import concurrent.futures
import difflib
import ctypes
import datetime
import gc
import hashlib
import html
import io
import posixpath
import importlib
import importlib.metadata
import json
import locale
import math
import array
import secrets
import os
import platform
import queue
import random
import re
import shutil
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import wave
import weakref
import zipfile
from collections import deque
from pathlib import Path, PurePosixPath

APP_NAME = "离线 AI 视频工坊"
APP_VERSION = "2.8.1"
RUNTIME_VERSION = "2026.11.13.6"
PIPELINE_VERSION = "2026.11.13.13"
MIN_PYTHON = (3, 10)
MAX_PYTHON = (3, 13)
GB = 1024 ** 3
DEFAULT_FPS = 24
SPEECH_RATE = 16000
ASR_WINDOW_SECONDS = 30
MAX_ASR_USER_WINDOWS = 36
ASR_BATCH_SECONDS = ASR_WINDOW_SECONDS * MAX_ASR_USER_WINDOWS
MAX_TRANSCRIPT_SECONDS = 24 * 3600
MAX_ASR_INPUTS = 0
MIN_SPEECH_SIMILARITY = .37
MIN_SPEECH_STRONG_MATCH = .72
MIN_STRONG_VOICE_CORRELATION = .90
MIN_SPEECH_REVIEW_CHARS = 12
MAX_NATIVE_SEGMENTS = 96
MAX_NEIGHBOR_FRAME_DIFFERENCE = 98
OCR_PAGES = 96
OCR_PAGE_SCALE = 1.5
SOURCE_METADATA_TIMEOUT = 15
EXTERNAL_COMMAND_HISTORY = 160
EXTERNAL_COMMAND_LOCK = threading.Lock()
EXTERNAL_COMMAND_EVENTS = deque(maxlen=EXTERNAL_COMMAND_HISTORY)
MIN_INSTALL_FREE = 8 * GB
MIN_JOB_FREE = 2 * GB
MAX_SCENE_ATTEMPTS = 3
MAX_REPAIR_PASSES = 2
MAX_AUTO_REPAIR_PASSES = 8
MAX_TEMPORAL_RETRIES = 2
MIN_CLIP_ABSOLUTE_COSINE = 0.12
MIN_CLIP_ABSOLUTE_MARGIN = 0.008
NATIVE_SMOKE_FRAMES = 17
NATIVE_SMOKE_STEPS = 4
NATIVE_SMOKE_TIMEOUT = 3600
REVIEW_PASS = "passed"
REVIEW_FAIL = "failed"
REVIEW_UNAVAILABLE = "unavailable"
REVIEW_NOT_APPLICABLE = "not_applicable"
MAX_SPEECH_SPEEDUP = 1.30
SPEECH_END_MARGIN = 0.12
STOP_GRACE_SECONDS = 18
MAX_FINAL_DURATION_DRIFT = 0.008
MIN_CLIP_COSINE = 0.16
MIN_CLIP_MARGIN = 0.015
PROGRESS_PREFIX = "OFFLINE_STUDIO_EVENT:"
MAX_DOCUMENT_BYTES = 24 * 1024 * 1024
MAX_DOCUMENT_XML_BYTES = 8 * 1024 * 1024
MAX_DOCUMENT_TEXT = 256000
MAX_FINGERPRINT_FULL_BYTES = 16 * 1024 * 1024
FINGERPRINT_SAMPLE_BYTES = 1024 * 1024
MODEL_SWITCH_FREE_BYTES = 5 * GB
FFMPEG_INPUT_TIMEOUT = 180
FIRST_LAST_HOLD_SECONDS = 0.35
BOUNDARY_FRAME_MEAN_DIFF_MAX = 24
VOICE_REPO = "rhasspy/piper-voices"
VOICE_REVISION = "217ddc79818708b078d0d14a8fae9608b9d77141"
VOICE_FILE = "zh/zh_CN/huayan/medium/zh_CN-huayan-medium.onnx"
VOICE_SHA256 = "9929917bf8cabb26fd528ea44d3a6699c11e87317a14765312420be230be0f3d"
VOICE_PACKAGES = ("piper-tts==1.8.0",)
MODEL_CHECK_MIN_BYTES = 1024 * 1024
MODEL_HASH_SAMPLE_BYTES = 64 * 1024
MODEL_HASH_VERIFICATION_FILE = ".hash-verification"
GPU_CRITICAL_FREE_BYTES = 512 * 1024 * 1024
DURATION_TIME_CONTEXT_CHARS = 32
MIN_REQUEST_DURATION = 1
MAX_REQUEST_DURATION = 3600
NATIVE_BACKGROUND_BANDWIDTH_BYTES = 4 * 1024 * 1024
NATIVE_DOWNLOAD_CHUNK_BYTES = 512 * 1024
NETWORK_COST_CHECK_INTERVAL = 60
NATIVE_DOWNLOAD_FILE_LIMIT = 256 * 1024 * 1024
WINDOWS_11_MIN_BUILD = 22000
TORCH_VERSION = "2.7.1"
CUDA_MIN_TOTAL_MB = 4096
CUDA_MIN_FREE_BYTES = 3 * GB
EXTERNAL_OUTPUT_QUEUE = 2048
EXTERNAL_ERROR_LINES = 18
UI_RECOMMEND_DELAY_MS = 450
UI_MAX_ASSET_ROWS = 5
UI_MAX_SCENE_ROWS = 10
UI_PREVIEW_IMAGE_LIMIT = 520
UI_PREVIEW_CACHE_LIMIT = 90
UI_PREVIEW_CACHE_AGE_SECONDS = 72 * 3600
UI_PREVIEW_RENDER_DELAY_MS = 160
NATIVE_GPU_LOW_STREAK_LIMIT = 2
NATIVE_STEP_GPU_CRITICAL_BYTES = GPU_CRITICAL_FREE_BYTES // 4
ASSET_MATCH_FACTOR = 4
ASSET_MATCH_LIMIT = 24
MAX_MODEL_DOWNLOAD_WORKERS = 4
MAX_DOWNLOAD_PROCESSES = 2
MIN_PARALLEL_DOWNLOAD_FREE = 20 * GB
MIN_FINAL_SEMANTIC_RETENTION = .78
MIN_SYSTEM_MEMORY_HEADROOM = 2 * GB
SYSTEM_MEMORY_RESERVE_FRACTION = .18
MIN_GPU_HEADROOM = 1024 * 1024 * 1024
MIN_WORKSPACE_PATH_MARGIN = 118
MAX_REFERENCE_BUDGET = 6400
MAX_DIRECTOR_CONTEXT = 4096
PLAN_BATCH_SCENES = 3
PLAN_OUTLINE_BATCH_SCENES = 6
PLAN_RETRIES = 3
PLAN_TOKENS_PER_SCENE = 280
BOUNDARY_BLEND_SECONDS = .45
BOUNDARY_FINAL_HOLD_SECONDS = .15
MIN_NATIVE_BRIDGE_SECONDS = 1.25
MIN_QUANTITY_COMPARISON_MARGIN = 0.009
DETECTOR_SCORE_LOW = 0.10
DETECTOR_SCORE_HIGH = 0.18
DETECTOR_NMS_IOU = 0.38
MIN_QUANTITY_FRAME_REVIEWS = 2
MIN_STATIC_SOURCE_PIXELS = 320 * 320
MAX_IMAGE_UPSCALE = 2.25
MIN_EFFECTIVE_IMAGE_PIXELS = 320 * 320
MIN_VIDEO_FRAME_CHANGE = 0.10
MIN_VIDEO_FREEZE_SECONDS = 0.5
TEMPORAL_REVIEW_SECONDS = 0.82
TEMPORAL_DUPLICATE_MEAN_DIFF = 0.095
TEMPORAL_JITTER_SPIKE_MIN = 38.0
REFERENCE_CHUNK_CHARS = 900
REFERENCE_CHUNK_OVERLAP = 80
MAX_MANDATORY_CLAUSES = 160
OFFLINE_PROBE_SECONDS = 2.0
MAX_VISUAL_CONSTRAINT_PROBES = 12
MAX_VISUAL_TEXT_PROBES = 24
MAX_SOURCE_REQUIREMENTS = 96
MAX_SOURCE_REQUIREMENT_CHARS = 9000
MAX_SOURCE_REQUIREMENT_CONTEXT = 1000
ASR_GPU_BASE_FREE_BYTES = 2 * GB
CUDA_PROBE_CACHE_SECONDS = 25
CUDA_FALLBACK_RETRY_SECONDS = 7 * 24 * 3600
MAX_SPEECH_RESPONSE_SECONDS = 150
RESOURCE_METRICS_LIMIT = 96
MAX_IMAGE_PIXELS = 1024 * 1024
MIN_IMAGE_DIMENSION = 192
NATIVE_VIDEO_MIN_FREE_MB = 1536
MIN_DISK_DOWNLOAD_RESERVE = MIN_JOB_FREE
VIDEO_MODEL_FOLDER = "video"
OPTIONAL_MODEL_FOLDERS = {"director": "director_plus", "painter": "painter_plus",
                          "listener": "listener_plus", "inspector": "inspector_plus"}
OPTIONAL_MODEL_CATALOG = (
    {"role": "director", "repo": "Qwen/Qwen2.5-3B-Instruct", "min_free_ram": 16 * GB,
     "min_free_gpu_mb": 6144, "download_estimate": 7 * GB},
    {"role": "painter", "repo": "stable-diffusion-v1-5/stable-diffusion-v1-5",
     "min_free_ram": 16 * GB, "min_free_gpu_mb": 8192, "download_estimate": 6 * GB},
    {"role": "inspector", "repo": "openai/clip-vit-large-patch14",
     "min_free_ram": 12 * GB, "min_free_gpu_mb": 6144, "download_estimate": 2 * GB},
    {"role": "listener", "repo": "openai/whisper-small",
     "min_free_ram": 12 * GB, "min_free_gpu_mb": 5120, "download_estimate": 2 * GB},
)
OPTIONAL_MODEL_FILE_PATTERNS = ("*.json", "*.txt", "*.model", "*.safetensors",
                                "*.vocab", "*.tiktoken", "*.merges")
OPTIONAL_ROLE_PATTERNS = {
    "director": OPTIONAL_MODEL_FILE_PATTERNS,
    "listener": OPTIONAL_MODEL_FILE_PATTERNS,
    "inspector": OPTIONAL_MODEL_FILE_PATTERNS,
    "painter": ("model_index.json", "feature_extractor/*.json", "scheduler/*.json",
                "tokenizer/*.json", "tokenizer/*.txt", "safety_checker/config.json",
                "safety_checker/model.safetensors", "text_encoder/config.json",
                "text_encoder/model.safetensors", "vae/config.json",
                "vae/diffusion_pytorch_model.safetensors", "unet/config.json",
                "unet/diffusion_pytorch_model.safetensors"),
}
OPTIONAL_MODEL_REVISIONS = {
    "Qwen/Qwen2.5-3B-Instruct": "aa8e72537993ba99e69dfaafa59ed015b17504d1",
    "stable-diffusion-v1-5/stable-diffusion-v1-5": "451f4fe16113bff5a5d2269ed5ad43b0592e9a14",
    "openai/clip-vit-large-patch14": "32bd64288804d66eefd0ccbe215aa642df71cc41",
    "openai/whisper-small": "973afd24965f72e36ca33b3055d56a652f456b4d",
}
TRUSTED_OPTIONAL_WEIGHTS = {
    "Qwen/Qwen2.5-3B-Instruct": {
        "model-00001-of-00002.safetensors": "67347b23fb4165b652eb6611f5e1f2a06dfcddba8e909df1b2b0b1857bee06c2",
        "model-00002-of-00002.safetensors": "a40d941d0e7e0b966ad8b62bb6d6b7c88cce1299197b599d9d0a4ce59aabfc1d"},
    "stable-diffusion-v1-5/stable-diffusion-v1-5": {
        "safety_checker/model.safetensors": "9d6a233ff6fd5ccb9f76fd99618d73369c52dd3d8222376384d0e601911089e8",
        "text_encoder/model.safetensors": "d008943c017f0092921106440254dbbe00b6a285f7883ec8ba160c3faad88334",
        "unet/diffusion_pytorch_model.safetensors": "19da7aaa4b880e59d56843f1fcb4dd9b599c28a1d9d9af7c1143057c8ffae9f1",
        "vae/diffusion_pytorch_model.safetensors": "a2b5134f4dbc140d9c11f11cba3233099e00af40f262f136c691fb7d38d2194c"},
    "openai/clip-vit-large-patch14": {
        "model.safetensors": "a2bf730a0c7debf160f7a6b50b3aaf3703e7e88ac73de7a314903141db026dcb"},
    "openai/whisper-small": {
        "model.safetensors": "1d7734884874f1a1513ed9aa760a4f8e97aaa02fd6d93a3a85d27b2ae9ca596b"},
}
NATIVE_VIDEO_FPS = 8
NATIVE_VIDEO_FRAMES = 49
NATIVE_VIDEO_MAX_FRAMES = 81
MAX_NATIVE_ATTEMPTS = 2
MAX_NATIVE_OUTPUT_DURATION_FACTOR = 1.04
NATIVE_VIDEO_MAX_SLOWDOWN = 1.5
NATIVE_REVIEW_FRACTIONS = (.02, .17, .34, .50, .66, .83, .98)
MODEL_INTEGRITY_EXTENSIONS = {".bin", ".safetensors", ".json", ".model", ".txt", ".py", ".onnx"}
RESOURCE_MONITOR_INTERVAL = 5
NETWORK_COST_CACHE = {"checked": 0.0, "result": None}
NETWORK_COST_LOCK = threading.Lock()
DOWNLOAD_SPACE_MULTIPLIER = 1.4
MODEL_SIZE_ESTIMATES = {"director": 2 * GB, "painter": 3 * GB, "listener": GB, "inspector": GB, "detector": GB, "voice": GB // 2}
MIN_CAPTION_FONT = 13
MAX_CAPTION_LINES = 3
CAPTION_MAX_WIDTH_FRACTION = .86
CAPTION_SEGMENT_GAP_FRAMES = 1
MAX_CAPTION_SEGMENTS = 12
MIN_NATIVE_TEMPORAL_DIFFERENCE = .7
MAX_NATIVE_TEMPORAL_DIFFERENCE = 80.0
MIN_MOTION_REVIEW_FRAMES = 3
MAX_ASR_CACHE_ENTRIES = 120
NATIVE_VIDEO_STEPS = {"快速": 12, "智能": 18, "精细": 25}
NATIVE_PROBE_STEPS = {"animatediff": 8, "cogvideox": 6}
MIN_DIRECTOR_USABLE_RAM = GB // 2
MIN_PAINTER_USABLE_RAM = GB
MIN_INSPECTOR_USABLE_RAM = GB // 2
CLIP_DURATION_TOLERANCE = .18
AMBIENT_VOLUME = .32
NATIVE_COMPONENTS = ("transformer", "vae", "text_encoder", "tokenizer", "scheduler")
NATIVE_RESOLUTIONS = {
    "横屏": ((768, 432), (512, 288), (384, 216), (256, 144)),
    "竖屏": ((432, 768), (288, 512), (216, 384), (144, 256)),
    "方形": ((576, 576), (448, 448), (384, 384), (320, 320), (256, 256))}
NATIVE_HIGH_MEMORY = 24 * GB
NATIVE_SEAM_DIFFERENCE_MAX = 58.0
NATIVE_MAX_SEAM_SAMPLES = 16
VOICE_PROBE_SECONDS = 60
VOICE_PROBE_LOCK = threading.RLock()
VOICE_PROBE_CACHE = {}
MIN_MIXED_VOICE_RMS = .0015
MIN_MIXED_VOICE_CORRELATION = .15
MAX_VOICE_CORRELATION_SECONDS = 9
MAX_VOICE_ALIGNMENT_SECONDS = .32
TORCH_WHEEL_INDEX = "https://download.pytorch.org/whl"
MODEL_SPECS = (
    ("分镜与文案", "Qwen/Qwen2.5-0.5B-Instruct", "director", ("*.json", "*.txt", "*.model", "*.safetensors")),
    ("画面生成", "segmind/tiny-sd", "painter", ("*.json", "*.txt", "*.model", "*.bin")),
    ("语音识别", "openai/whisper-tiny", "listener", ("*.json", "*.txt", "*.model", "*.safetensors")),
    ("画面语义审校", "openai/clip-vit-base-patch32", "inspector", ("*.json", "*.txt", "*.model", "*.bin")),
    ("实例数量检测", "google/owlvit-base-patch32", "detector", ("*.json", "*.txt", "*.model", "*.safetensors")),
)
MODEL_REVISIONS = {
    "Qwen/Qwen2.5-0.5B-Instruct": "7ae557604adf67be50417f59c2c2f167def9a775",
    "segmind/tiny-sd": "cad0bd7495fa6c4bcca01b19a723dc91627fe84f",
    "openai/whisper-tiny": "169d4a4341b33bc18d8881c4b69c2e104e1cc0af",
    "openai/clip-vit-base-patch32": "3d74acf9a28c67741b2f4f2ea7635f0aaf6f0268",
    "google/owlvit-base-patch32": "cbc355fb364588351c5d51c7f74465e8e7ec6f72",
}
TRUSTED_MODEL_WEIGHTS = {
    "Qwen/Qwen2.5-0.5B-Instruct": {
        "model.safetensors": "fdf756fa7fcbe7404d5c60e26bff1a0c8b8aa1f72ced49e7dd0210fe288fb7fe"},
    "segmind/tiny-sd": {
        "unet/diffusion_pytorch_model.bin": "c9b63e57cb1479c946c73bf5484bc1a823dbe565158ea0ee40015a18844d9f29",
        "text_encoder/pytorch_model.bin": "f99d8915149c782551f7d14aae5ca0b6e76a6e94d30e5dc86a349b228fbf92ad",
        "vae/diffusion_pytorch_model.bin": "279228e5296858f5d330db506ff6a51fdcad0d69f87634b5e9133406110af9bf"},
    "openai/whisper-tiny": {
        "model.safetensors": "7ebd0e69e78190ffe1438491fa05cc1f5c1aa3a4c4db3bc1723adbb551ea2395"},
    "openai/clip-vit-base-patch32": {
        "pytorch_model.bin": "a63082132ba4f97a80bea76823f544493bffa8082296d62d71581a4feff1576f"},
    "google/owlvit-base-patch32": {
        "model.safetensors": "4dbe0399f0b7d7c8dddf1535a98769cc30743bebc877aea681998c8d984ce52b"},
}
MIN_DISK_CACHE_RESERVE = GB
RUNTIME_BACKUP_FOLDER = "venv.rollback"
SOURCE_COPY_CHUNK = 2 * 1024 * 1024
BATTERY_RESOURCE_FRACTION = .8
MAX_ASSETS_PER_SCENE = 12
MIN_ASSET_SHOT_SECONDS = .45
MIN_MULTI_SCENE_SECONDS = 2.0
MAX_RESUME_JOBS = 250
MAX_PLAN_REPAIR_PASSES = 2
MIN_BOUNDARY_VISIBLE_FRAMES = 2
MIN_CAPTION_VISIBLE_FRAMES = 5
MAX_DOCX_EMBEDDED_IMAGES = 64
MAX_DOCX_EMBEDDED_IMAGE_PIXELS = 12000000
MAX_DOCX_EMBEDDED_BYTES = 12 * 1024 * 1024
MIN_EXPLICIT_DURATION_CONTEXT = 24


NATIVE_AUTO_REPO = "zai-org/CogVideoX-2b"
NATIVE_MOTION_REPO = "guoyww/animatediff-motion-adapter-v1-5-2"
NATIVE_BASE_REPO = "stable-diffusion-v1-5/stable-diffusion-v1-5"
NATIVE_ANIMATE_MIN_TOTAL_MB = 3584
NATIVE_ANIMATE_FRAME_LIMIT = 9
NATIVE_ANIMATE_LONG_FRAME_LIMIT = 17
NATIVE_ANIMATE_RESOLUTIONS = {
    "横屏": ((384, 216), (320, 192), (256, 144)),
    "竖屏": ((216, 384), (192, 320), (144, 256)),
    "方形": ((320, 320), (256, 256), (192, 192))}
NATIVE_MODEL_CATALOG = (
    {"id": "animatediff-1.5", "kind": "animatediff", "class": "AnimateDiffPipeline",
     "min_gpu_mb": NATIVE_ANIMATE_MIN_TOTAL_MB, "min_ram_bytes": 12 * GB,
     "estimated_download_bytes": 5 * GB, "license": "CreativeML OpenRAIL-M + motion-model license",
     "repos": ((NATIVE_BASE_REPO, "base"), (NATIVE_MOTION_REPO, "motion"))},
    {"id": "cogvideox-2b", "kind": "cogvideox", "class": "CogVideoXPipeline",
     "min_gpu_mb": 20 * 1024, "min_ram_bytes": 24 * GB,
     "estimated_download_bytes": 14 * GB, "license": "CogVideoX license",
     "repos": ((NATIVE_AUTO_REPO, ""),)})
NATIVE_AUTO_MIN_TOTAL_MB = 3584
NATIVE_AUTO_MIN_RAM = 2500 * 1024 * 1024
NATIVE_AUTO_RETRY_SECONDS = 24 * 3600
NATIVE_AUTO_DISK_RESERVE = 3 * GB
MODEL_DOWNLOAD_SECURITY_SUFFIXES = {".safetensors", ".json", ".model", ".txt"}
RESOURCE_PRESSURE_STREAK = 2
RESOURCE_MONITOR_CPU_LIMIT = 0.86
RESOURCE_MAX_CPU_SHARE = 0.65
RESOURCE_BUSY_IMAGE_FRACTION = 0.82
RESOURCE_BUSY_STEPS_FRACTION = 0.85
RESOURCE_BUSY_PAUSE_SECONDS = 2.4
RESOURCE_BUSY_POLL_SECONDS = 0.3
RESOURCE_MEMORY_WAIT_SECONDS = 1.6
RUNTIME_SNAPSHOT_RESERVE_BYTES = GB // 2
RUNTIME_MARKER_BACKUP = "packages_ready.rollback.json"
PDF_PAGE_TEXT_MIN_CHARS = 32
PDF_OCR_MISSING_MARKER = "[未完整识别第"
DOC_VISUAL_UNVERIFIED_MARKER = "[图片或图表含义未完全验证]"
VISUAL_CONTINUITY_THRESHOLD = 0.71
VISUAL_CONTINUITY_PATTERN = re.compile(
    r"同一(?:个|位|名)?(?:人物|人|角色|演员|主角)|人物(?:身份|外观|服装)一致|角色(?:形象|外观)一致|"
    r"same (?:person|character|actor)|consistent (?:character|actor|person)", re.I)

DOCUMENT_REQUIRED_PATTERN = re.compile(r"必须|严格按照|严格依据|仅根据|完全根据|务必引用|以.*(?:文档|材料|附件|资料).*为准|根据.*(?:文档|资料|附件)")

CORE_PACKAGE_SPECS = (
    "pillow>=10,<13", "numpy>=1.26,<2.3", "transformers==4.49.0", "sentencepiece>=0.2,<1",
    "accelerate>=1.4,<2", "safetensors>=0.4,<1",
    "huggingface-hub>=0.30,<1", "imageio-ffmpeg>=0.5,<1",
)
EXTENDED_PACKAGE_SPECS = ("diffusers==0.33.1", "pypdf>=5,<9")
OPTIONAL_OCR_PACKAGE_SPECS = ("pypdfium2>=4.30,<6", "rapidocr>=3.10,<5", "onnxruntime>=1.20,<2")
OPTIONAL_OCR_PACKAGE_IMPORTS = {"pypdfium2": "pypdfium2", "rapidocr": "rapidocr", "onnxruntime": "onnxruntime"}
CORE_PACKAGE_IMPORTS = {
    "torch": "torch", "transformers": "transformers", "accelerate": "accelerate",
    "safetensors": "safetensors", "huggingface-hub": "huggingface_hub",
    "imageio-ffmpeg": "imageio_ffmpeg", "pillow": "PIL", "numpy": "numpy",
    "sentencepiece": "sentencepiece",
}
EXTENDED_PACKAGE_IMPORTS = {"diffusers": "diffusers", "pypdf": "pypdf"}
VIDEO_TYPES = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}
AUDIO_TYPES = {".wav", ".mp3", ".flac", ".m4a", ".aac", ".ogg", ".wma"}
IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
DOC_TYPES = {".txt", ".md", ".csv", ".json", ".pdf", ".docx", ".html", ".htm", ".srt"}
RUNNING_CHILDREN = weakref.WeakSet()
RUNNING_CHILDREN_LOCK = threading.Lock()


def now_stamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def slug(value, length=34):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", str(value))
    value = re.sub(r"\s+", "_", value).strip(" ._")
    return value[:length] or "作品"



def request_fingerprint(request, previous=None):
    payload = {key: value for key, value in request.items() if key != "files"}
    payload["files"] = {}
    prior = (previous or {}).get("source_manifest", [])
    for category, paths in sorted(request.get("files", {}).items()):
        records = []
        for index, name in enumerate(paths):
            path = Path(name)
            if path.is_file() and not path.is_symlink():
                stat = path.stat()
                records.append((path.name.casefold(), stat.st_size, file_integrity_hash(path)))
            else:
                record = next((item for item in prior if item.get("category") == category and
                               item.get("index") == index and item.get("name", "").casefold() ==
                               path.name.casefold()), None)
                if record and verified_local_source(record, None):
                    records.append((path.name.casefold(), record["bytes"], record["sample_hash"]))
                else:
                    records.append((path.name.casefold(), None, "source_unavailable"))
        payload["files"][category] = records
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                     default=str).encode("utf-8")).hexdigest()


def request_resume_key(request):
    payload = {key: value for key, value in request.items() if key != "files"}
    payload["files"] = {category: [Path(name).name.casefold() for name in paths]
                        for category, paths in sorted(request.get("files", {}).items())}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                     default=str).encode("utf-8")).hexdigest()


def verified_local_source(record, root):
    try:
        path = Path(record.get("copy", ""))
        if root is not None:
            workspace = Path(root).resolve()
            actual = path.resolve(strict=True)
            if actual != workspace and workspace not in actual.parents:
                return False
        if (not path.is_file() or path.is_symlink() or
                path.stat().st_size != int(record.get("bytes", -1)) or
                not secrets.compare_digest(file_integrity_hash(path), str(record.get("sample_hash", "")))):
            return False
        digest = record.get("sha256")
        return not digest or secrets.compare_digest(full_file_sha256(path), digest)
    except (OSError, ValueError, TypeError):
        return False


def resume_sources_match(root, request, previous):
    manifest = previous.get("source_manifest", [])
    if not isinstance(manifest, list):
        return False
    requested = request.get("files", {})
    if sum(map(len, requested.values())) != len(manifest):
        return False
    for category, files in requested.items():
        for index, filename in enumerate(files):
            record = next((item for item in manifest if isinstance(item, dict) and
                           item.get("category") == category and item.get("index") == index and
                           item.get("name", "").casefold() == Path(filename).name.casefold()), None)
            if record is None or not verified_local_source(record, root):
                return False
            original = Path(filename)
            if original.is_file() and not original.is_symlink():
                if (original.stat().st_size != record["bytes"] or
                        file_integrity_hash(original) != record["sample_hash"]):
                    return False
    return True


def find_resumable_job(root, request):
    directory = Path(root) / ".studio" / "jobs"
    token = request_resume_key(request)
    for candidate in sorted(directory.glob("*/job.json"), reverse=True)[:MAX_RESUME_JOBS]:
        data = read_json(candidate, {})
        if (data.get("resume_key") == token and
                data.get("status") in ("失败", "已停止", "运行中") and
                resume_sources_match(root, request, data)):
            return candidate.parent, data
    return None


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + secrets.token_hex(8) + ".partial")
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_json(path, default=None):
    try:
        parsed = json.loads(Path(path).read_text(encoding="utf-8"))
        return parsed if default is None or isinstance(parsed, type(default)) else default
    except (OSError, ValueError, TypeError):
        return default


def memory_info():
    if os.name != "nt":
        try:
            page = os.sysconf("SC_PAGE_SIZE")
            allmem = os.sysconf("SC_PHYS_PAGES") * page
            freemem = os.sysconf("SC_AVPHYS_PAGES") * page
            return {"total": allmem, "available": freemem}
        except (OSError, ValueError, AttributeError):
            return {"total": 0, "available": 0}
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
    state = MEMORYSTATUSEX()
    state.dwLength = ctypes.sizeof(state)
    if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
        return {"total": state.ullTotalPhys, "available": state.ullAvailPhys}
    return {"total": 0, "available": 0}


def nvidia_smi_paths():
    programs = []
    discovered = shutil.which("nvidia-smi")
    if discovered:
        programs.append(discovered)
    if os.name == "nt":
        for variable in ("ProgramW6432", "ProgramFiles", "ProgramFiles(x86)"):
            location = os.environ.get(variable)
            if location:
                programs.append(str(Path(location) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe"))
        system = os.environ.get("SystemRoot", r"C:\Windows")
        programs.append(str(Path(system) / "System32" / "nvidia-smi.exe"))
    return list(dict.fromkeys(str(Path(item)) for item in programs if Path(item).is_file()))


WINDOWS_NVIDIA_CACHE = {"checked": 0.0, "devices": []}
RUNTIME_CUDA_CACHE = {}
RUNTIME_CUDA_LOCK = threading.RLock()


def windows_nvidia_fallback():
    if os.name != "nt":
        return []
    current = time.monotonic()
    if current - WINDOWS_NVIDIA_CACHE["checked"] < 60:
        return [dict(item) for item in WINDOWS_NVIDIA_CACHE["devices"]]
    flags = subprocess.CREATE_NO_WINDOW
    command = ("Get-CimInstance Win32_VideoController | "
               "Where-Object { $_.Name -match 'NVIDIA' } | "
               "Select-Object Name,AdapterRAM | ConvertTo-Json -Compress")
    try:
        result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
                                capture_output=True, text=True, encoding="utf-8", errors="replace",
                                timeout=12, creationflags=flags)
        if result.returncode != 0 or not result.stdout.strip():
            return []
        parsed = json.loads(result.stdout)
        records = parsed if isinstance(parsed, list) else [parsed]
        devices = []
        for item in records:
            if not isinstance(item, dict) or "NVIDIA" not in str(item.get("Name", "")).upper():
                continue
            try:
                ram = max(0, int(item.get("AdapterRAM") or 0))
            except (ValueError, TypeError):
                ram = 0
            devices.append({"index": len(devices), "physical_index": len(devices),
                            "name": str(item["Name"]), "total_mb": ram // (1024 * 1024),
                            "free_mb": 0, "driver": "", "uuid": "",
                            "detected_without_smi": True})
        WINDOWS_NVIDIA_CACHE.update({"checked": time.monotonic(), "devices": devices})
        return devices
    except (OSError, ValueError, subprocess.TimeoutExpired, json.JSONDecodeError):
        WINDOWS_NVIDIA_CACHE.update({"checked": time.monotonic(), "devices": []})
        return []


def runtime_cuda_devices(root):
    root = Path(root)
    python = runtime_python(root)
    if not python.is_file():
        return []
    key = str(root.resolve())
    current = time.monotonic()
    with RUNTIME_CUDA_LOCK:
        old = RUNTIME_CUDA_CACHE.get(key, {})
        if current - old.get("at", -1e9) < CUDA_PROBE_CACHE_SECONDS:
            return [dict(item) for item in old.get("devices", [])]
    script = ("import json, torch; result=[]; "
              "available=bool(torch.cuda.is_available()); "
              "[(lambda idx: result.append(dict(index=idx, physical_index=idx, "
              "name=torch.cuda.get_device_properties(idx).name, "
              "free_mb=torch.cuda.mem_get_info(idx)[0]//1048576, "
              "total_mb=torch.cuda.mem_get_info(idx)[1]//1048576, "
              "driver='', uuid='', runtime_cuda=True)))(i) "
              "for i in range(torch.cuda.device_count())] if available else None; "
              "print(json.dumps(result))")
    try:
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        proc = subprocess.run([str(python), "-c", script], cwd=str(root),
                              capture_output=True, text=True, errors="replace",
                              timeout=55, creationflags=flags, env=shell_env(root, offline=True))
        devices = json.loads(proc.stdout.splitlines()[-1]) if proc.returncode == 0 else []
        if not isinstance(devices, list) or not all(isinstance(item, dict) for item in devices):
            devices = []
    except (OSError, ValueError, IndexError, subprocess.TimeoutExpired):
        devices = []
    with RUNTIME_CUDA_LOCK:
        RUNTIME_CUDA_CACHE[key] = {"at": time.monotonic(), "devices": devices}
    return [dict(item) for item in devices]


def torch_runtime_probe(root):
    python = runtime_python(root)
    if not python.is_file():
        return {}
    script = 'import json, torch\nassert torch.__version__.split("+")[0] == "2.7.1"\nassert float(torch.ones(2).sum().item()) == 2.0\navailable = bool(torch.cuda.is_available())\ninfo = {"version":torch.__version__, "cuda_visible":available, "cuda_compute":False, "reason":""}\nif available:\n    try:\n        x = torch.ones(2, device="cuda")\n        info["cuda_compute"] = float(x.sum().item()) == 2.0\n        del x\n    except Exception as error:\n        info["reason"] = str(error)[:200]\nprint(json.dumps(info))\n'
    try:
        output = run_external([str(python), "-c", script], root, timeout=160,
                              env=shell_env(root, offline=True), capture=True)
        for line in reversed(output.splitlines()):
            try:
                record = json.loads(line)
                if isinstance(record, dict) and record.get("version"):
                    return record
            except (ValueError, TypeError):
                continue
    except (RuntimeError, OSError, TimeoutError):
        pass
    return {}


def gpu_info(root=None):
    result = {"name": "", "free_mb": 0, "total_mb": 0, "driver": "", "index": None, "devices": []}
    devices = []
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    for executable in nvidia_smi_paths():
        try:
            proc = subprocess.run([executable,
                                   "--query-gpu=index,name,memory.free,memory.total,driver_version,uuid",
                                   "--format=csv,noheader,nounits"], capture_output=True, text=True,
                                  timeout=6, creationflags=flags)
            if proc.returncode != 0:
                continue
            for line in proc.stdout.splitlines():
                fields = [field.strip() for field in line.split(",")]
                if len(fields) < 6:
                    continue
                try:
                    devices.append({"physical_index": int(fields[0]), "index": int(fields[0]),
                                    "name": fields[1], "free_mb": int(fields[2]),
                                    "total_mb": int(fields[3]), "driver": fields[4], "uuid": fields[5]})
                except (ValueError, IndexError):
                    continue
            if devices:
                break
        except (ValueError, OSError, subprocess.TimeoutExpired):
            continue
    logical_cuda = False
    if not devices:
        devices = windows_nvidia_fallback()
        if root is not None:
            actual_cuda = runtime_cuda_devices(root)
            if actual_cuda:
                devices = actual_cuda
                logical_cuda = True
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    if visible is not None and not logical_cuda:
        ordered = []
        for token in (part.strip() for part in visible.split(",")):
            if not token or token == "-1":
                continue
            found = next((item for item in devices if token == str(item["physical_index"]) or
                          (item.get("uuid") and (token == item["uuid"] or
                                                   item["uuid"].startswith(token)))), None)
            if found is not None and found not in ordered:
                ordered.append(found)
        devices = [{**item, "index": index} for index, item in enumerate(ordered)]
    if devices:
        preferred = max(devices, key=lambda item: (item["free_mb"], item["total_mb"]))
        result.update(preferred)
        result["devices"] = devices
    return result


def torch_cuda_devices(torch):
    devices = []
    try:
        if not torch.cuda.is_available():
            return devices
        for index in range(torch.cuda.device_count()):
            try:
                free, total = torch.cuda.mem_get_info(index)
                props = torch.cuda.get_device_properties(index)
                devices.append({"index": index, "name": props.name,
                                "free_mb": int(free // (1024 * 1024)),
                                "total_mb": int(total // (1024 * 1024)),
                                "free_bytes": int(free), "total_bytes": int(total)})
            except (RuntimeError, AssertionError, ValueError):
                continue
    except (RuntimeError, AssertionError, ValueError):
        pass
    return devices


def select_torch_gpu(torch, minimum_free=0, preferred=None):
    candidates = [item for item in torch_cuda_devices(torch) if item["free_bytes"] >= minimum_free]
    if preferred:
        candidates = [item for item in candidates if item["name"] == preferred.get("name") and
                      (preferred.get("index") is None or item["index"] == preferred["index"]) and
                      abs(item["total_mb"] - (preferred.get("total_mb") or 0)) <=
                      max(256, int((preferred.get("total_mb") or 0) * .04))]
    return max(candidates, key=lambda item: (item["free_bytes"], item["total_bytes"])) if candidates else None

class ResourceGovernor:
    def __init__(self, root=None):
        self.root = Path(root) if root else None
        self.peak_ram_pressure = 0.0
        self.lowest_available_ram = None
        self.lowest_available_gpu = None
        self.samples = []
        self._gpu_snapshot = {}
        self._gpu_checked = 0.0
        self._cuda_torch = None
        self._cuda_index = None
        self._monitor_stop = threading.Event()
        self._monitor_thread = None
        self.resource_stop_reason = None
        self._lock = threading.RLock()
        self.pressure_events = []
        self._cpu_previous = None
        self._cpu_busy = None
        self._power = system_power_state()
        self._power_checked = 0.0
        self._cpu_runtime = None
        self._cpu_threads_base = None
        self._cpu_threads_active = None
        self._cpu_throttle_events = []

    def attach_runtime(self, module):
        with self._lock:
            self._cpu_runtime = module
            self._cpu_threads_base = max(1, available_threads())
            self._cpu_threads_active = self._cpu_threads_base

    def adjust_cpu_threads(self, sample, stage):
        module = self._cpu_runtime
        if module is None or self._cpu_threads_base is None:
            return
        busy = sample.get("cpu_busy")
        limit = self._cpu_threads_base
        if sample.get("on_battery"):
            limit = max(1, int(limit * BATTERY_RESOURCE_FRACTION))
        if busy is not None and busy > RESOURCE_MONITOR_CPU_LIMIT:
            limit = max(1, min(limit, int(self._cpu_threads_base * RESOURCE_MAX_CPU_SHARE)))
        if limit == self._cpu_threads_active:
            return
        try:
            module.set_num_threads(limit)
        except (RuntimeError, ValueError, OSError):
            return
        with self._lock:
            self._cpu_threads_active = limit
            self._cpu_throttle_events.append({"stage": str(stage)[:80], "at": sample["at"],
                                              "threads": limit, "cpu_busy": busy,
                                              "on_battery": sample.get("on_battery")})
            self._cpu_throttle_events = self._cpu_throttle_events[-RESOURCE_METRICS_LIMIT:]

    def attach_cuda(self, torch_module=None, index=None):
        with self._lock:
            self._cuda_torch = torch_module if index is not None else None
            self._cuda_index = index
            self._gpu_checked = 0.0

    def start_monitor(self, cancel=None, notify=None):
        if self._monitor_thread is not None and self._monitor_thread.is_alive():
            return
        self._monitor_stop.clear()
        def monitor():
            streak = 0
            while not self._monitor_stop.wait(RESOURCE_MONITOR_INTERVAL):
                try:
                    sample = self.snapshot("live_resource_check")
                    total = sample["ram_total"]
                    danger_ram = total and sample["ram_available"] < max(512 * 1024 * 1024, int(total * .05))
                    free_disk = sample["disk_free"]
                    danger_disk = free_disk is not None and free_disk < MIN_JOB_FREE // 4
                    streak = streak + 1 if danger_ram or danger_disk else 0
                    if streak >= RESOURCE_PRESSURE_STREAK:
                        self.resource_stop_reason = ("可用内存持续低于安全阈值" if danger_ram else
                                                     "工作磁盘空间已接近耗尽")
                        if notify:
                            notify("为保护设备已请求停止：" + self.resource_stop_reason)
                        if isinstance(cancel, StopSignal):
                            cancel.filename.touch()
                        elif isinstance(cancel, threading.Event):
                            cancel.set()
                        break
                except (OSError, ValueError) as error:
                    if notify:
                        notify("资源采样跳过一次：" + type(error).__name__)
        self._monitor_thread = threading.Thread(target=monitor, daemon=True)
        self._monitor_thread.start()

    def stop_monitor(self):
        self._monitor_stop.set()
        if self._monitor_thread and threading.current_thread() is not self._monitor_thread:
            self._monitor_thread.join(timeout=1.0)
        self._monitor_thread = None

    def snapshot(self, stage=""):
        with self._lock:
            ram = memory_info()
            moment = time.monotonic()
            if moment - self._gpu_checked >= RESOURCE_MONITOR_INTERVAL or not self._gpu_snapshot:
                self._gpu_snapshot = gpu_info()
                self._gpu_checked = moment
            gpu = dict(self._gpu_snapshot)
            if self._cuda_torch is not None and self._cuda_index is not None:
                try:
                    free_bytes, total_bytes = self._cuda_torch.cuda.mem_get_info(self._cuda_index)
                    device_name = self._cuda_torch.cuda.get_device_properties(self._cuda_index).name
                    gpu.update({"free_mb": free_bytes // (1024 * 1024),
                                "total_mb": total_bytes // (1024 * 1024),
                                "index": self._cuda_index, "name": device_name,
                                "devices": [{"index": self._cuda_index, "name": device_name}]})
                except (RuntimeError, AssertionError, ValueError):
                    gpu.update({"free_mb": 0, "index": self._cuda_index, "devices": []})
            current_cpu = cpu_time_sample()
            if current_cpu and self._cpu_previous:
                idle_diff = current_cpu[0] - self._cpu_previous[0]
                total_diff = current_cpu[1] - self._cpu_previous[1]
                if total_diff > 0:
                    self._cpu_busy = round(max(0.0, min(1.0, 1.0 - idle_diff / total_diff)), 3)
            self._cpu_previous = current_cpu
            if moment - self._power_checked >= RESOURCE_MONITOR_INTERVAL:
                self._power = system_power_state()
                self._power_checked = moment
            free = int(ram.get("available", 0))
            total = int(ram.get("total", 0))
            gpu_free = max(0, int(gpu.get("free_mb", 0))) * 1024 * 1024
            reserve = max(MIN_SYSTEM_MEMORY_HEADROOM, int(total * SYSTEM_MEMORY_RESERVE_FRACTION))
            usable = max(0, free - reserve)
            if total:
                self.peak_ram_pressure = max(self.peak_ram_pressure, 1 - free / total)
            self.lowest_available_ram = (free if self.lowest_available_ram is None
                                         else min(free, self.lowest_available_ram))
            if gpu.get("devices"):
                self.lowest_available_gpu = (gpu_free if self.lowest_available_gpu is None
                                             else min(gpu_free, self.lowest_available_gpu))
            sample = {"stage": str(stage)[:80], "ram_available": free, "ram_usable": usable,
                      "ram_total": total, "gpu_free": gpu_free, "gpu_index": gpu.get("index"),
                      "disk_free": shutil.disk_usage(self.root).free if self.root and self.root.exists() else None,
                      "cpu_busy": self._cpu_busy,
                      "on_battery": self._power.get("on_battery", False),
                      "battery_percent": self._power.get("percent"),
                      "at": datetime.datetime.now().isoformat()}
            self.samples.append(sample)
            if len(self.samples) > RESOURCE_METRICS_LIMIT:
                del self.samples[:-RESOURCE_METRICS_LIMIT]
            return dict(sample)

    def budget(self, stage, ram_bytes=0, gpu_bytes=0, disk_bytes=0, device="cpu"):
        sample = self.snapshot(stage)
        if sample["ram_total"] and sample["ram_usable"] < int(ram_bytes):
            raise RuntimeError("本机可用内存不足以安全执行 %s" % stage)
        if device == "cuda" and sample["gpu_free"] < int(gpu_bytes) + MIN_GPU_HEADROOM:
            raise RuntimeError("当前空闲显存不足以安全执行 %s" % stage)
        if sample["disk_free"] is not None and sample["disk_free"] < MIN_JOB_FREE + int(disk_bytes):
            raise RuntimeError("工作目录剩余空间不足以安全执行 %s" % stage)
        return sample

    def adaptive_pause(self, stage, cancel=None, notify=None, allowance=4):
        paused_cpu = False
        start_time = time.monotonic()
        for number in range(allowance + 1):
            if cancel is not None and cancel.is_set():
                raise InterruptedError("已停止")
            sample = self.snapshot(stage)
            self.adjust_cpu_threads(sample, stage)
            total = sample["ram_total"]
            pressure = bool(total and sample["ram_available"] < max(
                MIN_SYSTEM_MEMORY_HEADROOM, int(total * SYSTEM_MEMORY_RESERVE_FRACTION)))
            busy_cpu = (sample.get("cpu_busy") is not None and
                        sample["cpu_busy"] > RESOURCE_MONITOR_CPU_LIMIT)
            on_battery = sample.get("on_battery")
            if not pressure:
                if busy_cpu and not paused_cpu and notify:
                    notify("检测到其他任务繁忙，已减少 CPU 并发并主动让出计算时间")
                if busy_cpu and time.monotonic() - start_time < RESOURCE_BUSY_PAUSE_SECONDS:
                    paused_cpu = True
                    wait_seconds = min(RESOURCE_BUSY_POLL_SECONDS,
                                       RESOURCE_BUSY_PAUSE_SECONDS - (time.monotonic() - start_time))
                    if wait_seconds > 0:
                        if cancel is not None and cancel.wait(wait_seconds):
                            raise InterruptedError("已停止")
                        if cancel is None:
                            time.sleep(wait_seconds)
                    continue
                if on_battery:
                    if cancel is not None and cancel.wait(RESOURCE_BUSY_POLL_SECONDS):
                        raise InterruptedError("已停止")
                    if cancel is None:
                        time.sleep(RESOURCE_BUSY_POLL_SECONDS)
                return sample
            with self._lock:
                self.pressure_events.append({"stage": stage, "at": sample["at"],
                                             "ram_available": sample["ram_available"]})
                self.pressure_events = self.pressure_events[-RESOURCE_METRICS_LIMIT:]
            if number >= allowance:
                raise RuntimeError("其他软件占用较多内存，已保护设备并停止当前阶段：" + stage)
            if notify:
                notify("检测到可用内存不足，释放缓存并等待其他程序释放资源")
            gc.collect()
            delay = min(RESOURCE_MEMORY_WAIT_SECONDS, RESOURCE_BUSY_POLL_SECONDS * (number + 2))
            if cancel is not None and cancel.wait(delay):
                raise InterruptedError("已停止")
            if cancel is None:
                time.sleep(delay)

    def image_profile(self, quality, device="cpu", torch_free=None):
        sample = self.snapshot("image_profile")
        ram = sample["ram_usable"]
        available = (max(0, torch_free - MIN_GPU_HEADROOM)
                     if device == "cuda" and torch_free is not None else
                     max(0, sample["gpu_free"] - MIN_GPU_HEADROOM) if device == "cuda" else ram)
        if sample.get("on_battery"):
            available = int(available * BATTERY_RESOURCE_FRACTION)
            ram = int(ram * BATTERY_RESOURCE_FRACTION)
        profile = image_resource_profile(quality, device, ram, max(0, available))
        if sample.get("cpu_busy") is not None and sample["cpu_busy"] > RESOURCE_MONITOR_CPU_LIMIT:
            return (max(MIN_IMAGE_DIMENSION, int(profile[0] * RESOURCE_BUSY_IMAGE_FRACTION) // 8 * 8),
                    max(6, int(profile[1] * RESOURCE_BUSY_STEPS_FRACTION)))
        return profile

    def ensure(self, stage, required=0, disk_required=0):
        sample = self.snapshot(stage)
        if required and sample["ram_usable"] < required:
            raise RuntimeError("可用内存不足，已保护系统并停止当前步骤：%s" % stage)
        if disk_required and sample["disk_free"] is not None and sample["disk_free"] < disk_required:
            raise RuntimeError("工作目录磁盘空间不足，已停止写入：%s" % stage)
        return sample

    def report(self):
        with self._lock:
            return {"peak_ram_pressure": round(self.peak_ram_pressure, 4),
                    "minimum_available_ram": self.lowest_available_ram,
                    "minimum_available_gpu": self.lowest_available_gpu,
                    "resource_stop_reason": self.resource_stop_reason,
                    "power": dict(self._power), "cpu_busy": self._cpu_busy,
                    "pressure_events": list(self.pressure_events),
                    "cpu_throttle_events": list(self._cpu_throttle_events),
                    "cpu_threads_active": self._cpu_threads_active,
                    "samples": list(self.samples)}

def cuda_install_expectation(root):
    root = Path(root)
    gpu = gpu_info(root)
    candidate = bool(gpu.get("total_mb", 0) >= CUDA_MIN_TOTAL_MB or any(
        item.get("detected_without_smi") for item in gpu.get("devices", [])))
    if not candidate:
        return False
    status = torch_runtime_probe(root)
    if status.get("cuda_compute"):
        return False
    identity = hashlib.sha256(json.dumps([gpu.get("name", ""), gpu.get("driver", ""),
        gpu.get("total_mb", 0), TORCH_VERSION, str(runtime_python(root))],
        ensure_ascii=False).encode("utf-8")).hexdigest()
    previous = read_json(root / ".studio" / "cuda_cpu_fallback.json", {})
    if (previous.get("identity") == identity and previous.get("status") == "cpu_fallback" and
            time.time() - float(previous.get("checked_at", 0)) < CUDA_FALLBACK_RETRY_SECONDS):
        return False
    return True


def record_cuda_fallback(root, detected, failed):
    root = Path(root)
    marker = root / ".studio" / "cuda_cpu_fallback.json"
    if failed:
        identity = hashlib.sha256(json.dumps([detected.get("name", ""), detected.get("driver", ""),
            detected.get("total_mb", 0), TORCH_VERSION, str(runtime_python(root))],
            ensure_ascii=False).encode("utf-8")).hexdigest()
        atomic_json(marker, {"status": "cpu_fallback", "identity": identity,
                             "checked_at": time.time(), "driver": detected.get("driver", ""),
                             "gpu": detected.get("name", ""), "torch": TORCH_VERSION})
    else:
        marker.unlink(missing_ok=True)


def torch_install_sources(gpu, package_indexes):
    sources = []
    match = re.match(r"^(\d+)", str(gpu.get("driver", "")))
    major = int(match.group(1)) if match else 0
    if gpu.get("total_mb", 0) >= CUDA_MIN_TOTAL_MB or gpu.get("detected_without_smi"):
        if major >= 570:
            sources.append(("CUDA 12.8", TORCH_WHEEL_INDEX + "/cu128", True))
        if major >= 560:
            sources.append(("CUDA 12.6", TORCH_WHEEL_INDEX + "/cu126", True))
        if major >= 520 or gpu.get("detected_without_smi") and not major:
            sources.append(("CUDA 11.8", TORCH_WHEEL_INDEX + "/cu118", True))
    sources.append(("CPU", TORCH_WHEEL_INDEX + "/cpu", False))
    sources.extend(("CPU 备用源", index, False) for index in package_indexes)
    return sources


def host_install_preflight(root):
    import importlib.util
    unsupported = [name for name in ("ssl", "venv", "ensurepip", "tkinter")
                   if importlib.util.find_spec(name) is None]
    if unsupported:
        raise RuntimeError("当前 Python 安装不完整，缺少 " + ", ".join(unsupported) + "；请安装带 Tcl/Tk、pip 和 venv 的正式 64 位 Python")
    if os.name == "nt":
        if sys.getwindowsversion().build < WINDOWS_11_MIN_BUILD:
            raise RuntimeError("系统版本低于 Windows 11 build 22000")
        if struct.calcsize("P") != 8:
            raise RuntimeError("当前 Python 不是 64 位解释器")
    root = Path(root)
    if len(str(root)) + MIN_WORKSPACE_PATH_MARGIN >= 240 and os.name == "nt":
        raise RuntimeError("工作目录路径过长，不适合存储深层模型文件")
    transaction = root / (".studio_preflight_" + secrets.token_hex(6))
    destination = transaction.with_suffix(".checked")
    try:
        transaction.write_bytes(b"ok")
        os.replace(transaction, destination)
        if destination.read_bytes() != b"ok":
            raise RuntimeError("选定目录不支持可靠写入和重命名")
    finally:
        transaction.unlink(missing_ok=True)
        destination.unlink(missing_ok=True)
    free = shutil.disk_usage(root).free
    detected = gpu_info()
    return {"python": list(sys.version_info[:2]), "architecture_bits": struct.calcsize("P") * 8,
            "system_build": sys.getwindowsversion().build if os.name == "nt" else None,
            "disk_free_gb": round(free / GB, 2),
            "gpu_mode": "nvidia_cuda_candidate" if detected.get("devices") else "cpu_fallback",
            "nvidia_driver": detected.get("driver", ""),
            "nvidia_total_mb": detected.get("total_mb", 0)}


def installation_failure_hint(error):
    message = str(error).lower()
    if any(word in message for word in ("no space left", "disk full", "winerror 112", "磁盘空间不足", "空间不足")):
        return "disk_full", "磁盘空间不足，请更换工作目录或清理空间"
    if any(word in message for word in ("no matching distribution", "not a supported wheel", "requires-python", "unsupported python")):
        return "incompatible_package", "安装包与当前 Python/Windows 版本不兼容"
    if any(word in message for word in ("sha-256", "sha256", "hash mismatch", "校验失败", "校验结果不符")):
        return "integrity_failed", "下载数据校验失败，请保留工作目录并重试"
    if any(word in message for word in ("winerror 5", "permission denied", "access is denied", "拒绝访问")):
        return "permission_denied", "工作目录或缓存文件权限不足"
    if any(word in message for word in ("certificate verify failed", "sslerror", "tlsv", "certificate_verify")):
        return "certificate_error", "TLS 证书验证失败，请检查 Windows 证书和网络设置"
    if any(word in message for word in ("404", "not found", "repositorynotfounderror", "entrynotfounderror")):
        return "resource_missing", "安装源或固定版本资源不可用，将尝试备用线路"
    if any(word in message for word in ("timeout", "timed out", "name resolution", "temporary failure", "network is unreachable", "连接超时", "无法连接")):
        return "network_unavailable", "网络不可达或请求超时，将尝试备用线路"
    return "unclassified", "可根据黑匣子中的日志判断失败位置"


def windows_network_cost(force=False):
    if os.name != "nt":
        return {"known": False, "metered": True, "type": "unsupported_platform"}
    with NETWORK_COST_LOCK:
        when = time.monotonic()
        previous = NETWORK_COST_CACHE["result"]
        if not force and previous is not None and when - NETWORK_COST_CACHE["checked"] < NETWORK_COST_CHECK_INTERVAL:
            return dict(previous)
        script = ("$ErrorActionPreference='Stop';"
                  "$p=[Windows.Networking.Connectivity.NetworkInformation,Windows.Networking.Connectivity,ContentType=WindowsRuntime]::GetInternetConnectionProfile();"
                  "if($null -eq $p){'none';exit};"
                  "$c=$p.GetConnectionCost();"
                  "'{0},{1},{2},{3}' -f $c.NetworkCostType,$c.Roaming,$c.OverDataLimit,$c.ApproachingDataLimit")
        result = {"known": False, "metered": True, "type": "unknown"}
        try:
            flags = subprocess.CREATE_NO_WINDOW
            completed = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                                       capture_output=True, text=True, encoding="utf-8", errors="replace",
                                       timeout=12, creationflags=flags)
            lines = completed.stdout.strip().splitlines()
            if completed.returncode == 0 and lines:
                values = [item.strip().lower() for item in lines[-1].split(",")]
                if len(values) == 4 and values[0] in {"unrestricted", "fixed", "variable", "unknown"}:
                    is_metered = (values[0] != "unrestricted" or any(
                        flag == "true" for flag in values[1:]))
                    result = {"known": values[0] != "unknown", "metered": is_metered,
                              "type": values[0], "roaming": values[1] == "true",
                              "over_limit": values[2] == "true", "near_limit": values[3] == "true"}
        except (OSError, ValueError, subprocess.TimeoutExpired):
            pass
        NETWORK_COST_CACHE.update({"checked": when, "result": result})
        return dict(result)


def image_resource_profile(quality, device, available_ram, available_gpu):
    available = max(0, int(available_gpu if device == "cuda" else available_ram))
    if device == "cuda":
        bounds = ((3 * GB, 256), (5 * GB, 320), (8 * GB, 448),
                  (12 * GB, 512), (16 * GB, 640), (24 * GB, 768),
                  (32 * GB, 896), (40 * GB, 1024))
    else:
        bounds = ((3 * GB, 256), (6 * GB, 320), (10 * GB, 384),
                  (16 * GB, 448), (24 * GB, 512))
    side = bounds[0][1]
    for floor, size in bounds:
        if available >= floor:
            side = size
    if quality == "快速":
        side = min(side, 448)
    elif quality == "精细" and available >= (12 if device == "cuda" else 16) * GB:
        side = min(1024, round(side * 1.12 / 8) * 8)
    steps = {"快速": 8, "智能": 16, "精细": 26}.get(quality, 16)
    if device == "cpu":
        steps = min(steps, 18)
    return max(MIN_IMAGE_DIMENSION, side // 8 * 8), steps


def is_memory_error(error):
    if isinstance(error, MemoryError):
        return True
    description = str(error).lower()
    return any(item in description for item in (
        "out of memory", "not enough memory", "cuda error: out", "cuda out of memory",
        "defaultcpuallocator", "can't allocate memory", "cannot allocate memory",
        "allocation failed", "failed to allocate", "bad allocation"))


def set_low_priority():
    try:
        if os.name == "nt":
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
        else:
            os.nice(5)
    except (OSError, AttributeError):
        pass


def configure_environment(root):
    root = Path(root)
    directories = ("models", "cache", "cache/hf", "cache/torch", "cache/pip", "jobs", "sources", "logs", "tmp")
    for dirname in directories:
        (root / ".studio" / dirname).mkdir(parents=True, exist_ok=True)
    os.environ.update({
        "HF_HOME": str(root / ".studio" / "cache" / "hf"),
        "HUGGINGFACE_HUB_CACHE": str(root / ".studio" / "cache" / "hf" / "hub"),
        "HF_XET_CACHE": str(root / ".studio" / "cache" / "hf" / "xet"),
        "TORCH_HOME": str(root / ".studio" / "cache" / "torch"),
        "PIP_CACHE_DIR": str(root / ".studio" / "cache" / "pip"),
        "TEMP": str(root / ".studio" / "tmp"),
        "TMP": str(root / ".studio" / "tmp"),
        "TMPDIR": str(root / ".studio" / "tmp"),
        "HF_HUB_DISABLE_TELEMETRY": "1",
        "HF_HUB_DISABLE_XET": "1",
        "DO_NOT_TRACK": "1",
        "PYTHONUTF8": "1",
        "TOKENIZERS_PARALLELISM": "false",
        "PYTHONNOUSERSITE": "1",
    })
    return root / ".studio"


def runtime_python(root):
    runtime = Path(root) / ".studio" / "venv"
    return runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def system_power_state():
    if os.name != "nt":
        return {"on_battery": False, "percent": None}
    class PowerStatus(ctypes.Structure):
        _fields_ = [("ac", ctypes.c_ubyte), ("flag", ctypes.c_ubyte),
                    ("percent", ctypes.c_ubyte), ("reserved", ctypes.c_ubyte),
                    ("lifetime", ctypes.c_ulong), ("remaining", ctypes.c_ulong)]
    status = PowerStatus()
    try:
        if not ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            return {"on_battery": False, "percent": None}
        return {"on_battery": status.ac == 0,
                "percent": status.percent if status.percent <= 100 else None}
    except (AttributeError, OSError, ValueError):
        return {"on_battery": False, "percent": None}


def cpu_time_sample():
    if os.name != "nt":
        return None
    idle, kernel, user = ctypes.c_ulonglong(), ctypes.c_ulonglong(), ctypes.c_ulonglong()
    try:
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
            return None
        return idle.value, kernel.value + user.value
    except (AttributeError, OSError):
        return None


def runtime_matches_host(root):
    executable = runtime_python(root)
    if not executable.is_file():
        return False
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    program = ("import sys,struct,json;print(json.dumps([sys.version_info[0],"
               "sys.version_info[1],struct.calcsize('P')*8]))")
    try:
        result = subprocess.run([str(executable), "-c", program], capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=18,
                                creationflags=creationflags)
        lines = result.stdout.strip().splitlines()
        return result.returncode == 0 and bool(lines) and json.loads(lines[-1]) == [
            sys.version_info.major, sys.version_info.minor, 64 if sys.maxsize > 2 ** 32 else 32]
    except (OSError, subprocess.TimeoutExpired, ValueError, IndexError):
        return False


def runtime_snapshot_copy(source, target):
    return shutil.copy2(source, target)

def recover_runtime_transaction(root):
    folder = Path(root) / ".studio"
    existing = folder / "venv"
    backup = folder / RUNTIME_BACKUP_FOLDER
    snapshot_staging = folder / (RUNTIME_BACKUP_FOLDER + ".creating")
    if snapshot_staging.is_dir():
        shutil.rmtree(snapshot_staging)
    if not backup.is_dir():
        return False
    if existing.exists():
        shutil.rmtree(existing)
    os.replace(backup, existing)
    marker = folder / "packages_ready.json"
    marker_backup = folder / RUNTIME_MARKER_BACKUP
    if marker_backup.is_file():
        os.replace(marker_backup, marker)
    else:
        marker.unlink(missing_ok=True)
    return True


def installation_disk_budget(root, tier="basic", needs_piper=False, replacement=False):
    root = Path(root)
    free = shutil.disk_usage(root).free
    missing = [spec[2] for spec in MODEL_SPECS[:1 if tier == "basic" else len(MODEL_SPECS)]
               if not model_download_complete(root, spec)]
    if needs_piper and not voice_download_complete(root):
        missing.append("voice")
    expected_models = sum(MODEL_SIZE_ESTIMATES.get(name, GB) for name in missing)
    existing_venv = root / ".studio" / "venv"
    occupied = 0
    if existing_venv.is_dir():
        for filename in existing_venv.rglob("*"):
            if filename.is_file() and not filename.is_symlink():
                occupied += filename.stat().st_size
    engine = (5 * GB if gpu_info().get("total_mb", 0) >= CUDA_MIN_TOTAL_MB else 3 * GB)
    library_cost = GB if tier == "basic" else 2 * GB
    snapshot_cost = (max(RUNTIME_SNAPSHOT_RESERVE_BYTES, occupied)
                     if existing_venv.is_dir() and not replacement else 0)
    additional_runtime = (engine + library_cost if replacement or not existing_venv.is_dir()
                          else library_cost + snapshot_cost)
    required = (MIN_JOB_FREE + MIN_DISK_CACHE_RESERVE +
                int(expected_models * DOWNLOAD_SPACE_MULTIPLIER) + additional_runtime)
    return {"free": free, "required": required, "missing_models": missing,
            "runtime_bytes": occupied, "snapshot_budget_bytes": snapshot_cost,
            "replacement": replacement, "tier": tier, "estimated_model_bytes": expected_models}


def runtime_site(root):
    runtime = Path(root) / ".studio" / "venv"
    if os.name == "nt":
        return runtime / "Lib" / "site-packages"
    return runtime / "lib" / ("python%d.%d" % sys.version_info[:2]) / "site-packages"


class WorkspaceLock:
    def __init__(self, root):
        base = Path(root) / ".studio"
        base.mkdir(parents=True, exist_ok=True)
        self.handle = (base / "instance.lock").open("a+b")
        try:
            self.handle.seek(0)
            if not self.handle.read(1):
                self.handle.seek(0)
                self.handle.write(b"0")
                self.handle.flush()
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError):
            self.handle.close()
            raise RuntimeError("此工作目录正被另一个程序实例使用，请勿重复打开")

    def close(self):
        if self.handle.closed:
            return
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()


class StopSignal:
    def __init__(self, filename):
        self.filename = Path(filename)

    def is_set(self):
        return self.filename.is_file()

    def wait(self, seconds):
        deadline = time.monotonic() + max(0, float(seconds))
        while time.monotonic() < deadline:
            if self.is_set():
                return True
            time.sleep(min(.12, max(0, deadline - time.monotonic())))
        return self.is_set()


def model_path(root, folder):
    return Path(root) / ".studio" / "models" / folder


def voice_model_path(root):
    return model_path(root, "voice") / VOICE_FILE


def voice_model_ready(root):
    weight = voice_model_path(root)
    config = read_json(str(weight) + ".json", {})
    return (weight.is_file() and weight.stat().st_size >= 30 * 1024 * 1024
            and isinstance(config, dict) and config.get("phoneme_type") == "espeak"
            and isinstance(config.get("phoneme_id_map"), dict)
            and bool(config.get("phoneme_id_map")))


def voice_download_complete(root, deep=False):
    marker = read_json(model_path(root, "voice") / "download.json", {})
    if not (marker.get("repo") == VOICE_REPO
            and marker.get("revision") == VOICE_REVISION
            and marker.get("sha256") == VOICE_SHA256
            and voice_model_ready(root)):
        return False
    weight = voice_model_path(root)
    if deep or not marker.get("sample_hash"):
        return full_file_sha256(weight) == VOICE_SHA256
    return marker.get("sample_hash") == file_integrity_hash(weight)


def folder_has_weights(path):
    path = Path(path)
    name = path.name.removesuffix(".downloading")
    def weighted(folder):
        return any(file.is_file() and file.stat().st_size > MODEL_CHECK_MIN_BYTES
                   for suffix in ("*.bin", "*.safetensors") for file in folder.glob(suffix))
    if name == "painter":
        if not (path / "model_index.json").is_file():
            return False
        for component in ("unet", "vae", "text_encoder"):
            folder = path / component
            if not (folder / "config.json").is_file() or not weighted(folder):
                return False
        return (path / "tokenizer" / "vocab.json").is_file() and (path / "tokenizer" / "merges.txt").is_file()
    required = {"director": ("config.json", "tokenizer_config.json"),
                "listener": ("config.json", "preprocessor_config.json"),
                "inspector": ("config.json", "preprocessor_config.json")}.get(name)
    if not required or not all((path / filename).is_file() for filename in required):
        return False
    return weighted(path)


def model_files_manifest(folder):
    folder = Path(folder)
    return {entry.relative_to(folder).as_posix(): entry.stat().st_size
            for entry in folder.rglob("*")
            if entry.is_file() and ".cache" not in entry.relative_to(folder).parts
            and entry.name not in {"download.json", MODEL_HASH_VERIFICATION_FILE}}


def pinned_model_weights_valid(folder, repo, hashes=None, deep=False):
    folder = Path(folder)
    expected = TRUSTED_MODEL_WEIGHTS.get(repo)
    if not expected:
        return False
    if hashes is not None and not isinstance(hashes, dict):
        return False
    for relative, digest in expected.items():
        item = folder.joinpath(*PurePosixPath(relative).parts)
        if not item.is_file() or item.is_symlink() or item.stat().st_size < MODEL_CHECK_MIN_BYTES:
            return False
        if hashes is not None and not secrets.compare_digest(str(hashes.get(relative, "")), digest):
            return False
        if deep and not secrets.compare_digest(full_file_sha256(item), digest):
            return False
    return True


def file_integrity_hash(path):
    path = Path(path)
    size = path.stat().st_size
    digest = hashlib.sha256(struct.pack("<Q", size))
    with path.open("rb") as stream:
        if size <= MODEL_HASH_SAMPLE_BYTES * 3:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        else:
            for offset in (0, max(0, (size - MODEL_HASH_SAMPLE_BYTES) // 2),
                           max(0, size - MODEL_HASH_SAMPLE_BYTES)):
                stream.seek(offset)
                digest.update(struct.pack("<Q", offset))
                digest.update(stream.read(MODEL_HASH_SAMPLE_BYTES))
    return digest.hexdigest()


def full_file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def model_integrity_manifest(folder):
    folder = Path(folder)
    return {path.relative_to(folder).as_posix(): file_integrity_hash(path)
            for path in folder.rglob("*") if path.is_file()
            and ".cache" not in path.relative_to(folder).parts
            and path.suffix.lower() in MODEL_INTEGRITY_EXTENSIONS
            and path.name not in {"download.json", MODEL_HASH_VERIFICATION_FILE}}


def model_full_sha256_manifest(folder):
    folder = Path(folder)
    return {path.relative_to(folder).as_posix(): full_file_sha256(path)
            for path in folder.rglob("*") if path.is_file()
            and ".cache" not in path.relative_to(folder).parts
            and path.name not in {"download.json", MODEL_HASH_VERIFICATION_FILE}}

def full_hashes_verified(folder, expected_hashes, force=False):
    folder = Path(folder)
    if not isinstance(expected_hashes, dict) or not expected_hashes:
        return False
    records = []
    try:
        for relative, digest in sorted(expected_hashes.items()):
            part = PurePosixPath(relative)
            if (not isinstance(relative, str) or not part.parts or part.is_absolute() or
                    ".." in part.parts or not isinstance(digest, str) or
                    not re.fullmatch(r"[0-9a-f]{64}", digest)):
                return False
            file = folder.joinpath(*part.parts)
            if not file.is_file() or file.is_symlink():
                return False
            stat = file.stat()
            records.append((relative, digest, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns))
        token = hashlib.sha256(json.dumps(records, ensure_ascii=False,
                                          separators=(",", ":")).encode("utf-8")).hexdigest()
        stamp = folder / MODEL_HASH_VERIFICATION_FILE
        if not force and read_json(stamp, {}).get("fingerprint") == token:
            return True
        for relative, digest, _, _, _ in records:
            if not secrets.compare_digest(full_file_sha256(folder.joinpath(*PurePosixPath(relative).parts)), digest):
                return False
        for relative, _, size, mtime, ctime in records:
            stat = folder.joinpath(*PurePosixPath(relative).parts).stat()
            if (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns) != (size, mtime, ctime):
                return False
        atomic_json(stamp, {"fingerprint": token, "verified_at": datetime.datetime.now().isoformat(),
                            "files": len(records)})
        return True
    except (OSError, ValueError, TypeError):
        return False


def git_blob_sha1(path):
    size = Path(path).stat().st_size
    digest = hashlib.sha1(("blob %d\0" % size).encode("ascii"))
    with Path(path).open("rb") as stream:
        for piece in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(piece)
    return digest.hexdigest()


def official_model_metadata(repo, revision, endpoint):
    from huggingface_hub import HfApi
    tried = []
    for server in ("https://huggingface.co",):
        try:
            info = HfApi(endpoint=server).model_info(repo_id=repo, revision=revision,
                                                      files_metadata=True, timeout=SOURCE_METADATA_TIMEOUT)
            if info.sha != revision:
                raise RuntimeError("模型仓库提交版本与锁定值不一致")
            hashes = {}
            sizes = {}
            for sibling in info.siblings:
                name = str(sibling.rfilename)
                size = getattr(sibling, "size", None)
                if isinstance(size, int) and size >= 0:
                    sizes[name] = size
                lfs = getattr(sibling, "lfs", None)
                value = lfs.get("sha256") if isinstance(lfs, dict) else None
                if value and re.fullmatch(r"[0-9a-f]{64}", value):
                    hashes[name] = {"type": "sha256", "value": value}
                else:
                    blob = getattr(sibling, "blob_id", None)
                    if isinstance(blob, str) and re.fullmatch(r"[0-9a-f]{40}", blob):
                        hashes[name] = {"type": "git-sha1", "value": blob}
            if not hashes:
                raise RuntimeError("仓库未返回可校验的文件摘要")
            pinned = TRUSTED_MODEL_WEIGHTS.get(repo, {})
            if any(hashes.get(name, {}).get("value") != digest and hashes.get(name, {}).get("type") == "sha256"
                   for name, digest in pinned.items()):
                raise RuntimeError("官方固定提交权重摘要与内置可信清单冲突")
            return {"repo": repo, "revision": revision, "origin": server,
                    "authoritative": True, "hashes": hashes, "sizes": sizes}
        except (OSError, RuntimeError, ValueError, urllib.error.URLError) as error:
            tried.append(str(error)[:170])
    pins = TRUSTED_MODEL_WEIGHTS.get(repo)
    if not pins:
        raise RuntimeError("官方元数据不可访问且没有独立的可信权重摘要：" + " / ".join(tried))
    print("官方元数据暂不可达，启用程序内置可信 SHA-256 权重校验；镜像配置文件仍需离线推理验收", flush=True)
    return {"repo": repo, "revision": revision, "origin": "embedded-sha256-pins",
            "authoritative": False, "verification_level": "pinned_weights_only",
            "hashes": {name: {"type": "sha256", "value": value} for name, value in pins.items()},
            "sizes": {}, "official_errors": tried[-2:]}


def verify_remote_file_hashes(folder, provenance, mandatory=True):
    hashes = provenance.get("hashes", {})
    if not isinstance(hashes, dict):
        return False
    checked = 0
    for name, value in hashes.items():
        if not isinstance(name, str) or Path(name).is_absolute() or ".." in Path(name).parts:
            return False
        file = Path(folder) / name
        if not file.is_file():
            continue
        if not isinstance(value, dict) or value.get("type") not in {"sha256", "git-sha1"}:
            return False
        expected = value.get("value", "")
        if (value["type"] == "git-sha1" and
                name in TRUSTED_MODEL_WEIGHTS.get(provenance.get("repo", ""), {})):
            if full_file_sha256(file) != TRUSTED_MODEL_WEIGHTS[provenance["repo"]][name]:
                return False
            checked += 1
            continue
        actual = full_file_sha256(file) if value["type"] == "sha256" else git_blob_sha1(file)
        if not secrets.compare_digest(str(expected), actual):
            return False
        if file.suffix.lower() in {".bin", ".safetensors", ".onnx"}:
            checked += 1
    return bool(checked) if mandatory else True


def model_folder_complete(folder, spec, deep=False):
    repo = spec[1]
    folder = Path(folder)
    marker = read_json(folder / "download.json", {})
    if (not folder_has_weights(folder) or marker.get("repo") != repo
            or marker.get("revision") != MODEL_REVISIONS.get(repo)
            or not marker.get("complete")):
        return False
    recorded = marker.get("files")
    if not isinstance(recorded, dict) or not recorded:
        return False
    for relative, size in recorded.items():
        if not isinstance(relative, str) or not isinstance(size, int) or size <= 0:
            return False
        path = Path(relative)
        if path.is_absolute() or ".." in path.parts:
            return False
        item = folder / path
        if not item.is_file() or item.stat().st_size != size:
            return False
    full_hashes = marker.get("sha256")
    if not isinstance(full_hashes, dict) or set(full_hashes) != set(recorded):
        return False
    if any(not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value)
           for value in full_hashes.values()):
        return False
    if not pinned_model_weights_valid(folder, repo, full_hashes, deep=False):
        return False
    integrity = marker.get("integrity")
    if not isinstance(integrity, dict) or not integrity:
        return False
    for relative, signature in integrity.items():
        if (relative not in recorded or not isinstance(relative, str)
                or not re.fullmatch(r"[0-9a-f]{64}", str(signature))
                or Path(relative).is_absolute() or ".." in Path(relative).parts):
            return False
        item = folder / relative
        if not item.is_file() or file_integrity_hash(item) != signature:
            return False
    if not full_hashes_verified(folder, full_hashes, force=deep):
        return False
    if deep:
        provenance = marker.get("source_metadata")
        if provenance:
            if (not isinstance(provenance, dict) or provenance.get("repo") != repo or
                    provenance.get("revision") != MODEL_REVISIONS[repo]):
                return False
            official = (provenance.get("authoritative") is True and
                        provenance.get("origin") == "https://huggingface.co")
            embedded = (provenance.get("authoritative") is False and
                        provenance.get("origin") == "embedded-sha256-pins" and
                        provenance.get("verification_level") == "pinned_weights_only" and
                        provenance.get("hashes") == {name: {"type": "sha256", "value": value}
                                                      for name, value in TRUSTED_MODEL_WEIGHTS[repo].items()})
            if not (official or embedded) or not verify_remote_file_hashes(folder, provenance):
                return False
    for index in folder.rglob("*.index.json"):
        index_data = read_json(index, {})
        weights = index_data.get("weight_map")
        if not isinstance(weights, dict) or not weights:
            return False
        for relative in set(weights.values()):
            if not isinstance(relative, str) or ".." in Path(relative).parts:
                return False
            shard = index.parent / relative
            if not shard.is_file() or shard.stat().st_size <= MODEL_CHECK_MIN_BYTES:
                return False
    return True


def remove_corrupt_model_files(folder, marker):
    folder = Path(folder)
    hashes = marker.get("sha256", {})
    sizes = marker.get("files", {})
    signatures = marker.get("integrity", {})
    for relative, size in sizes.items():
        if not isinstance(relative, str) or Path(relative).is_absolute() or ".." in Path(relative).parts:
            continue
        path = folder / relative
        if not path.is_file():
            continue
        corrupted = (path.stat().st_size != size or
                     relative in signatures and file_integrity_hash(path) != signatures[relative] or
                     relative in hashes and full_file_sha256(path) != hashes[relative])
        if corrupted:
            path.unlink()


def optional_trusted_provenance(repo):
    revision = OPTIONAL_MODEL_REVISIONS[repo]
    hashes = TRUSTED_OPTIONAL_WEIGHTS[repo]
    return {"repo": repo, "revision": revision, "origin": "embedded-sha256-pins",
            "authoritative": False, "verification_level": "pinned_weights_only",
            "hashes": {name: {"type": "sha256", "value": digest}
                       for name, digest in hashes.items()}, "sizes": {}}


def optional_weights_verified(folder, repo, check_files=True):
    folder = Path(folder)
    expected = TRUSTED_OPTIONAL_WEIGHTS.get(repo, {})
    weights = {file.relative_to(folder).as_posix(): file
               for file in folder.rglob("*.safetensors") if file.is_file()}
    weights.update({file.relative_to(folder).as_posix(): file
                    for file in folder.rglob("*.bin") if file.is_file()})
    if not expected or set(weights) != set(expected):
        return False
    if not check_files:
        return True
    return all(secrets.compare_digest(full_file_sha256(weights[name]), digest)
               for name, digest in expected.items())


def optional_model_verified(folder, role, deep=False):
    folder = Path(folder)
    manifest = read_json(folder / "download.json", {})
    selection = next((item for item in OPTIONAL_MODEL_CATALOG if item["role"] == role), None)
    if (selection is None or manifest.get("repo") != selection["repo"] or
            manifest.get("revision") != OPTIONAL_MODEL_REVISIONS.get(selection["repo"]) or
            manifest.get("role") != role or not manifest.get("complete") or
            not isinstance(manifest.get("sha256"), dict)):
        return False
    provenance = manifest.get("source_metadata", {})
    if not isinstance(provenance, dict) or provenance != optional_trusted_provenance(selection["repo"]):
        return False
    weights = [part for ext in ("*.bin", "*.safetensors") for part in folder.rglob(ext)]
    if not weights or not (folder / ("model_index.json" if role == "painter" else "config.json")).is_file():
        return False
    signatures = manifest["sha256"]
    checked_integrity = manifest.get("integrity", {})
    if not isinstance(checked_integrity, dict) or not checked_integrity:
        return False
    if not all((entry.relative_to(folder).as_posix() in signatures) for entry in weights):
        return False
    for relative, digest in signatures.items():
        filename = Path(relative)
        if filename.is_absolute() or ".." in filename.parts or not re.fullmatch(r"[0-9a-f]{64}", str(digest)):
            return False
        item = folder / filename
        if not item.is_file():
            return False
        if relative in checked_integrity and file_integrity_hash(item) != checked_integrity[relative]:
            return False
    if not full_hashes_verified(folder, signatures, force=deep):
        return False
    if (not set(weight.relative_to(folder).as_posix() for weight in weights).issubset(checked_integrity)
            or not optional_weights_verified(folder, selection["repo"], check_files=False)):
        return False
    return not deep or (optional_weights_verified(folder, selection["repo"], check_files=True)
                        and verify_remote_file_hashes(folder, provenance))


def model_provenance(root):
    result = []
    for _, repo, folder, _ in MODEL_SPECS:
        marker = read_json(model_path(root, folder) / "download.json", {})
        origin = marker.get("source_metadata", {})
        result.append({"role": folder, "repo": repo, "revision_locked": marker.get("revision") == MODEL_REVISIONS[repo],
                       "source_metadata": "official" if origin.get("authoritative") else
                       "mirror_only" if origin.get("hashes") else "self_hash_only",
                       "content_verified": bool(origin.get("hashes"))})
    return result


def model_download_complete(root, spec, deep=False):
    return model_folder_complete(model_path(root, spec[2]), spec, deep=deep)


def models_complete(root):
    return all(model_download_complete(root, item) for item in MODEL_SPECS)


def required_imports(tier, needs_piper=False):
    result = dict(CORE_PACKAGE_IMPORTS)
    if tier == "full":
        result.update(EXTENDED_PACKAGE_IMPORTS)
    if needs_piper:
        result["piper-tts"] = "piper"
    return result


def installed_package_versions(root):
    site = runtime_site(root)
    versions = {}
    if site.is_dir():
        for item in importlib.metadata.distributions(path=[str(site)]):
            name = str(item.metadata.get("Name", "")).strip().lower().replace("_", "-")
            if name:
                versions[name] = item.version
    return versions


def package_sentinels(root, tier, needs_piper=False):
    site = runtime_site(root)
    result = {}
    for module in required_imports(tier, needs_piper).values():
        folder = site / module
        candidate = folder / "__init__.py" if folder.is_dir() else site / (module + ".py")
        if not candidate.is_file():
            return None
        result[candidate.relative_to(site).as_posix()] = file_integrity_hash(candidate)
    binary = site / "torch" / ("_C.pyd" if os.name == "nt" else "_C" + (".so" if sys.platform != "darwin" else ".dylib"))
    if binary.is_file():
        result[binary.relative_to(site).as_posix()] = file_integrity_hash(binary)
    return result


def optional_ocr_ready(root):
    marker = read_json(Path(root) / ".studio" / "ocr_ready.json", {})
    if (marker.get("runtime_version") != RUNTIME_VERSION or
            marker.get("python") != list(sys.version_info[:2])):
        return False
    installed = installed_package_versions(root)
    return all(installed.get(name) == marker.get("versions", {}).get(name)
               and (runtime_site(root) / module / "__init__.py").is_file()
               for name, module in OPTIONAL_OCR_PACKAGE_IMPORTS.items())


def packages_healthy(root, tier="basic", needs_piper=False):
    marker = read_json(Path(root) / ".studio" / "packages_ready.json", {})
    if (marker.get("runtime_version") != RUNTIME_VERSION or
            marker.get("python") != list(sys.version_info[:2]) or
            not marker.get("tiers", {}).get(tier) or not runtime_matches_host(root)):
        return False
    expected = required_imports(tier, needs_piper)
    versions = installed_package_versions(root)
    locked = marker.get("versions", {})
    if any(not versions.get(name) or versions[name] != locked.get(name) for name in expected):
        return False
    expected_signatures = marker.get("sentinels", {})
    current = package_sentinels(root, tier, needs_piper)
    return bool(current) and all(expected_signatures.get(name) == value for name, value in current.items())


def verify_packages_worker(root, tier="basic", needs_piper=False):
    configure_environment(root)
    imported = {}
    if tier == "ocr":
        for distribution, module in OPTIONAL_OCR_PACKAGE_IMPORTS.items():
            imported[distribution] = importlib.import_module(module).__name__
        from rapidocr import RapidOCR
        if not callable(RapidOCR):
            raise RuntimeError("离线 OCR 模块无法创建")
        print(json.dumps({"ok": True, "tier": tier, "imports": imported}, ensure_ascii=False), flush=True)
        return
    for distribution, module in required_imports(tier, needs_piper).items():
        imported[distribution] = importlib.import_module(module).__name__
    import torch
    if not math.isclose(float(torch.ones(2, device="cpu").sum().item()), 2.0):
        raise RuntimeError("PyTorch CPU 计算校验失败")
    if tier == "full":
        from diffusers import DiffusionPipeline
        from transformers import CLIPModel, WhisperForConditionalGeneration
        if not all((DiffusionPipeline, CLIPModel, WhisperForConditionalGeneration)):
            raise RuntimeError("离线模型的导入检查失败")
    print(json.dumps({"ok": True, "tier": tier, "imports": imported}, ensure_ascii=False), flush=True)


def basic_ready(root):
    marker = read_json(Path(root) / ".studio" / "basic_ready.json", {})
    if (marker.get("runtime_version") != RUNTIME_VERSION
            or marker.get("python") != list(sys.version_info[:2])
            or not marker.get("diagnostic", {}).get("smoke_test")
            or not runtime_matches_host(root)):
        return False
    if not model_download_complete(root, MODEL_SPECS[0]):
        return False
    voice_backend = marker.get("diagnostic", {}).get("voice_backend")
    if voice_backend not in {"sapi", "piper"} or not voice_backend_operational(root, voice_backend):
        return False
    return packages_healthy(root, "basic", voice_backend == "piper")


def safetensors_structure_valid(path):
    path = Path(path)
    try:
        size = path.stat().st_size
        if size <= 32:
            return False
        with path.open("rb") as stream:
            header_size = struct.unpack("<Q", stream.read(8))[0]
            if not 2 <= header_size <= min(size - 8, 64 * 1024 * 1024):
                return False
            header = json.loads(stream.read(header_size).decode("utf-8"))
        if not isinstance(header, dict):
            return False
        entries = [entry for key, entry in header.items() if key != "__metadata__"]
        if not entries:
            return False
        payload_size = size - 8 - header_size
        for value in entries:
            if not isinstance(value, dict):
                return False
            offsets = value.get("data_offsets")
            if (not isinstance(offsets, list) or len(offsets) != 2 or
                    not all(isinstance(number, int) for number in offsets) or
                    not 0 <= offsets[0] < offsets[1] <= payload_size or
                    not isinstance(value.get("dtype"), str) or
                    not isinstance(value.get("shape"), list)):
                return False
        return True
    except (OSError, ValueError, TypeError, UnicodeError, struct.error, OverflowError):
        return False



def select_native_profile(gpu=None, ram=None, disk_free=None, needs_images=False, profile_id=None):
    gpu = gpu if gpu is not None else gpu_info()
    ram = ram if ram is not None else memory_info()
    total_ram = int(ram.get("total", 0))
    free_ram = int(ram.get("available", 0))
    usable_ram = max(0, free_ram - max(MIN_SYSTEM_MEMORY_HEADROOM,
                                       int(total_ram * SYSTEM_MEMORY_RESERVE_FRACTION)))
    gpu_free = int(gpu.get("free_mb", 0))
    available = []
    for profile in NATIVE_MODEL_CATALOG:
        minimum_disk = (NATIVE_AUTO_DISK_RESERVE + MIN_INSTALL_FREE +
                        math.ceil(profile["estimated_download_bytes"] * DOWNLOAD_SPACE_MULTIPLIER))
        minimum_gpu_free = max(NATIVE_VIDEO_MIN_FREE_MB,
                               int(profile["min_gpu_mb"] * .75) + MIN_GPU_HEADROOM // (1024 * 1024))
        if (int(gpu.get("total_mb", 0)) >= profile["min_gpu_mb"] and
                gpu_free >= minimum_gpu_free and usable_ram >= profile["min_ram_bytes"] and
                (disk_free is None or disk_free >= minimum_disk) and
                (not needs_images or profile["class"] in {
                    "AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"}) and
                (profile_id is None or profile["id"] == profile_id)):
            available.append(profile)
    return max(available, key=lambda item: (item["min_gpu_mb"], item["min_ram_bytes"])) if available else None



def explicit_native_requested(prompt):
    return bool(re.search(r"原生\s*(?:ai|人工智能)?\s*(?:动态)?视频|原生时序|真实时序生成|"
                          r"(?:必须|务必|只能|请用|要求).{0,14}(?:时序扩散|逐帧生成|非静态运镜)|"
                          r"native\s*(?:ai\s*)?(?:video|generation)|temporal\s+diffusion", str(prompt), re.I))


def native_input_compatibility(model_class, request):
    files = request.get("files", {}) if isinstance(request, dict) else {}
    inputs = bool(any(files.get(kind) for kind in ("图片", "首帧", "尾帧")))
    if not model_class:
        return False, "尚无通过离线推理验收的原生视频模型"
    if inputs and model_class == "CogVideoXPipeline":
        return False, "当前原生模型仅支持文生视频，不接受用户上传的图片或首尾帧"
    if model_class == "CogVideoXImageToVideoPipeline" and not files.get("首帧"):
        return False, "当前原生模型要求提供首帧，无法为所有分镜提供输入条件"
    if (files.get("尾帧") and model_class not in
            {"AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"}):
        return False, "原生模型无法处理用户指定的尾帧约束"
    return True, "图文输入与原生视频模型兼容"


SUBJECT_MOTION_PATTERN = re.compile(
    r"奔跑|跑步|跑向|走过来|走过去|走路|行走|跃起|跳跃|跳起|跳舞|起舞|挥手|转身|回头|"
    r"接住|抓住|扑向|追逐|摔倒|落地|飞行|飞过|游动|游泳|攀爬|挣脱|翻滚|打斗|奔向|"
    r"\b(?:runs?|running|walks?|walking|jumps?|jumping|dances?|dancing|waves?|waving|"
    r"leaps?|leaping|catches?|catching|flies|flying|swims?|swimming|climbs?|climbing|"
    r"moves?\s+(?:across|toward|towards|away|forward)|turns?\s+(?:around|his\s+head|her\s+head))\b", re.I)


def requires_subject_motion(prompt):
    source = str(prompt)
    return bool(SUBJECT_MOTION_PATTERN.search(source) and not re.search(
        r"(?:不要|禁止|无需|不需要|没有|无)\s*(?:人物|动物|主体)?(?:运动|动作|跳跃|跑步)|"
        r"(?:no|without)\s+(?:subject\s+)?(?:motion|movement|action)", source, re.I))

def native_mode_for_request(capabilities, request, model_class=None):
    required = bool(explicit_native_requested(request.get("prompt", "")) or
                    requires_subject_motion(request.get("prompt", "")))
    compatible, reason = native_input_compatibility(model_class, request)
    use_native = bool(capabilities.get("native_video") and compatible)
    return {"visual_mode": "原生AI视频（自动）" if use_native or required else "智能轻量运镜",
            "native_required": required, "native_usable": use_native,
            "compatible": compatible, "reason": reason}

def native_component_layout_valid(folder):
    folder = Path(folder)
    info = read_json(folder / "model_index.json", {})
    kind = info.get("_class_name")
    if kind == "AnimateDiffPipeline":
        base = folder / "base"
        adapter = folder / "motion"
        index = read_json(base / "model_index.json", {})
        if index.get("_class_name") != "StableDiffusionPipeline":
            return False
        components = ("unet", "vae", "text_encoder", "tokenizer", "scheduler")
        for role in components:
            base_role = base / role
            config = ("scheduler_config.json" if role == "scheduler" else
                      "tokenizer_config.json" if role == "tokenizer" else "config.json")
            if not (base_role / config).is_file():
                return False
            if role in {"unet", "vae", "text_encoder"}:
                weights = list(base_role.glob("*.safetensors"))
                if (len(weights) != 1 or not weights[0].name.endswith(".fp16.safetensors") or
                        not safetensors_structure_valid(weights[0])):
                    return False
        if not ((base / "tokenizer" / "vocab.json").is_file() and
                (base / "tokenizer" / "merges.txt").is_file() and
                (adapter / "config.json").is_file() and
                (adapter / "diffusion_pytorch_model.fp16.safetensors").is_file() and
                safetensors_structure_valid(adapter / "diffusion_pytorch_model.fp16.safetensors")):
            return False
    elif kind in {"CogVideoXPipeline", "CogVideoXImageToVideoPipeline"}:
        for component in NATIVE_COMPONENTS:
            entry = info.get(component)
            if not isinstance(entry, list) or len(entry) != 2 or not all(isinstance(x, str) for x in entry):
                return False
            base = folder / component
            config_name = ("scheduler_config.json" if component == "scheduler" else
                           "tokenizer_config.json" if component == "tokenizer" else "config.json")
            if not (base / config_name).is_file():
                return False
            if component == "tokenizer" and not any(
                    (base / name).is_file() for name in
                    ("tokenizer.json", "spiece.model", "sentencepiece.bpe.model", "vocab.json", "vocab.txt")):
                return False
            if component in {"transformer", "vae", "text_encoder"}:
                weights = [item for item in base.rglob("*") if item.is_file() and
                           item.suffix.lower() in {".safetensors", ".bin"}]
                if not weights or not all(
                        safetensors_structure_valid(item) if item.suffix.lower() == ".safetensors"
                        else item.stat().st_size >= MODEL_CHECK_MIN_BYTES for item in weights):
                    return False
    else:
        return False
    for index_file in folder.rglob("*.index.json"):
        weight_map = read_json(index_file, {}).get("weight_map", {})
        if not isinstance(weight_map, dict) or not weight_map:
            return False
        for name in set(weight_map.values()):
            if not isinstance(name, str) or PurePosixPath(name).name != name:
                return False
            shard = index_file.parent / name
            if not shard.is_file() or shard.stat().st_size < MODEL_CHECK_MIN_BYTES:
                return False
    return True


def native_video_folder_complete(folder, deep=False):
    folder = Path(folder)
    if not native_component_layout_valid(folder):
        return False
    marker = read_json(folder / "download.json", {})
    if marker.get("kind") not in {"cogvideox", "animatediff"} or marker.get("complete") is not True:
        return False
    if (marker.get("kind") == "animatediff") != (
            read_json(folder / "model_index.json", {}).get("_class_name") == "AnimateDiffPipeline"):
        return False
    files = marker.get("files")
    hashes = marker.get("sha256")
    signatures = marker.get("integrity")
    if (not isinstance(files, dict) or not files or not isinstance(hashes, dict) or
            not isinstance(signatures, dict) or set(files) != set(hashes) or
            not set(signatures).issuperset({name for name in files if
                                             Path(name).suffix.lower() in {".bin", ".safetensors"}})):
        return False
    if set(files) != set(model_files_manifest(folder)):
        return False
    for relative, size in files.items():
        part = PurePosixPath(relative)
        if (not isinstance(relative, str) or part.is_absolute() or ".." in part.parts or
                not isinstance(size, int) or size <= 0 or
                not isinstance(hashes.get(relative), str) or
                not re.fullmatch(r"[0-9a-f]{64}", hashes[relative])):
            return False
        file = folder.joinpath(*part.parts)
        if not file.is_file() or file.stat().st_size != size:
            return False
        if relative in signatures and (not isinstance(signatures[relative], str) or
                                       file_integrity_hash(file) != signatures[relative]):
            return False
    if not full_hashes_verified(folder, hashes, force=deep):
        return False
    source = marker.get("source_metadata")
    if (not isinstance(source, dict) or source.get("repo") != marker.get("repo") or
            source.get("revision") != marker.get("revision") or
            source.get("origin") not in {"https://huggingface.co", "https://hf-mirror.com"} or
            (source.get("origin") != "https://huggingface.co" and
             source.get("verification_level") != "mirror_safetensors_sha256_requires_offline_smoke")):
        return False
    if any(file.suffix.lower() == ".bin" for file in folder.rglob("*.bin")):
        if not isinstance(source, dict) or not source.get("authoritative"):
            return False
        if not verify_remote_file_hashes(folder, source):
            return False
    if deep and source and not verify_remote_file_hashes(folder, source):
        return False
    return True


def native_video_model(root):
    folder = model_path(root, VIDEO_MODEL_FOLDER)
    if not native_video_folder_complete(folder):
        return None
    return folder, read_json(folder / "model_index.json", {})["_class_name"]


def native_model_signature(root):
    folder = model_path(root, VIDEO_MODEL_FOLDER)
    marker = read_json(folder / "download.json", {})
    paths = sorted((name, digest) for name, digest in marker.get("sha256", {}).items())
    return hashlib.sha256(json.dumps(paths, ensure_ascii=False).encode("utf-8")).hexdigest()


def native_load_ready(root):
    model = native_video_model(root)
    if model is None:
        return False
    marker = read_json(Path(root) / ".studio" / "native_ready.json", {})
    devices = gpu_info().get("devices", [])
    matching = any(item.get("name") == marker.get("gpu_name") and
                   abs(item.get("total_mb", 0) - marker.get("gpu_total_mb", 0)) <=
                   max(256, int(marker.get("gpu_total_mb", 0) * .04)) for item in devices)
    return bool(marker.get("runtime_version") == RUNTIME_VERSION and
                marker.get("python") == list(sys.version_info[:2]) and
                marker.get("model_signature") == native_model_signature(root) and
                marker.get("model_class") == model[1] and
                marker.get("offline_load") is True and matching)


def native_inference_ready(root):
    marker = read_json(Path(root) / ".studio" / "native_ready.json", {})
    return bool(native_load_ready(root) and marker.get("inference_tested") is True and
                marker.get("decode_tested") is True and marker.get("temporal_tested") is True and
                (marker.get("image_conditioned_tested") is True if
                 marker.get("model_class") in {"AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"} else True) and
                marker.get("frame_count", 0) >=
                max(NATIVE_SMOKE_FRAMES, int(marker.get("required_frames", NATIVE_SMOKE_FRAMES))))


def native_gpu_snapshot(root):
    marker = read_json(Path(root) / ".studio" / "native_ready.json", {})
    devices = gpu_info(root).get("devices", [])
    eligible = [item for item in devices if item.get("name") == marker.get("gpu_name") and
                abs(item.get("total_mb", 0) - marker.get("gpu_total_mb", 0)) <=
                max(256, int(marker.get("gpu_total_mb", 0) * .04))]
    selected = next((item for item in eligible if item["index"] == marker.get("gpu_index")), None)
    return selected or {}


def load_native_pipeline(root, gpu_index, image_conditioned=False):
    import torch
    from diffusers import (AnimateDiffPipeline, AnimateDiffVideoToVideoPipeline,
                           MotionAdapter, DDIMScheduler, CogVideoXPipeline,
                           CogVideoXImageToVideoPipeline)
    model = native_video_model(root)
    if model is None:
        raise RuntimeError("原生视频模型尚未完整下载并通过 SHA-256 验证")
    folder, model_class = model
    precision = native_model_precision(torch, gpu_index)
    if model_class == "AnimateDiffPipeline":
        adapter = MotionAdapter.from_pretrained(
            str(folder / "motion"), local_files_only=True, use_safetensors=True,
            variant="fp16", torch_dtype=precision)
        cls = AnimateDiffVideoToVideoPipeline if image_conditioned else AnimateDiffPipeline
        pipeline = cls.from_pretrained(
            str(folder / "base"), motion_adapter=adapter, local_files_only=True,
            use_safetensors=True, variant="fp16", safety_checker=None, feature_extractor=None,
            torch_dtype=precision)
        pipeline.scheduler = DDIMScheduler.from_config(
            pipeline.scheduler.config, beta_schedule="linear", clip_sample=False,
            steps_offset=1)
        pipeline.vae.enable_slicing()
        pipeline.vae.enable_tiling()
        if hasattr(pipeline.unet, "set_attention_slice"):
            pipeline.unet.set_attention_slice("auto")
        if hasattr(pipeline.unet, "enable_forward_chunking"):
            pipeline.unet.enable_forward_chunking(chunk_size=1, dim=1)
        pipeline.enable_sequential_cpu_offload(gpu_id=gpu_index)
    else:
        cls = CogVideoXImageToVideoPipeline if model_class == "CogVideoXImageToVideoPipeline" else CogVideoXPipeline
        pipeline = cls.from_pretrained(str(folder), local_files_only=True, torch_dtype=precision)
        pipeline.enable_model_cpu_offload(gpu_id=gpu_index)
        if hasattr(pipeline.vae, "enable_tiling"):
            pipeline.vae.enable_tiling()
    return pipeline, precision



def normalize_native_boundary(source, size):
    from PIL import Image, ImageFilter, ImageOps
    with Image.open(source) as photo:
        image = ImageOps.exif_transpose(photo).convert("RGB")
    backdrop = ImageOps.fit(image, size, method=Image.Resampling.LANCZOS)
    backdrop = backdrop.filter(ImageFilter.GaussianBlur(max(3, size[0] // 100)))
    foreground = ImageOps.contain(image, size, method=Image.Resampling.LANCZOS)
    backdrop.paste(foreground, ((size[0] - foreground.width) // 2,
                                (size[1] - foreground.height) // 2))
    return backdrop


def native_frame_boundary_transition(frames, first=None, last=None):
    from PIL import Image
    pictures = [image.convert("RGB") for image in frames]
    if not pictures:
        raise RuntimeError("原生视频未返回可用于边界过渡的图像帧")
    limit = max(1, min(len(pictures) // 3, round(BOUNDARY_BLEND_SECONDS * NATIVE_VIDEO_FPS)))
    if first is not None:
        head = first.convert("RGB").resize(pictures[0].size, Image.Resampling.LANCZOS)
        for index in range(limit + 1):
            ratio = index / max(1, limit)
            pictures[index] = Image.blend(head, pictures[index], ratio)
        pictures[0] = head
    if last is not None:
        tail = last.convert("RGB").resize(pictures[-1].size, Image.Resampling.LANCZOS)
        for offset in range(limit + 1):
            index = len(pictures) - 1 - offset
            ratio = 1 - offset / max(1, limit)
            pictures[index] = Image.blend(pictures[index], tail, ratio)
        pictures[-1] = tail
    return pictures


def native_frame_spread(frames):
    from PIL import ImageChops, ImageStat
    if len(frames) < 3:
        return 0.0
    samples = [frame.convert("L").resize((96, 64)) for frame in
               (frames[0], frames[len(frames) // 2], frames[-1])]
    return max(float(ImageStat.Stat(ImageChops.difference(a, b)).mean[0])
               for a, b in zip(samples, samples[1:]))

def native_segment_seed(prompt, output, segment_index):
    identity = "%s|%s|%d" % (str(prompt), Path(output).stem, int(segment_index))
    return int(hashlib.sha256(identity.encode("utf-8")).hexdigest()[:8], 16)


def cleanup_native_segments(output):
    path = Path(output)
    candidates = list(path.parent.glob(path.stem + "_part_*.mp4"))
    candidates.append(path.with_name(path.stem + "_parts.txt"))
    freed = 0
    removed = 0
    failures = []
    for candidate in candidates:
        if not candidate.is_file() or candidate.is_symlink():
            continue
        try:
            size = candidate.stat().st_size
            candidate.unlink()
            freed += size
            removed += 1
        except OSError as error:
            failures.append({"name": candidate.name, "error_type": type(error).__name__})
    return {"removed_files": removed, "freed_bytes": freed, "errors": failures[:20]}


def native_denoise_callback(governor, cancel=None, stage="native_denoise"):
    last_check = [0.0]
    gpu_streak = [0]
    def step_end(pipeline, step, timestep, tensors):
        if cancel is not None and cancel.is_set():
            raise InterruptedError("用户已停止原生视频推理")
        if governor is None or (step > 0 and
                time.monotonic() - last_check[0] < RESOURCE_MONITOR_INTERVAL):
            return tensors
        last_check[0] = time.monotonic()
        sample = governor.snapshot("%s_%d" % (stage, step))
        governor.adjust_cpu_threads(sample, stage)
        if governor.resource_stop_reason:
            raise RuntimeError("设备资源保护已启动：" + governor.resource_stop_reason)
        if sample["ram_total"] and sample["ram_available"] < max(
                512 * 1024 * 1024, int(sample["ram_total"] * .05)):
            raise RuntimeError("推理中可用内存不足，已保护其它软件并停止")
        if sample["disk_free"] is not None and sample["disk_free"] < MIN_JOB_FREE // 2:
            raise RuntimeError("推理中磁盘空间已低于安全余量")
        if sample["gpu_index"] is not None:
            gpu_streak[0] = gpu_streak[0] + 1 if sample["gpu_free"] < NATIVE_STEP_GPU_CRITICAL_BYTES else 0
            if gpu_streak[0] >= NATIVE_GPU_LOW_STREAK_LIMIT:
                raise RuntimeError("推理中空闲显存持续过低，已主动保护 GPU 资源")
        if sample.get("cpu_busy") is not None and sample["cpu_busy"] > RESOURCE_MONITOR_CPU_LIMIT:
            time.sleep(min(.05, RESOURCE_BUSY_POLL_SECONDS))
        return tensors
    return step_end


def native_pipeline_output(pipeline, model_class, prompt, width, height, count, steps,
                           reference=None, seed=None, governor=None, cancel=None, stage="native_denoise"):
    import torch
    from PIL import Image, ImageOps
    params = {"prompt": prompt[:600], "num_inference_steps": steps,
              "guidance_scale": 7.5 if model_class == "AnimateDiffPipeline" else 6.0,
              "height": height, "width": width}
    if seed is not None:
        params["generator"] = torch.Generator(device="cpu").manual_seed(int(seed))
    if model_class == "AnimateDiffPipeline":
        params["decode_chunk_size"] = 2
        if reference is None:
            params["num_frames"] = count
        else:
            conditioned = ImageOps.pad(reference, (width, height), method=Image.Resampling.LANCZOS)
            params["video"] = [conditioned.copy() for _ in range(count)]
            params["strength"] = .72
    else:
        params["num_frames"] = count
        if model_class == "CogVideoXImageToVideoPipeline":
            if reference is None:
                raise RuntimeError("当前原生图生视频模型缺少首帧输入")
            params["image"] = ImageOps.pad(reference, (width, height), method=Image.Resampling.LANCZOS,
                                           color=(12, 12, 12))
    import inspect
    if "callback_on_step_end" not in inspect.signature(pipeline.__call__).parameters:
        raise RuntimeError("原生视频生成管线缺少逐步资源与停止回调，拒绝无保护推理")
    params["callback_on_step_end"] = native_denoise_callback(governor, cancel, stage)
    params["callback_on_step_end_tensor_inputs"] = []
    with torch.inference_mode():
        frames = pipeline(**params).frames[0]
    if not isinstance(frames, (list, tuple)) or len(frames) != count:
        raise RuntimeError("原生生成没有返回全部要求的连续帧")
    return frames


def check_native_worker(root):
    configure_environment(root)
    os.environ.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "DIFFUSERS_OFFLINE": "1"})
    model = native_video_model(root)
    if not model or not native_video_folder_complete(model[0], deep=True):
        raise RuntimeError("原生模型未通过离线完整性与安全校验")
    import torch
    from diffusers.utils import export_to_video
    from PIL import Image, ImageDraw
    set_low_priority()
    gpu = select_torch_gpu(torch, NATIVE_VIDEO_MIN_FREE_MB * 1024 * 1024)
    if gpu is None:
        raise RuntimeError("NVIDIA GPU 可用显存不足，暂停原生视频推理验收")
    torch.cuda.set_device(gpu["index"])
    governor = ResourceGovernor(root)
    governor.attach_cuda(torch, gpu["index"])
    governor.attach_runtime(torch)
    governor.start_monitor()
    model_class = model[1]
    marker_file = Path(root) / ".studio" / "native_ready.json"
    count = max(NATIVE_SMOKE_FRAMES, 17)
    steps = NATIVE_PROBE_STEPS["animatediff" if model_class == "AnimateDiffPipeline" else "cogvideox"]
    marker = {"runtime_version": RUNTIME_VERSION, "python": list(sys.version_info[:2]),
              "model_signature": native_model_signature(root), "model_class": model_class,
              "gpu_name": gpu["name"], "gpu_total_mb": gpu["total_mb"],
              "gpu_index": gpu["index"], "offline_load": False,
              "inference_tested": False, "decode_tested": False,
              "temporal_tested": False, "image_conditioned_tested": False,
              "required_frames": count, "frame_count": 0,
              "probe_steps": steps, "checked": datetime.datetime.now().isoformat()}
    pipeline = None
    tmp = Path(root) / ".studio" / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    probe = tmp / "native_inference_probe.mp4"
    try:
        pipeline, precision = load_native_pipeline(root, gpu["index"])
        marker["offline_load"] = True
        marker["precision"] = str(precision)
        atomic_json(marker_file, marker)
        width, height = native_generation_resolution("横屏", gpu["free_bytes"], model_class, probe=True)
        probe_reference = None
        if model_class == "CogVideoXImageToVideoPipeline":
            probe_reference = Image.new("RGB", (width, height), (25, 38, 68))
            draw = ImageDraw.Draw(probe_reference)
            size = min(width, height) // 3
            draw.rectangle(((width - size) // 2, (height - size) // 2,
                            (width + size) // 2, (height + size) // 2), fill=(215, 46, 35))
        frames = native_pipeline_output(pipeline, model_class,
                                        "a red cube turning slowly, definite motion, fixed studio background",
                                        width, height, count, steps,
                                        reference=probe_reference, seed=1001,
                                        governor=governor, stage="native_acceptance")
        marker["temporal_spread"] = round(native_frame_spread(frames), 3)
        if marker["temporal_spread"] < MIN_NATIVE_TEMPORAL_DIFFERENCE:
            raise RuntimeError("原生视频测试帧缺乏可检测的时序变化")
        export_to_video(frames, str(probe), fps=NATIVE_VIDEO_FPS)
        if not probe.is_file() or probe.stat().st_size < 8192:
            raise RuntimeError("原生视频推理完成但编码异常")
        run_external([ffmpeg_executable(), "-hide_banner", "-loglevel", "error", "-xerror",
                      "-i", str(probe), "-f", "null", "-"], root,
                     timeout=120, env=shell_env(root, offline=True), capture=True)
        if model_class in {"AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"}:
            pipeline = None
            gc.collect()
            torch.cuda.empty_cache()
            pipeline, _ = load_native_pipeline(root, gpu["index"], image_conditioned=True)
            conditioned = native_pipeline_output(
                pipeline, model_class, "a red cube rotating gradually, continuous temporal motion",
                width, height, count, steps, reference=frames[0], seed=1002,
                governor=governor, stage="native_conditioned_acceptance")
            if native_frame_spread(conditioned) < MIN_NATIVE_TEMPORAL_DIFFERENCE:
                raise RuntimeError("原生图生视频实际推理缺乏有效时序变化")
            marker["image_conditioned_tested"] = True
        marker.update({"inference_tested": True, "decode_tested": True,
                       "temporal_tested": True, "frame_count": len(frames),
                       "smoke_status": REVIEW_PASS, "probe_resolution": [width, height]})
        atomic_json(marker_file, marker)
        print(json.dumps({"ok": True, "offline_load": True, "inference_tested": True,
                          "decode_tested": True, "temporal_tested": True,
                          "model_class": model_class}, ensure_ascii=False), flush=True)
    except (RuntimeError, MemoryError, OSError, ValueError, ImportError) as error:
        marker.update({"smoke_status": REVIEW_UNAVAILABLE,
                       "smoke_error_type": type(error).__name__,
                       "smoke_error_code": "RESOURCE_EXHAUSTED" if is_memory_error(error) else
                                           "NATIVE_INFERENCE_FAILED"})
        atomic_json(marker_file, marker)
        raise RuntimeError("原生视频离线实际推理、运动或解码验收未通过：" + str(error)[:300]) from error
    finally:
        governor.stop_monitor()
        marker["resource_report"] = governor.report()
        try:
            atomic_json(marker_file, marker)
        except OSError:
            pass
        probe.unlink(missing_ok=True)
        if pipeline is not None:
            del pipeline
        gc.collect()
        torch.cuda.empty_cache()


def model_signature(root, include_optional=False):
    entries = []
    for _, _, folder, _ in MODEL_SPECS:
        base = model_path(root, folder)
        for item in base.rglob("*"):
            if not item.is_file() or ".cache" in item.parts:
                continue
            if item.suffix.lower() not in {".json", ".txt", ".model", ".bin", ".safetensors"}:
                continue
            stat = item.stat()
            entries.append((folder, item.relative_to(base).as_posix(), stat.st_size, stat.st_mtime_ns))
    if include_optional:
        for role, folder in OPTIONAL_MODEL_FOLDERS.items():
            path = model_path(root, folder)
            if optional_model_verified(path, role):
                marker = read_json(path / "download.json", {})
                entries.append((folder, "verified_extra", marker.get("revision", ""),
                                len(marker.get("sha256", {}))))
        if native_video_model(root):
            entries.append((VIDEO_MODEL_FOLDER, "verified_native", native_model_signature(root), 1))
    return hashlib.sha256(json.dumps(sorted(entries)).encode("utf-8")).hexdigest()


def shell_env(root, offline=False, endpoint=None):
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    env["PYTHONUTF8"] = "1"
    env["PYTHONNOUSERSITE"] = "1"
    env["HF_HOME"] = str(Path(root) / ".studio" / "cache" / "hf")
    env["HF_HUB_CACHE"] = str(Path(root) / ".studio" / "cache" / "hf" / "hub")
    env["HF_XET_CACHE"] = str(Path(root) / ".studio" / "cache" / "hf" / "xet")
    env["TORCH_HOME"] = str(Path(root) / ".studio" / "cache" / "torch")
    env["PIP_CACHE_DIR"] = str(Path(root) / ".studio" / "cache" / "pip")
    env["TEMP"] = str(Path(root) / ".studio" / "tmp")
    env["TMP"] = str(Path(root) / ".studio" / "tmp")
    env["TMPDIR"] = str(Path(root) / ".studio" / "tmp")
    env["HF_HUB_DISABLE_TELEMETRY"] = "1"
    env["HF_HUB_DISABLE_XET"] = "1"
    env["TOKENIZERS_PARALLELISM"] = "false"
    if offline:
        env["HF_HUB_OFFLINE"] = "1"
        env["TRANSFORMERS_OFFLINE"] = "1"
        env["DIFFUSERS_OFFLINE"] = "1"
    else:
        for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "DIFFUSERS_OFFLINE"):
            env.pop(key, None)
    if endpoint:
        env["HF_ENDPOINT"] = endpoint
    return env


def is_ready(root):
    marker = read_json(Path(root) / ".studio" / "ready.json", {})
    if (not marker or marker.get("runtime_version") != RUNTIME_VERSION or not marker.get("smoke_test")
            or marker.get("python") != list(sys.version_info[:2]) or not models_complete(root)):
        return False
    if marker.get("model_signature") != model_signature(root):
        return False
    diagnostics = marker.get("diagnostic", {})
    if (not optional_ocr_ready(root) or
            diagnostics.get("instance_detector") != REVIEW_PASS or
            diagnostics.get("offline_pipeline", {}).get("status") != REVIEW_PASS or
            not diagnostics.get("offline_pipeline", {}).get("network_disabled") or
            diagnostics.get("offline_pipeline", {}).get("decoded_frames", 0) < DEFAULT_FPS):
        return False
    if not diagnostics.get("chinese_voice") or diagnostics.get("voice_backend") not in {"sapi", "piper"}:
        return False
    if not voice_backend_operational(root, diagnostics["voice_backend"]):
        return False
    if not runtime_matches_host(root):
        return False
    return packages_healthy(root, "full", diagnostics["voice_backend"] == "piper")




def capability_report(root, request=None):
    root = Path(root)
    basic = basic_ready(root)
    complete = bool(basic and is_ready(root))
    native_files = native_video_model(root) if complete else None
    native_loaded = bool(native_files and native_load_ready(root))
    native_verified = bool(native_loaded and native_inference_ready(root))
    gpu = native_gpu_snapshot(root) if native_files else {}
    native_available = bool(native_verified and gpu.get("free_mb", 0) >= NATIVE_VIDEO_MIN_FREE_MB)
    files = request.get("files", {}) if isinstance(request, dict) else {}
    visual_assets = any(files.get(item) for item in ("图片", "首帧", "尾帧", "视频"))
    native_requested = bool(request and
                            (str(request.get("visual_mode", "")).startswith("原生AI视频") or
                             explicit_native_requested(request.get("prompt", "")) or
                             requires_subject_motion(request.get("prompt", ""))))
    compatible, reason = native_input_compatibility(native_files[1] if native_files else None, request)
    return {"basic": bool(basic), "image_generation": complete,
            "offline_pipeline_verified": complete,
            "semantic_review": complete, "speech_review": complete,
            "ocr": optional_ocr_ready(root) if complete else False,
            "instance_counting": bool(complete),
            "native_video": native_available, "native_inference_verified": native_verified,
            "native_model_present": (model_path(root, VIDEO_MODEL_FOLDER) / "model_index.json").is_file(),
            "native_model_detected": bool(native_files), "native_load_verified": native_loaded,
            "native_model_class": native_files[1] if native_files else None,
            "native_input_compatible": bool(compatible), "native_input_reason": reason,
            "native_gpu_free_mb": gpu.get("free_mb", 0),
            "visual_assets": bool(visual_assets), "native_requested": native_requested,
            "create_allowed": complete, "offline": complete, "full_offline": complete,
            "review_level": "full" if complete else "dependencies_only" if basic else "unavailable"}


def native_preparation_state(root, request, capabilities=None):
    capabilities = capabilities or capability_report(root, request)
    if not capabilities.get("native_requested"):
        return {"ready": True, "prepare": False, "reason": ""}
    if capabilities.get("native_video") and capabilities.get("native_input_compatible"):
        return {"ready": True, "prepare": False, "reason": ""}
    gpu = gpu_info(root)
    free_ram = memory_info()
    image_inputs = any(request.get("files", {}).get(kind) for kind in ("图片", "首帧", "尾帧"))
    free_disk = shutil.disk_usage(root).free
    suitable = select_native_profile(gpu=gpu, ram=free_ram, needs_images=image_inputs)
    if suitable is None:
        choices = [p for p in NATIVE_MODEL_CATALOG if not image_inputs or
                   p["class"] in {"AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"}]
        if choices and int(gpu.get("total_mb", 0)) < min(p["min_gpu_mb"] for p in choices):
            why = "当前 NVIDIA 显卡总显存不足，无法满足原生时序视频最低模型要求"
        elif not choices:
            why = "可部署原生时序模型不支持当前首尾帧或图片输入"
        else:
            why = "原生时序视频所需的空闲显存或系统内存不足；关闭占用资源的程序后可重试"
        return {"ready": False, "prepare": False, "reason": why}
    present = native_video_model(root)
    if present and not capabilities.get("native_input_compatible") and suitable["class"] == present[1]:
        return {"ready": False, "prepare": False,
                "reason": "当前已安装原生模型的输入能力不匹配：" + capabilities.get("native_input_reason", "")}
    profile = select_native_profile(gpu=gpu, ram=free_ram, disk_free=free_disk, needs_images=image_inputs)
    cached = model_path(root, VIDEO_MODEL_FOLDER).with_name(VIDEO_MODEL_FOLDER + ".cached." + suitable["id"])
    if profile is None and not native_video_folder_complete(cached):
        return {"ready": False, "prepare": False,
                "reason": "原生视频模型下载及安全运行的剩余磁盘空间不足"}
    if system_power_state().get("on_battery") and profile is not None:
        return {"ready": False, "prepare": False,
                "reason": "当前电池供电，已暂停大型模型自动下载以保护设备"}
    if profile is not None:
        network = windows_network_cost()
        if network.get("known") and network.get("metered"):
            return {"ready": False, "prepare": False,
                    "reason": "当前网络按流量计费，已暂停大型模型下载以保护流量"}
    return {"ready": False, "prepare": True,
            "reason": "原生时序模型尚未完成离线推理验收，正在准备或等待验证"}


def request_preflight(root, request, capabilities=None, deep_voice=False):
    capabilities = capabilities or capability_report(root, request)
    if not request.get("prompt", "").strip():
        return {"ready": False, "prepare": False, "reason": "创作提示词为空"}
    lost = [str(item) for paths in request.get("files", {}).values()
            for item in paths if not Path(item).is_file()]
    if lost and find_resumable_job(root, request) is None:
        return {"ready": False, "prepare": False,
                "reason": "输入素材已丢失或无法读取：" + "、".join(Path(n).name for n in lost[:4])}
    policies = media_preferences(request.get("prompt", ""))
    if policies["narration_policy"] == "required" and policies.get("voice_language") == "en":
        if not voice_language_operational(root, "en", force=deep_voice):
            return {"ready": False, "prepare": False,
                    "reason": "用户明确要求英语旁白，但本机没有通过实际发声检测的离线英语语音；请安装可用的 Windows 英语语音"}
    if not capabilities.get("create_allowed"):
        return {"ready": False, "prepare": True,
                "reason": "完整离线绘图及审校组件尚未通过验收"}
    native = native_preparation_state(root, request, capabilities)
    if not native["ready"]:
        return native
    return {"ready": True, "prepare": False, "reason": ""}


def require_request_capabilities(root, request):
    capabilities = capability_report(root, request)
    if not capabilities["create_allowed"]:
        if not capabilities["basic"]:
            raise RuntimeError("基础离线分镜、配音和视频编码尚未通过验收，请完成基础部署")
        raise RuntimeError("完整离线图像生成及 AI 审校尚未验收；请等待扩展组件安装完成")
    preflight = request_preflight(root, request, capabilities, deep_voice=True)
    if not preflight["ready"]:
        raise RuntimeError(preflight["reason"])
    return capabilities


def available_threads():
    logical = os.cpu_count() or 2
    memory = memory_info()["available"]
    limit = max(1, logical - max(1, logical // 3))
    if 0 < memory < 4 * GB:
        limit = min(limit, 2)
    elif 0 < memory < 8 * GB:
        limit = min(limit, 4)
    return max(1, min(8, limit))


def stop_process_tree(proc):
    if proc.poll() is not None:
        return
    if os.name == "nt":
        try:
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                           capture_output=True, timeout=6, creationflags=subprocess.CREATE_NO_WINDOW)
        except (OSError, subprocess.TimeoutExpired):
            pass
    if proc.poll() is None:
        try:
            proc.terminate()
            proc.wait(timeout=2)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()


def run_external(args, root, log=None, cancel=None, timeout=None, env=None, capture=False,
                 on_line=None, stop_file=None, stop_grace=0):
    flags = (subprocess.CREATE_NO_WINDOW | 0x00004000) if os.name == "nt" else 0
    args = list(args)
    if (args and "ffmpeg" in Path(str(args[0])).name.lower() and "-threads" not in args):
        cores = max(1, os.cpu_count() or 1)
        budget_threads = max(1, min(available_threads(), int(cores * RESOURCE_MAX_CPU_SHARE)))
        args[1:1] = ["-threads", str(budget_threads), "-filter_threads", str(budget_threads)]
    if log:
        log("命令类别：" + Path(str(args[0])).name + " · " + " ".join(str(arg) for arg in args[1:3])[:110])
    started = time.monotonic()
    audit = {"tool": Path(str(args[0])).name, "purpose": str(args[1])[:75] if len(args) > 1 else "",
             "started": datetime.datetime.now().isoformat(), "timeout": timeout,
             "status": "started", "returncode": None}
    proc = subprocess.Popen([str(arg) for arg in args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL, bufsize=1, text=True, encoding="utf-8", errors="replace",
                            env=env or shell_env(root), creationflags=flags, cwd=str(root))
    with RUNNING_CHILDREN_LOCK:
        RUNNING_CHILDREN.add(proc)
    output = []
    tail = deque(maxlen=EXTERNAL_ERROR_LINES)
    pending = queue.Queue(maxsize=EXTERNAL_OUTPUT_QUEUE)
    completed = threading.Event()
    abandoned = threading.Event()
    def reader():
        try:
            for message in proc.stdout:
                if abandoned.is_set():
                    break
                while not abandoned.is_set():
                    try:
                        pending.put(message, timeout=.1)
                        break
                    except queue.Full:
                        if proc.poll() is not None and abandoned.is_set():
                            break
        except (OSError, ValueError):
            pass
        finally:
            completed.set()
    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    stopping = None
    try:
        while True:
            if cancel is not None and cancel.is_set():
                if stop_file is not None and stopping is None:
                    Path(stop_file).touch()
                    stopping = time.monotonic()
                if stopping is None or time.monotonic() - stopping >= stop_grace:
                    stop_process_tree(proc)
                    raise InterruptedError("已停止，已保存已完成的检查点")
            if timeout and time.monotonic() - started > timeout:
                stop_process_tree(proc)
                raise TimeoutError("外部进程运行超时")
            try:
                line = pending.get(timeout=.16).rstrip()
            except queue.Empty:
                if proc.poll() is not None and completed.is_set() and pending.empty():
                    break
                continue
            if line:
                if not line.startswith(PROGRESS_PREFIX):
                    tail.append(line)
                if on_line:
                    on_line(line)
                if log:
                    log(line)
                if capture:
                    output.append(line)
                    if len(output) > 1200:
                        output = output[-800:]
        code = proc.wait()
        audit["returncode"] = code
        if stopping is not None:
            raise InterruptedError("已停止，已保存已完成的检查点")
        if code:
            raise RuntimeError("命令失败（退出码 %s）：%s" % (code, " | ".join(tail)))
        return "\n".join(output)
    finally:
        abandoned.set()
        if proc.poll() is None:
            stop_process_tree(proc)
        if proc.stdout is not None:
            try:
                proc.stdout.close()
            except OSError:
                pass
        try:
            proc.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            pass
        thread.join(timeout=2)
        audit["elapsed_seconds"] = round(time.monotonic() - started, 3)
        audit["returncode"] = proc.returncode
        audit["status"] = "completed" if proc.returncode == 0 else "interrupted_or_failed"
        audit["last_output"] = " | ".join(list(tail)[-3:])[-500:]
        with EXTERNAL_COMMAND_LOCK:
            EXTERNAL_COMMAND_EVENTS.append(dict(audit))
            try:
                history = Path(root) / ".studio" / "logs" / "process_events.jsonl"
                history.parent.mkdir(parents=True, exist_ok=True)
                if history.is_file() and history.stat().st_size > 5 * 1024 * 1024:
                    history.replace(history.with_suffix(".previous.jsonl"))
                with history.open("a", encoding="utf-8") as audit_file:
                    audit_file.write(json.dumps(audit, ensure_ascii=False) + "\n")
            except OSError:
                pass
        with RUNNING_CHILDREN_LOCK:
            RUNNING_CHILDREN.discard(proc)

def probe_url(url, timeout=4):
    started = time.monotonic()
    for method in ("HEAD", "GET"):
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json, */*"}
        if method == "GET":
            headers["Range"] = "bytes=0-511"
        try:
            req = urllib.request.Request(url, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                if method == "GET":
                    response.read(512)
            return time.monotonic() - started
        except (OSError, urllib.error.URLError, ValueError):
            continue
    return float("inf")


def download_disk_budget(root, folder, reserve=MIN_DISK_DOWNLOAD_RESERVE, source_metadata=None):
    root = Path(root)
    expected = MODEL_SIZE_ESTIMATES.get(folder, GB)
    if isinstance(source_metadata, dict):
        sizes = source_metadata.get("sizes", {})
        if isinstance(sizes, dict) and sizes:
            expected = sum(int(value) for name, value in sizes.items()
                           if isinstance(value, int) and value >= 0 and
                           Path(name).suffix.lower() in MODEL_INTEGRITY_EXTENSIONS)
            expected = max(MODEL_CHECK_MIN_BYTES, expected)
    existing = 0
    for dirname in (folder, folder + ".downloading"):
        path = model_path(root, dirname)
        if path.is_dir():
            existing = max(existing, sum(file.stat().st_size for file in path.rglob("*") if file.is_file()))
    remaining = max(0, expected - existing)
    needed = reserve + int(remaining * DOWNLOAD_SPACE_MULTIPLIER)
    free = shutil.disk_usage(root).free
    if free < needed:
        raise RuntimeError("下载前空间检查未通过：%s 预计至少需要 %.2f GB 可用空间（当前 %.2f GB），请更换工作目录或清理磁盘" % (
            folder, needed / GB, free / GB))
    return {"estimated_remaining": remaining, "required_free": needed, "current_free": free}


def choose_endpoints():
    possibilities = ("https://hf-mirror.com", "https://huggingface.co")
    values = {}
    threads = []
    def measure(base):
        values[base] = probe_url(base + "/api/models/openai/whisper-tiny")
    for item in possibilities:
        thread = threading.Thread(target=measure, args=(item,), daemon=True)
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join(5)
    return sorted(possibilities, key=lambda item: values.get(item, float("inf")))


def download_model_worker(root, index, endpoint, deep=False):
    configure_environment(root)
    os.environ["HF_ENDPOINT"] = endpoint
    os.environ["HF_HUB_OFFLINE"] = "0"
    from huggingface_hub import snapshot_download
    spec = MODEL_SPECS[int(index)]
    target = model_path(root, spec[2])
    staging = target.with_name(target.name + ".downloading")
    if model_folder_complete(target, spec, deep=deep):
        return
    download_disk_budget(root, spec[2])
    if target.exists() and not staging.exists():
        target.replace(staging)
    staging.mkdir(parents=True, exist_ok=True)
    if model_folder_complete(staging, spec, deep=deep):
        if target.exists():
            shutil.rmtree(target)
        staging.replace(target)
        return
    revision = MODEL_REVISIONS[spec[1]]
    previous = read_json(staging / "download.json", {})
    if previous.get("repo") == spec[1] and previous.get("revision") == revision:
        remove_corrupt_model_files(staging, previous)
    elif previous:
        shutil.rmtree(staging)
        staging.mkdir(parents=True, exist_ok=True)
    source_metadata = official_model_metadata(spec[1], revision, endpoint)
    download_disk_budget(root, spec[2], source_metadata=source_metadata)
    snapshot_download(repo_id=spec[1], revision=revision, local_dir=str(staging), allow_patterns=list(spec[3]),
                      max_workers=max(1, min(MAX_MODEL_DOWNLOAD_WORKERS, available_threads())))
    if not pinned_model_weights_valid(staging, spec[1], deep=True):
        raise RuntimeError("固定版本模型权重与程序内置可信 SHA-256 不符，拒绝执行不可信权重")
    if not source_metadata.get("authoritative"):
        print("当前使用内置权重哈希模式，配置文件来源无法独立证明，之后必须通过模型加载与实际生成验收", flush=True)
    if not verify_remote_file_hashes(staging, source_metadata):
        raise RuntimeError("模型权重和固定提交的远程 SHA 摘要不一致，已拒绝使用")
    if not folder_has_weights(staging):
        raise RuntimeError("模型文件未完整保存：" + spec[1])
    for item in staging.rglob("*.index.json"):
        weights = read_json(item, {}).get("weight_map")
        if not isinstance(weights, dict) or not weights or any(
                not (item.parent / part).is_file() for part in weights.values()):
            raise RuntimeError("模型缺少权重分片：" + str(item))
    manifest = model_files_manifest(staging)
    if not manifest:
        raise RuntimeError("模型下载结果为空：" + spec[1])
    atomic_json(staging / "download.json", {"repo": spec[1], "revision": revision, "endpoint": endpoint,
                                           "completed": now_stamp(), "complete": True,
                                           "files": manifest,
                                           "integrity": model_integrity_manifest(staging),
                                           "sha256": model_full_sha256_manifest(staging),
                                           "source_metadata": source_metadata})
    if not model_folder_complete(staging, spec, deep=True):
        raise RuntimeError("模型下载后的完整 SHA-256 校验未通过：" + spec[1])
    if target.exists():
        shutil.rmtree(target)
    staging.replace(target)


def download_optional_model_worker(root, role, endpoint):
    configure_environment(root)
    os.environ["HF_ENDPOINT"] = endpoint
    os.environ["HF_HUB_OFFLINE"] = "0"
    from huggingface_hub import snapshot_download
    selection = next((item for item in OPTIONAL_MODEL_CATALOG if item["role"] == role), None)
    if selection is None:
        raise RuntimeError("未知可选模型类别：" + str(role))
    repo = selection["repo"]
    revision = OPTIONAL_MODEL_REVISIONS[repo]
    provenance = optional_trusted_provenance(repo)
    target = model_path(root, OPTIONAL_MODEL_FOLDERS[role])
    if optional_model_verified(target, role):
        return
    estimate = selection["download_estimate"]
    free = shutil.disk_usage(root).free
    if free < MIN_JOB_FREE + MIN_INSTALL_FREE + int(estimate * DOWNLOAD_SPACE_MULTIPLIER):
        raise RuntimeError("高阶模型下载空间不足，当前基础离线模型不受影响")
    staging = target.with_name(target.name + ".downloading")
    previous = read_json(staging / "download.json", {})
    if previous and (previous.get("revision") != revision or previous.get("repo") != repo):
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)
    if previous.get("revision") == revision and previous.get("repo") == repo:
        remove_corrupt_model_files(staging, previous)
    snapshot_download(repo_id=repo, revision=revision, local_dir=str(staging),
                      allow_patterns=list(OPTIONAL_ROLE_PATTERNS[role]), max_workers=1)
    if not folder_has_weights(staging):
        raise RuntimeError("高阶模型权重文件未完整下载")
    required_config = "model_index.json" if role == "painter" else "config.json"
    if not (staging / required_config).is_file():
        raise RuntimeError("高阶模型缺少可加载的模型配置")
    for index in staging.rglob("*.index.json"):
        mapping = read_json(index, {}).get("weight_map", {})
        if not isinstance(mapping, dict) or not mapping or any(
                not (index.parent / name).is_file() for name in mapping.values()):
            raise RuntimeError("高阶模型权重分片不完整")
    if not optional_weights_verified(staging, repo):
        raise RuntimeError("高阶模型权重未通过内置可信 SHA-256 校验，拒绝安装")
    marker = {"role": role, "repo": repo, "revision": revision,
              "source_metadata": provenance, "complete": True, "at": now_stamp(),
              "files": model_files_manifest(staging),
              "integrity": model_integrity_manifest(staging),
              "sha256": model_full_sha256_manifest(staging)}
    atomic_json(staging / "download.json", marker)
    if not optional_model_verified(staging, role, deep=True):
        raise RuntimeError("高阶模型完整性验证失败，不启用")
    if target.exists():
        shutil.rmtree(target)
    staging.replace(target)


def native_repo_relative_path(name):
    name = str(name)
    relative = PurePosixPath(name)
    if (not name or len(name) > 512 or relative.is_absolute() or
            ".." in relative.parts or any(not part or part == "." or
            part.split(".")[0].upper() in {"CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3",
                                             "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
                                             "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6",
                                             "LPT7", "LPT8", "LPT9"} for part in name.split("/")) or
            any(char in name for char in '<>:"\\|?*') or
            any(ord(char) < 32 for char in name)):
        raise RuntimeError("原生模型文件路径不符合 Windows 安全要求：" + name[:120])
    if relative.suffix.lower() not in MODEL_DOWNLOAD_SECURITY_SUFFIXES:
        raise RuntimeError("原生模型文件类型不允许：" + name[:120])
    return relative


def native_download_metadata(endpoint, repo=NATIVE_AUTO_REPO):
    from huggingface_hub import HfApi
    errors = []
    for server in dict.fromkeys(("https://huggingface.co", endpoint)):
        try:
            info = HfApi(endpoint=server).model_info(repo_id=repo,
                                                      files_metadata=True, timeout=SOURCE_METADATA_TIMEOUT)
            revision = str(info.sha)
            if not re.fullmatch(r"[0-9a-f]{40}", revision):
                raise RuntimeError("模型仓库未提供合法的提交 SHA")
            hashes, sizes, files = {}, {}, []
            for sibling in info.siblings:
                name = str(sibling.rfilename)
                if PurePosixPath(name).suffix.lower() not in MODEL_DOWNLOAD_SECURITY_SUFFIXES:
                    continue
                native_repo_relative_path(name)
                files.append(name)
                size = getattr(sibling, "size", None)
                if isinstance(size, int) and size > 0:
                    sizes[name] = size
                lfs = getattr(sibling, "lfs", None)
                digest = lfs.get("sha256") if isinstance(lfs, dict) else None
                if isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest):
                    hashes[name] = {"type": "sha256", "value": digest}
                else:
                    blob = getattr(sibling, "blob_id", None)
                    if isinstance(blob, str) and re.fullmatch(r"[0-9a-f]{40}", blob):
                        hashes[name] = {"type": "git-sha1", "value": blob}
            if not files or any(name not in hashes for name in files):
                raise RuntimeError("模型文件缺少可信的官方或镜像摘要")
            metadata = {"repo": repo, "revision": revision,
                        "origin": server, "authoritative": server == "https://huggingface.co",
                        "verification_level": ("official_lfs_sha256" if server == "https://huggingface.co"
                                               else "mirror_safetensors_sha256_requires_offline_smoke"),
                        "hashes": hashes, "sizes": sizes}
            if server != "https://huggingface.co":
                metadata["official_errors"] = errors[-2:]
            return files, metadata
        except (OSError, RuntimeError, ValueError, TypeError, AttributeError, urllib.error.URLError) as error:
            errors.append("%s: %s" % (server, str(error)[:160]))
    raise RuntimeError("原生模型官方与镜像元数据均无法验证：" + " / ".join(errors))


def native_repository_file_selection(profile, repo, names):
    names = set(names)
    if profile["kind"] == "cogvideox":
        selected = sorted(names)
    elif repo == NATIVE_BASE_REPO:
        selected = sorted(name for name in names if
                          name == "model_index.json" or
                          name.startswith(("scheduler/", "tokenizer/")) or
                          (name.startswith(("unet/", "vae/", "text_encoder/")) and
                           (name.endswith("config.json") or name.endswith(".fp16.safetensors"))))
    elif repo == NATIVE_MOTION_REPO:
        selected = [name for name in ("config.json", "diffusion_pytorch_model.fp16.safetensors")
                    if name in names]
    else:
        raise RuntimeError("未知的原生视频模型仓库")
    if (not selected or not any(name.endswith(".safetensors") for name in selected) or
            profile["kind"] == "animatediff" and repo == NATIVE_BASE_REPO and
            not {"model_index.json", "unet/config.json", "vae/config.json", "text_encoder/config.json",
                 "tokenizer/tokenizer_config.json", "scheduler/scheduler_config.json",
                 "unet/diffusion_pytorch_model.fp16.safetensors", "vae/diffusion_pytorch_model.fp16.safetensors",
                 "text_encoder/model.fp16.safetensors"}.issubset(selected) or
            profile["kind"] == "animatediff" and repo == NATIVE_MOTION_REPO and len(selected) != 2):
        raise RuntimeError("原生模型缺少所需的 safetensors 组件，拒绝下载不完整或不安全的权重")
    return selected


def native_file_hash_matches(path, record):
    if not path.is_file() or not isinstance(record, dict):
        return False
    kind = record.get("type")
    expected = record.get("value")
    if kind == "sha256":
        return bool(expected and secrets.compare_digest(full_file_sha256(path), expected))
    if kind == "git-sha1":
        return bool(expected and secrets.compare_digest(git_blob_sha1(path), expected))
    return False


def download_native_file(staging, endpoint, revision, name, metadata, throttle,
                         repo=NATIVE_AUTO_REPO, prefix=""):
    relative = native_repo_relative_path(name)
    destination = (PurePosixPath(prefix) / relative) if prefix else relative
    target = Path(staging).joinpath(*destination.parts)
    target.parent.mkdir(parents=True, exist_ok=True)
    entry = metadata.get("hashes", {}).get(name, {})
    expected_size = int(metadata.get("sizes", {}).get(name, 0))
    if target.is_file() and (not expected_size or target.stat().st_size == expected_size):
        if native_file_hash_matches(target, entry):
            return
        target.unlink()
    partial = target.with_name(target.name + ".partial")
    existing = partial.stat().st_size if partial.is_file() else 0
    if expected_size and existing > expected_size:
        partial.unlink()
        existing = 0
    if expected_size and existing == expected_size and native_file_hash_matches(partial, entry):
        os.replace(partial, target)
        return
    url = (endpoint.rstrip("/") + "/" + repo + "/resolve/" +
           urllib.parse.quote(revision, safe="") + "/" +
           urllib.parse.quote(str(relative), safe="/"))
    headers = {"User-Agent": "Offline-AI-Video/" + APP_VERSION,
               "Accept-Encoding": "identity"}
    if existing:
        headers["Range"] = "bytes=%d-" % existing
    request = urllib.request.Request(url, headers=headers)
    try:
        response = urllib.request.urlopen(request, timeout=45)
    except urllib.error.HTTPError as error:
        if error.code == 416 and existing:
            partial.unlink(missing_ok=True)
            return download_native_file(staging, endpoint, revision, name, metadata, throttle,
                                        repo=repo, prefix=prefix)
        raise
    with response:
        status = response.getcode()
        if status not in (200, 206):
            raise RuntimeError("原生模型下载返回异常 HTTP %s：%s" % (status, name))
        if status == 206:
            reported = str(response.headers.get("Content-Range", ""))
            if not reported.startswith("bytes %d-" % existing):
                raise RuntimeError("断点续传响应范围不匹配：" + name)
        elif existing:
            existing = 0
        mode = "ab" if existing else "wb"
        received = existing
        ceiling = expected_size or NATIVE_DOWNLOAD_FILE_LIMIT
        with partial.open(mode) as output:
            while True:
                chunk = response.read(NATIVE_DOWNLOAD_CHUNK_BYTES)
                if not chunk:
                    break
                received += len(chunk)
                if received > ceiling:
                    raise RuntimeError("原生模型下载体积超过可信元数据声明：" + name)
                output.write(chunk)
                throttle["bytes"] += len(chunk)
                delay = (throttle["bytes"] / throttle["limit"] -
                         (time.monotonic() - throttle["started"]))
                if delay > 0:
                    time.sleep(min(delay, 1.0))
    if expected_size and partial.stat().st_size != expected_size:
        raise RuntimeError("下载不完整，保留断点以供下次重试：" + name)
    if not native_file_hash_matches(partial, entry):
        partial.unlink(missing_ok=True)
        raise RuntimeError("原生模型文件摘要不匹配，已移除损坏的部分：" + name)
    os.replace(partial, target)
    print("模型文件已验证：%s (%.2f GB)" % (name, target.stat().st_size / GB), flush=True)


def download_native_worker(root, endpoint, profile_id=None):
    configure_environment(root)
    os.environ["HF_ENDPOINT"] = endpoint
    os.environ["HF_HUB_OFFLINE"] = "0"
    target = model_path(root, VIDEO_MODEL_FOLDER)
    active_manifest = read_json(target / "download.json", {})
    if (native_video_folder_complete(target) and
            (profile_id is None or active_manifest.get("profile_id") == profile_id)):
        return
    available = shutil.disk_usage(root).free
    profile = select_native_profile(disk_free=available, profile_id=profile_id)
    if profile is None:
        profile = select_native_profile(profile_id=profile_id)
        if profile is None:
            raise RuntimeError("当前硬件或内存无法运行所需的原生视频模型")
    backup = target.with_name(target.name + ".cached." + profile["id"])
    if native_video_folder_complete(backup):
        if target.exists():
            active_id = active_manifest.get("profile_id")
            preserved = target.with_name(target.name + ".cached." + str(active_id or "legacy"))
            if preserved.exists():
                shutil.rmtree(preserved)
            target.replace(preserved)
        try:
            backup.replace(target)
        except BaseException:
            if not target.exists() and active_manifest.get("profile_id"):
                preserved = target.with_name(target.name + ".cached." + active_manifest["profile_id"])
                if preserved.exists():
                    preserved.replace(target)
            raise
        (Path(root) / ".studio" / "native_ready.json").unlink(missing_ok=True)
        return
    minimum_disk = (NATIVE_AUTO_DISK_RESERVE + MIN_INSTALL_FREE +
                    math.ceil(profile["estimated_download_bytes"] * DOWNLOAD_SPACE_MULTIPLIER))
    if available < minimum_disk:
        raise RuntimeError("切换原生视频模型需要保留旧模型并下载新模型，当前空间不足")
    staging = target.with_name(target.name + ".downloading")
    marker = read_json(staging / "download.json", {})
    if marker and marker.get("profile_id") != profile["id"]:
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)
    jobs, total_bytes, fingerprints = [], 0, []
    combined_hashes, combined_sizes = {}, {}
    authoritative = True
    for repo, prefix in profile["repos"]:
        available, metadata = native_download_metadata(endpoint, repo)
        selected = native_repository_file_selection(profile, repo, available)
        authoritative = authoritative and metadata.get("authoritative", False)
        fingerprints.append((repo, metadata["revision"]))
        for name in selected:
            local_name = str(PurePosixPath(prefix) / name) if prefix else name
            combined_hashes[local_name] = metadata["hashes"][name]
            size = metadata["sizes"].get(name)
            if isinstance(size, int):
                combined_sizes[local_name] = size
                total_bytes += size
            if name.endswith(".safetensors") and (
                    metadata["hashes"][name].get("type") != "sha256" or
                    not isinstance(size, int) or size < MODEL_CHECK_MIN_BYTES):
                raise RuntimeError("原生视频权重缺少可验证的 SHA-256 和大小：" + name)
        jobs.append((repo, prefix, selected, metadata))
    revision = hashlib.sha256(json.dumps(fingerprints).encode("utf-8")).hexdigest()
    previous = read_json(staging / "download.json", {})
    if previous and previous.get("revision") != revision:
        shutil.rmtree(staging)
        staging.mkdir(parents=True, exist_ok=True)
    existing = 0
    for relative, size in combined_sizes.items():
        file = staging / relative
        partial = file.with_name(file.name + ".partial")
        existing += min(size, max(file.stat().st_size if file.is_file() else 0,
                                  partial.stat().st_size if partial.is_file() else 0))
    necessary = NATIVE_AUTO_DISK_RESERVE + int(max(0, total_bytes - existing) * DOWNLOAD_SPACE_MULTIPLIER)
    available_bytes = shutil.disk_usage(root).free
    if available_bytes < necessary:
        raise RuntimeError("原生视频模型需要 %.1f GB 空闲空间，目前只有 %.1f GB" % (
            necessary / GB, available_bytes / GB))
    print("智能选择原生时序生成模型：%s；待下载 %.2f GB" % (
        profile["id"], max(0, total_bytes - existing) / GB), flush=True)
    throttle = {"started": time.monotonic(), "bytes": 0,
                "limit": max(NATIVE_BACKGROUND_BANDWIDTH_BYTES, int(available_threads() * 1024 * 1024))}
    for repo, prefix, selected, metadata in jobs:
        for name in selected:
            download_native_file(staging, endpoint, metadata["revision"], name, metadata, throttle,
                                 repo=repo, prefix=prefix)
    if profile["kind"] == "animatediff":
        atomic_json(staging / "model_index.json", {"_class_name": "AnimateDiffPipeline",
                                                  "_profile_id": profile["id"]})
    if not native_component_layout_valid(staging):
        raise RuntimeError("原生视频模型缺少必要的运行组件或安全权重")
    provenance = {"repo": "+".join(repo for repo, _ in fingerprints), "revision": revision,
                  "origin": "https://huggingface.co" if authoritative else "https://hf-mirror.com",
                  "authoritative": authoritative,
                  "verification_level": ("official_lfs_sha256" if authoritative
                                         else "mirror_safetensors_sha256_requires_offline_smoke"),
                  "repositories": [{"repo": repo, "revision": rev} for repo, rev in fingerprints],
                  "hashes": combined_hashes, "sizes": combined_sizes}
    if not verify_remote_file_hashes(staging, provenance):
        raise RuntimeError("原生模型文件与锁定提交的权威摘要不符")
    manifest = model_files_manifest(staging)
    atomic_json(staging / "download.json", {
        "kind": profile["kind"], "profile_id": profile["id"], "complete": True,
        "repo": provenance["repo"], "revision": revision, "files": manifest,
        "sha256": model_full_sha256_manifest(staging),
        "integrity": model_integrity_manifest(staging),
        "source_metadata": provenance, "completed": now_stamp()})
    if not native_video_folder_complete(staging, deep=True):
        raise RuntimeError("原生模型完整性验收失败，未激活该模型")
    prior_id = active_manifest.get("profile_id")
    preserved = target.with_name(target.name + ".cached." + str(prior_id or "legacy"))
    if target.exists():
        if preserved.exists():
            shutil.rmtree(preserved)
        target.replace(preserved)
    try:
        staging.replace(target)
    except BaseException:
        if not target.exists() and preserved.exists():
            preserved.replace(target)
        raise
    (Path(root) / ".studio" / "native_ready.json").unlink(missing_ok=True)


def download_voice_worker(root, endpoint):
    configure_environment(root)
    os.environ["HF_ENDPOINT"] = endpoint
    os.environ["HF_HUB_OFFLINE"] = "0"
    from huggingface_hub import hf_hub_download
    corrupt = voice_model_ready(root) and not voice_download_complete(root, deep=True)
    download_disk_budget(root, "voice")
    base = model_path(root, "voice")
    for file in (VOICE_FILE, VOICE_FILE + ".json"):
        hf_hub_download(repo_id=VOICE_REPO, filename=file, revision=VOICE_REVISION,
                        local_dir=str(base), force_download=corrupt)
    if not voice_model_ready(root):
        raise RuntimeError("中文离线语音模型缺失或配置无效")
    digest = hashlib.sha256()
    with voice_model_path(root).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != VOICE_SHA256:
        raise RuntimeError("中文语音模型校验失败，请重试下载")
    atomic_json(base / "download.json", {"repo": VOICE_REPO, "revision": VOICE_REVISION,
                                         "completed": now_stamp(), "sha256": digest.hexdigest(),
                                         "endpoint": endpoint, "sample_hash": file_integrity_hash(voice_model_path(root))})


def piper_speak_worker(root, text_path, output):
    configure_environment(root)
    os.environ["HF_HUB_OFFLINE"] = "1"
    if not voice_download_complete(root):
        raise RuntimeError("中文离线语音模型或拼音资源不完整")
    from piper import PiperVoice
    text = Path(text_path).read_text(encoding="utf-8-sig").strip()
    if not text:
        raise RuntimeError("中文旁白文本为空")
    voice = PiperVoice.load(str(voice_model_path(root)), use_cuda=False)
    with wave.open(str(output), "wb") as writer:
        voice.synthesize_wav(text, writer)
    if audio_seconds(output) < .15:
        raise RuntimeError("中文离线语音未产生有效声音")


def piper_server_worker(root):
    configure_environment(root)
    os.environ["HF_HUB_OFFLINE"] = "1"
    if not voice_download_complete(root):
        raise RuntimeError("本地中文语音模型尚未验收")
    from piper import PiperVoice
    voice = PiperVoice.load(str(voice_model_path(root)), use_cuda=False)
    print("PIPER_RESPONSE:" + json.dumps({"ready": True}), flush=True)
    for line in sys.stdin:
        try:
            command = json.loads(line)
            if command.get("command") == "close":
                break
            input_path = Path(command["text_path"])
            output = Path(command["output"])
            text = input_path.read_text(encoding="utf-8-sig").strip()
            if not text:
                raise ValueError("旁白不能为空")
            output.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(output), "wb") as writer:
                voice.synthesize_wav(text, writer)
            if audio_seconds(output) < .15:
                raise RuntimeError("语音合成未产生有效声音")
            data = {"ok": True, "output": str(output)}
        except Exception as error:
            data = {"ok": False, "error": str(error)[:500], "type": type(error).__name__}
        print("PIPER_RESPONSE:" + json.dumps(data, ensure_ascii=False), flush=True)


class PersistentPiper:
    def __init__(self, root, cancel, log):
        self.root = Path(root)
        self.cancel = cancel
        self.log = log
        self.responses = queue.Queue()
        self.finished = threading.Event()
        flags = (subprocess.CREATE_NO_WINDOW | 0x00004000) if os.name == "nt" else 0
        self.proc = subprocess.Popen([str(runtime_python(root)), "-u", str(Path(__file__).resolve()),
                                      "--speak-server", str(root)], cwd=str(root),
                                     env=shell_env(root, offline=True), stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     encoding="utf-8", errors="replace", bufsize=1, creationflags=flags)
        with RUNNING_CHILDREN_LOCK:
            RUNNING_CHILDREN.add(self.proc)
        def reader():
            try:
                for line in self.proc.stdout:
                    if line.startswith("PIPER_RESPONSE:"):
                        try:
                            self.responses.put(json.loads(line[len("PIPER_RESPONSE:"):]))
                        except ValueError:
                            self.log("语音工作进程返回了无效数据")
                    elif line.strip():
                        self.log("语音引擎：" + line.strip()[:180])
            except (OSError, ValueError):
                pass
            finally:
                self.finished.set()
        self.reader = threading.Thread(target=reader, daemon=True)
        self.reader.start()
        try:
            ready = self._receive(90)
            if ready.get("ready") is not True:
                raise RuntimeError("常驻语音引擎未确认加载完成")
        except BaseException:
            self.close()
            raise

    def _receive(self, timeout):
        started = time.monotonic()
        while time.monotonic() - started < timeout:
            if self.cancel.is_set():
                raise InterruptedError("停止语音合成")
            if self.proc.poll() is not None and self.finished.is_set() and self.responses.empty():
                raise RuntimeError("语音工作进程意外退出：%s" % self.proc.returncode)
            try:
                message = self.responses.get(timeout=.2)
                if message.get("error"):
                    raise RuntimeError(str(message["error"]))
                return message
            except queue.Empty:
                continue
        raise TimeoutError("语音引擎响应超时")

    def synthesize(self, text_path, output):
        if self.proc.poll() is not None:
            raise RuntimeError("语音工作进程已经退出")
        data = {"text_path": str(text_path), "output": str(output)}
        self.proc.stdin.write(json.dumps(data, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        result = self._receive(MAX_SPEECH_RESPONSE_SECONDS)
        if not result.get("ok") or result.get("output") != str(output) or audio_seconds(output) < .15:
            raise RuntimeError("语音工作进程未正确产生 WAV 文件")
        return Path(output)

    def close(self):
        if self.proc.poll() is None:
            try:
                self.proc.stdin.write('{"command":"close"}\n')
                self.proc.stdin.flush()
                self.proc.wait(timeout=4)
            except (OSError, ValueError, subprocess.TimeoutExpired):
                stop_process_tree(self.proc)
        for stream in (self.proc.stdin, self.proc.stdout):
            if stream is not None:
                try:
                    stream.close()
                except OSError:
                    pass
        self.reader.join(timeout=2)
        with RUNNING_CHILDREN_LOCK:
            RUNNING_CHILDREN.discard(self.proc)

def verify_offline_pipeline(root, image, voice, ffmpeg):
    import socket
    root = Path(root)
    image, voice = Path(image), Path(voice)
    if not image.is_file() or not voice.is_file():
        raise RuntimeError("离线联合验收缺少输入图像或语音合成结果")
    folder = root / ".studio" / "tmp" / "offline_full_creation"
    folder.mkdir(parents=True, exist_ok=True)
    picture = folder / "planned_scene.png"
    rough = folder / "edited_scene.mp4"
    final = folder / "delivered_probe.mp4"
    frame = folder / "checked_frame.png"
    original_connect = socket.socket.connect
    original_connect_ex = socket.socket.connect_ex
    original_create = socket.create_connection
    denied = []
    checks = []
    def local_only(address):
        host = address[0] if isinstance(address, tuple) and address else None
        if host not in {"localhost", "127.0.0.1", "::1"}:
            denied.append(str(host)[:120])
            raise OSError("离线完整验收禁止向外部网络建立连接")
    def blocked_connect(instance, address):
        local_only(address)
        return original_connect(instance, address)
    def blocked_connect_ex(instance, address):
        local_only(address)
        return original_connect_ex(instance, address)
    def blocked_create(address, *args, **kwargs):
        local_only(address)
        return original_create(address, *args, **kwargs)
    socket.socket.connect = blocked_connect
    socket.socket.connect_ex = blocked_connect_ex
    socket.create_connection = blocked_create
    models = None
    try:
        prompt = "晨光中的绿色森林，真实自然风景，电影摄影构图"
        models = LocalModels(root, lambda message: None, threading.Event(), quality="快速")
        policy = models.decide_media(prompt, "", media_preferences(prompt))
        if not all(isinstance(policy.get(key), bool) for key in ("narration", "subtitles", "music")):
            raise RuntimeError("本地导演没有完成媒体方案的自主决策")
        checks.append("local_media_decision")
        plan = models.plan(prompt, "", 1, 2.0, policy)
        if not validate_plan(plan, 1):
            raise RuntimeError("本地导演未产生有效的完整分镜计划")
        checks.append("local_storyboard_planning")
        visual = plan["scenes"][0]["visual_prompt"]
        models.paint(visual, picture, 61293, "快速", "横屏 16:9",
                     min_dimensions=required_image_dimensions((512, 288)))
        accepted, reason = validate_image(picture)
        if not accepted:
            raise RuntimeError("规划场景生成的图像未通过素材检查：" + str(reason))
        checks.append("local_visual_generation")
        baseline = models.image_similarity(picture, visual)
        if not baseline.get("passed"):
            raise RuntimeError("规划场景未通过独立AI图像语义检查")
        checks.append("local_semantic_first_review")
        run_external([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-loop", "1",
                      "-framerate", str(DEFAULT_FPS), "-i", str(picture), "-t", "2",
                      "-vf", "fps=%d,scale=512:288:force_original_aspect_ratio=increase,"
                              "crop=512:288,format=yuv420p" % DEFAULT_FPS,
                      "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", str(rough)],
                     root, timeout=130, capture=True, env=shell_env(root, offline=True))
        if not rough.is_file() or rough.stat().st_size < 2000:
            raise RuntimeError("完整离线验收未生成可供后期剪辑的视频片段")
        checks.append("local_video_edition")
        run_external([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(rough),
                      "-i", str(voice), "-t", "2", "-map", "0:v:0", "-map", "1:a:0",
                      "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
                      "-c:a", "aac", "-ar", str(SPEECH_RATE), "-ac", "1", str(final)],
                     root, timeout=130, capture=True, env=shell_env(root, offline=True))
        if not final.is_file() or final.stat().st_size < 2500:
            raise RuntimeError("离线审核后的视频无法进行成片混音与交付编码")
        checks.append("local_audio_mixing_and_export")
        run_external([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", "1",
                      "-i", str(final), "-frames:v", "1", str(frame)],
                     root, timeout=75, capture=True, env=shell_env(root, offline=True))
        accepted, reason = validate_image(frame)
        if not accepted:
            raise RuntimeError("导出的成片画面损坏：" + str(reason))
        final_review = models.image_similarity(frame, visual)
        if not final_review.get("passed"):
            raise RuntimeError("剪辑后的最终成片未通过独立AI语义复核")
        checks.append("local_semantic_final_review")
        decoded = run_external([ffmpeg, "-hide_banner", "-loglevel", "error", "-xerror",
                                "-nostdin", "-i", str(final), "-map", "0:v:0", "-map", "0:a:0",
                                "-progress", "pipe:1", "-f", "null", "-"], root,
                               timeout=130, capture=True, env=shell_env(root, offline=True))
        frames = re.findall(r"(?:^|\n)frame=\s*(\d+)", decoded)
        if not frames or int(frames[-1]) < DEFAULT_FPS * 2 - 2:
            raise RuntimeError("离线创作链路未完成最终音视频全流解码")
        checks.append("local_full_media_decode")
        if denied:
            raise RuntimeError("完整离线验收中发现试图联网的调用：" + ",".join(denied[:4]))
        return {"status": REVIEW_PASS, "decoded_frames": int(frames[-1]),
                "video_bytes": final.stat().st_size, "network_disabled": True,
                "network_isolation": "socket_guard_plus_hf_offline",
                "outbound_connections": 0, "steps": checks,
                "semantic_review": {key: final_review.get(key) for key in
                                    ("status", "cosine", "margin", "subject_margin")}}
    finally:
        if models is not None:
            models.close()
        socket.socket.connect = original_connect
        socket.socket.connect_ex = original_connect_ex
        socket.create_connection = original_create
        shutil.rmtree(folder, ignore_errors=True)


def check_runtime_worker(root, tier="full"):
    configure_environment(root)
    os.environ.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "DIFFUSERS_OFFLINE": "1"})
    import torch
    import imageio_ffmpeg
    import PIL
    import transformers
    import numpy as np
    from PIL import Image
    from transformers import (AutoTokenizer, AutoModelForCausalLM, WhisperProcessor,
                              WhisperForConditionalGeneration, CLIPProcessor, CLIPModel)
    torch.set_num_threads(available_threads())
    checks = {}
    def release():
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    folder = str(model_path(root, "director"))
    tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True)
    director = AutoModelForCausalLM.from_pretrained(folder, torch_dtype=torch.float32,
                                                   local_files_only=True, low_cpu_mem_usage=True)
    director.eval()
    prompt = tokenizer("你好", return_tensors="pt")
    with torch.inference_mode():
        sample = director.generate(**prompt, max_new_tokens=2, do_sample=False,
                                   pad_token_id=tokenizer.eos_token_id)
    if sample.shape[1] <= prompt.input_ids.shape[1]:
        raise RuntimeError("本地文案模型未生成任何文字")
    checks["director"] = "passed"
    del tokenizer, director, prompt, sample
    release()
    if tier == "full":
        import diffusers
        import pypdf
        from diffusers import DiffusionPipeline
        folder = str(model_path(root, "listener"))
        listener_processor = WhisperProcessor.from_pretrained(folder, local_files_only=True)
        listener = WhisperForConditionalGeneration.from_pretrained(folder, local_files_only=True)
        listener.eval()
        batch = listener_processor(np.zeros(SPEECH_RATE, dtype=np.float32),
                                   sampling_rate=SPEECH_RATE, return_tensors="pt")
        with torch.inference_mode():
            ids = listener.generate(batch.input_features, max_new_tokens=4)
        if ids.numel() == 0:
            raise RuntimeError("本地语音识别模型没有产生结果")
        checks["listener"] = "passed"
        del listener_processor, listener, batch, ids
        release()
        folder = str(model_path(root, "inspector"))
        inspector_processor = CLIPProcessor.from_pretrained(folder, local_files_only=True, use_fast=False)
        inspector = CLIPModel.from_pretrained(folder, local_files_only=True, torch_dtype=torch.float32)
        inspector.eval()
        batch = inspector_processor(text=["a red square", "an empty background"],
                                    images=Image.new("RGB", (224, 224), "red"),
                                    return_tensors="pt", padding=True, truncation=True)
        with torch.inference_mode():
            logits = inspector(**batch).logits_per_image
        if logits.numel() != 2 or not torch.isfinite(logits).all():
            raise RuntimeError("画面审校模型输出不正确")
        checks["inspector"] = "passed"
        del inspector_processor, inspector, batch, logits
        release()
        from transformers import OwlViTForObjectDetection, OwlViTProcessor
        folder = str(model_path(root, "detector"))
        detection_processor = OwlViTProcessor.from_pretrained(folder, local_files_only=True)
        detection_model = OwlViTForObjectDetection.from_pretrained(
            folder, local_files_only=True, torch_dtype=torch.float32, use_safetensors=True)
        detection_model.eval()
        detections = detection_processor(text=[["a photo of a red square"]],
                                          images=Image.new("RGB", (128, 128), "red"), return_tensors="pt")
        with torch.inference_mode():
            detected = detection_model(**detections)
        if detected.logits.numel() == 0 or not torch.isfinite(detected.logits).all():
            raise RuntimeError("离线实例数量检测器没有通过真实计算测试")
        checks["instance_detector"] = REVIEW_PASS
        del detection_processor, detection_model, detections, detected
        release()
        painter = DiffusionPipeline.from_pretrained(str(model_path(root, "painter")),
                                                   torch_dtype=torch.float32, local_files_only=True,
                                                   low_cpu_mem_usage=True)
        painter.to("cpu")
        painter.set_progress_bar_config(disable=True)
        with torch.inference_mode():
            picture = painter("a red apple", width=256, height=256,
                              num_inference_steps=1, guidance_scale=1.0).images[0]
        if picture.width < 128 or picture.height < 128:
            raise RuntimeError("本地图像生成模型没有产生正确的画面")
        checks["painter"] = "passed"
        offline_picture = Path(root) / ".studio" / "tmp" / "offline_acceptance_image.png"
        picture.convert("RGB").save(offline_picture)
        del painter, picture
        release()
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    temporary = Path(root) / ".studio" / "tmp" / "runtime_probe.mp4"
    try:
        result = subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi",
                                 "-i", "color=c=red:s=160x160:r=8:d=1", "-f", "lavfi",
                                 "-i", "anullsrc=r=16000:cl=mono", "-t", "1", "-c:v", "libx264",
                                 "-pix_fmt", "yuv420p", "-c:a", "aac", str(temporary)],
                                capture_output=True, timeout=50,
                                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        if result.returncode or not temporary.is_file() or temporary.stat().st_size < 2048:
            raise RuntimeError("视频和音频编码组件未通过实际输出测试：" + result.stderr.decode(errors="replace")[-400:])
    finally:
        temporary.unlink(missing_ok=True)
    checks["encoder"] = "passed"
    voice_backend = "sapi" if test_system_chinese_voice(root) else "piper"
    voice_text = Path(root) / ".studio" / "tmp" / "voice_probe.txt"
    voice_wave = Path(root) / ".studio" / "tmp" / "voice_probe.wav"
    voice_script = Path(root) / ".studio" / "tmp" / "voice_probe.ps1"
    try:
        voice_text.write_text("你好，欢迎使用离线视频工坊。", encoding="utf-8-sig")
        if voice_backend == "piper":
            piper_speak_worker(root, voice_text, voice_wave)
        elif tier == "full":
            safe_wave = str(voice_wave).replace("'", "''")
            voice_script.write_text(
                "Add-Type -AssemblyName System.Speech\n"
                "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
                "$c=@($s.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'zh*' })\n"
                "if($c.Count -lt 1){throw 'CHINESE_VOICE_MISSING'}\n"
                "$s.SelectVoice($c[0].VoiceInfo.Name)\n"
                "$s.SetOutputToWaveFile('" + safe_wave + "')\n"
                "$s.Speak('你好，欢迎使用离线视频工坊。')\n$s.Dispose()\n",
                encoding="utf-8-sig")
            run_external(["powershell.exe", "-NoProfile", "-NonInteractive",
                          "-ExecutionPolicy", "Bypass", "-File", str(voice_script)],
                         root, timeout=80, capture=True, env=shell_env(root, offline=True))
        if tier == "full":
            checks["offline_pipeline"] = verify_offline_pipeline(root, offline_picture, voice_wave, ffmpeg)
        checks["voice"] = "passed"
    finally:
        voice_text.unlink(missing_ok=True)
        voice_wave.unlink(missing_ok=True)
        voice_script.unlink(missing_ok=True)
        if tier == "full":
            offline_picture.unlink(missing_ok=True)
    print(json.dumps({"ok": True, "tier": tier, "smoke_test": checks, "chinese_voice": True,
                       "voice_backend": voice_backend,
                       "offline_pipeline": checks.get("offline_pipeline", {}),
                      "instance_detector": checks.get("instance_detector", REVIEW_UNAVAILABLE),
                      "torch": torch.__version__, "cuda": torch.cuda.is_available(),
                      "ffmpeg": str(ffmpeg), "transformers": transformers.__version__,
                      "diffusers": diffusers.__version__ if tier == "full" else "not-installed",
                      "pillow": PIL.__version__}, ensure_ascii=False), flush=True)


def native_seam_positions(metadata):
    counts = metadata.get("frame_schedule", [])
    fps = metadata.get("fps", NATIVE_VIDEO_FPS)
    if not isinstance(counts, list) or not all(isinstance(count, int) and count >= 9 for count in counts):
        return []
    if not isinstance(fps, (int, float)) or not math.isfinite(fps) or fps <= 0:
        return []
    frames = counts[0] if counts else 0
    positions = []
    for count in counts[1:]:
        positions.append(((frames - 1) / fps, frames / fps))
        frames += count - 1
    if len(positions) > NATIVE_MAX_SEAM_SAMPLES:
        step = (len(positions) - 1) / max(1, NATIVE_MAX_SEAM_SAMPLES - 1)
        positions = [positions[round(index * step)] for index in range(NATIVE_MAX_SEAM_SAMPLES)]
    return positions


def image_mean_difference(first, second):
    from PIL import Image, ImageChops, ImageStat
    with Image.open(first) as left, Image.open(second) as right:
        a = left.convert("L").resize((96, 64))
        b = right.convert("L").resize((96, 64))
        return float(ImageStat.Stat(ImageChops.difference(a, b)).mean[0])


def extract_video_frame(ffmpeg, video, destination, seconds, root, cancel=None, log=None):
    run_external([str(ffmpeg), "-hide_banner", "-loglevel", "error", "-y", "-i", str(video),
                  "-ss", "%.6f" % max(0, float(seconds)), "-frames:v", "1", str(destination)],
                 root, cancel=cancel, log=log, timeout=110, capture=True)
    if not Path(destination).is_file():
        raise RuntimeError("指定时间点未能提取视频帧")
    return destination


def native_frame_schedule(seconds, fps=NATIVE_VIDEO_FPS, maximum=NATIVE_VIDEO_FRAMES):
    maximum = max(9, (int(maximum) - 1) // 8 * 8 + 1)
    required = max(9, math.ceil(max(1.0, float(seconds)) * fps))
    segments = max(1, math.ceil((required - 1) / max(1, maximum - 1)))
    if segments > MAX_NATIVE_SEGMENTS:
        raise RuntimeError("当前安全分段上限无法覆盖 %.1f 秒连续动态视频" % float(seconds))
    remaining = required - 1
    counts = []
    for index in range(segments):
        addition = math.ceil(remaining / (segments - index))
        frames = min(maximum, max(9, math.ceil(addition / 8) * 8 + 1))
        counts.append(frames)
        remaining = max(0, remaining - (frames - 1))
    if remaining:
        raise RuntimeError("原生视频帧数规划不足，拒绝冻结末帧凑时长")
    return counts


def native_aspect_name(aspect):
    return "竖屏" if "竖屏" in str(aspect) else "方形" if "方形" in str(aspect) else "横屏"


def native_generation_resolution(aspect, free_bytes, model_class, probe=False):
    if model_class == "AnimateDiffPipeline":
        choices = NATIVE_ANIMATE_RESOLUTIONS[native_aspect_name(aspect)]
        if probe:
            return choices[-1]
        return choices[1] if free_bytes < 7 * GB else choices[0]
    if model_class not in {"CogVideoXPipeline", "CogVideoXImageToVideoPipeline"}:
        raise ValueError("未注册的原生时序视频模型类型")
    choices = NATIVE_RESOLUTIONS[native_aspect_name(aspect)]
    return choices[-1] if probe else choices[0] if free_bytes >= NATIVE_HIGH_MEMORY else choices[1]


def native_smaller_resolution(aspect, current, model_class):
    choices = (NATIVE_ANIMATE_RESOLUTIONS if model_class == "AnimateDiffPipeline"
               else NATIVE_RESOLUTIONS)[native_aspect_name(aspect)]
    old_area = int(current[0]) * int(current[1])
    return next(((w, h) for w, h in choices if w * h < old_area and w <= current[0] and h <= current[1]), None)


def native_model_capabilities(pipeline, aspect, available_bytes, model_class):
    if model_class == "AnimateDiffPipeline":
        resolution = native_generation_resolution(aspect, available_bytes, model_class)
        frames = NATIVE_ANIMATE_LONG_FRAME_LIMIT if available_bytes >= 7 * GB else NATIVE_ANIMATE_FRAME_LIMIT
        return {"resolution": resolution, "frame_limit": frames,
                "native_resolution": resolution, "model_reported_frames": 32}
    transformer = getattr(pipeline, "transformer", None)
    config = getattr(transformer, "config", None)
    scale = getattr(pipeline, "vae_scale_factor_spatial", 8)
    try:
        scale = max(1, min(32, int(scale)))
    except (TypeError, ValueError):
        scale = 8
    sample_width = getattr(config, "sample_width", None)
    sample_height = getattr(config, "sample_height", None)
    if isinstance(sample_width, int) and isinstance(sample_height, int) and sample_width > 0 and sample_height > 0:
        native_width, native_height = sample_width * scale, sample_height * scale
    else:
        native_width, native_height = native_generation_resolution(aspect, available_bytes, model_class)
    permitted = min(native_width * native_height, native_generation_resolution(aspect, available_bytes, model_class)[0] *
                    native_generation_resolution(aspect, available_bytes, model_class)[1])
    target = {"横屏": 16 / 9, "竖屏": 9 / 16, "方形": 1.0}[native_aspect_name(aspect)]
    width = max(16, int(math.sqrt(permitted * target) // 16 * 16))
    height = max(16, int(math.sqrt(permitted / target) // 16 * 16))
    width = min(width, max(16, native_width // 16 * 16))
    height = min(height, max(16, native_height // 16 * 16))
    reported_frames = getattr(config, "sample_frames", None)
    maximum = (min(NATIVE_VIDEO_MAX_FRAMES, reported_frames) if
               isinstance(reported_frames, int) and reported_frames >= 17 else
               NATIVE_VIDEO_MAX_FRAMES if available_bytes >= NATIVE_HIGH_MEMORY else NATIVE_VIDEO_FRAMES)
    maximum = max(17, (int(maximum) - 1) // 8 * 8 + 1)
    return {"resolution": (width, height), "frame_limit": maximum,
            "native_resolution": (native_width, native_height),
            "model_reported_frames": reported_frames}


def required_image_dimensions(final_size):
    width, height = final_size
    return (max(16, math.ceil(width / MAX_IMAGE_UPSCALE / 8) * 8),
            max(16, math.ceil(height / MAX_IMAGE_UPSCALE / 8) * 8))


def native_model_precision(torch, gpu_index):
    try:
        return torch.bfloat16 if torch.cuda.is_bf16_supported(including_emulation=False) else torch.float16
    except (AttributeError, RuntimeError, TypeError):
        try:
            capability = torch.cuda.get_device_capability(gpu_index)
            return torch.bfloat16 if capability[0] >= 8 else torch.float16
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return torch.float16


def native_video_worker(root, prompt_path, output, quality, seconds=3.0, image_path=None,
                        aspect="横屏 16:9", tail_image_path=None, cancel=None):
    configure_environment(root)
    os.environ.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "DIFFUSERS_OFFLINE": "1"})
    model = native_video_model(root)
    if model is None or not native_video_folder_complete(model[0]):
        raise RuntimeError("原生视频模型未通过文件与摘要校验")
    import torch
    from diffusers.utils import export_to_video
    from PIL import Image, ImageOps
    if not torch.cuda.is_available() or not native_inference_ready(root):
        raise RuntimeError("原生视频尚未通过离线推理、运动和编码验收")
    verified = read_json(Path(root) / ".studio" / "native_ready.json", {})
    selected = select_torch_gpu(torch, NATIVE_VIDEO_MIN_FREE_MB * 1024 * 1024,
                                {"name": verified.get("gpu_name"),
                                 "total_mb": verified.get("gpu_total_mb"),
                                 "index": verified.get("gpu_index")})
    if not selected:
        raise RuntimeError("已验证的 NVIDIA GPU 显存被其它任务占用，主动暂停原生视频生成")
    free, gpu_index = selected["free_bytes"], selected["index"]
    torch.cuda.set_device(gpu_index)
    if cancel is not None and cancel.is_set():
        raise InterruptedError("已停止原生视频生成")
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.unlink(missing_ok=True)
    Path(str(output_path) + ".json").unlink(missing_ok=True)
    Path(str(output_path) + ".failure.json").unlink(missing_ok=True)
    cleanup_native_segments(output_path)
    prompt = Path(prompt_path).read_text(encoding="utf-8").strip()
    model_class = model[1]
    if (image_path or tail_image_path) and model_class not in {
            "AnimateDiffPipeline", "CogVideoXImageToVideoPipeline"}:
        raise RuntimeError("当前原生文生视频模型无法满足指定首帧或尾帧，未忽略用户素材")
    if model_class == "CogVideoXImageToVideoPipeline" and not (image_path or tail_image_path):
        raise RuntimeError("原生图生视频模型缺少必要的参考图片")
    steps = NATIVE_VIDEO_STEPS.get(quality, NATIVE_VIDEO_STEPS["智能"])
    is_image_pipeline = bool(image_path or model_class == "CogVideoXImageToVideoPipeline")
    pipeline = None
    parts = []
    segment_reports = []
    success_report = None
    failure = None
    changed_resolution = False
    conditioned_segments = 0
    concat_file = output_path.with_name(output_path.stem + "_parts.txt")
    governor = ResourceGovernor(root)
    governor.attach_cuda(torch, gpu_index)
    governor.attach_runtime(torch)
    governor.start_monitor(cancel, lambda message: print(message, flush=True))
    began = time.monotonic()
    try:
        pipeline, precision = load_native_pipeline(
            root, gpu_index, image_conditioned=is_image_pipeline)
        limits = native_model_capabilities(pipeline, aspect, free, model_class)
        schedule = native_frame_schedule(seconds, maximum=limits["frame_limit"])
        if (image_path or tail_image_path) and seconds < MIN_NATIVE_BRIDGE_SECONDS:
            raise RuntimeError("时长过短，无法兼顾用户首尾画面与连续动态过渡")
        output_width, output_height = limits["resolution"]
        width, height = output_width, output_height
        head = normalize_native_boundary(image_path, (output_width, output_height)) if image_path else None
        tail = normalize_native_boundary(tail_image_path, (output_width, output_height)) if tail_image_path else None
        reference = head
        previous_end = None
        for number, count in enumerate(schedule):
            governor.adaptive_pause("native_video_segment", cancel=cancel)
            governor.ensure("native_video_segment", required=MIN_SYSTEM_MEMORY_HEADROOM,
                            disk_required=MIN_JOB_FREE)
            gpu_free, _ = torch.cuda.mem_get_info(gpu_index)
            if gpu_free < GPU_CRITICAL_FREE_BYTES:
                raise RuntimeError("剩余显存过低，保护其它软件并暂停视频推理")
            last_segment = number == len(schedule) - 1
            reverse_tail = bool(last_segment and tail is not None)
            generated_reference = tail if reverse_tail else reference if reference is not None else previous_end
            if model_class == "CogVideoXPipeline":
                generated_reference = None
            elif model_class == "AnimateDiffPipeline":
                should_condition = generated_reference is not None
                if should_condition != is_image_pipeline:
                    pipeline = None
                    gc.collect()
                    torch.cuda.empty_cache()
                    pipeline, precision = load_native_pipeline(
                        root, gpu_index, image_conditioned=should_condition)
                    is_image_pipeline = should_condition
            if generated_reference is not None:
                conditioned_segments += 1
            seed = native_segment_seed(prompt, output_path, number)
            for retry in range(len(NATIVE_RESOLUTIONS[native_aspect_name(aspect)]) + 1):
                try:
                    frames = native_pipeline_output(pipeline, model_class, prompt, width, height,
                                                    count, steps, reference=generated_reference, seed=seed,
                                                    governor=governor, cancel=cancel,
                                                    stage="native_segment_%02d" % number)
                    break
                except (RuntimeError, MemoryError) as error:
                    smaller = native_smaller_resolution(aspect, (width, height), model_class)
                    if not is_memory_error(error) or smaller is None:
                        raise
                    width, height = smaller
                    changed_resolution = True
                    gc.collect()
                    torch.cuda.empty_cache()
                    print("显存压力触发自适应推理分辨率：%d×%d" % (width, height), flush=True)
            frames = [frame.convert("RGB").resize((output_width, output_height), Image.Resampling.LANCZOS)
                      for frame in frames]
            if reverse_tail:
                frames.reverse()
            if previous_end is not None:
                frames[0] = previous_end.copy()
                bridge = max(2, min(5, len(frames) // 4))
                for step in range(1, bridge):
                    frames[step] = Image.blend(previous_end, frames[step], step / bridge)
            frames = native_frame_boundary_transition(
                frames, head if number == 0 else None, tail if last_segment else None)
            previous_end = frames[-1].convert("RGB")
            reference = previous_end
            encoded = frames if number == 0 else frames[1:]
            segment = Path(output).with_name(Path(output).stem + "_part_%02d.mp4" % number)
            export_to_video(encoded, str(segment), fps=NATIVE_VIDEO_FPS)
            if not segment.is_file() or segment.stat().st_size < 8192:
                raise RuntimeError("原生视频第%d段编码失败" % (number + 1))
            parts.append(segment)
            segment_reports.append({"index": number, "frames": len(encoded), "bytes": segment.stat().st_size,
                                    "seed": seed, "resolution": [width, height]})
            print("原生动态镜头 %d/%d，%d帧，推理分辨率%d×%d" % (
                number + 1, len(schedule), len(encoded), width, height), flush=True)
            del frames, encoded
            gc.collect()
            torch.cuda.empty_cache()
        concat_file.write_text("\n".join("file '%s'" % str(part).replace("\\", "/").replace("'", "'\\''")
                                          for part in parts), encoding="utf-8")
        run_external([ffmpeg_executable(), "-hide_banner", "-loglevel", "error", "-y",
                      "-f", "concat", "-safe", "0", "-i", str(concat_file),
                      "-c:v", "libx264", "-pix_fmt", "yuv420p", "-r", str(NATIVE_VIDEO_FPS),
                      "-an", str(output)], root, timeout=max(360, int(seconds * 90)),
                     env=shell_env(root, offline=True), capture=True)
        if not Path(output).is_file() or Path(output).stat().st_size < 8192:
            raise RuntimeError("原生时序视频未生成有效MP4")
        full_frames = sum(schedule) - len(schedule) + 1
        actual_seconds = full_frames / NATIVE_VIDEO_FPS
        if actual_seconds < float(seconds) / MAX_NATIVE_OUTPUT_DURATION_FACTOR:
            raise RuntimeError("原生动态生成时长不足，不以冻结图片补齐")
        success_report = {
            "frames": full_frames, "fps": NATIVE_VIDEO_FPS,
            "seconds": round(actual_seconds, 4), "requested_seconds": float(seconds),
            "segments": len(schedule), "frame_schedule": schedule,
            "model_class": model_class,
            "reference_signature": file_integrity_hash(image_path) if image_path else None,
            "tail_reference_signature": file_integrity_hash(tail_image_path) if tail_image_path else None,
            "boundary_method": "conditioned_reversed_tail_and_verified_blended_endpoints",
            "resolution": [output_width, output_height], "inference_resolution": [width, height],
            "adaptive_resolution": changed_resolution,
            "conditioned_segments": conditioned_segments,
            "model_native_resolution": list(limits["native_resolution"]),
            "model_reported_frames": limits["model_reported_frames"],
            "precision": str(precision), "aspect": aspect, "generated": now_stamp(),
            "motion_fill": "native_temporal_diffusion_with_frame_bridge",
            "memory_strategy": "sequential_cpu_offload" if model_class == "AnimateDiffPipeline"
                               else "model_cpu_offload"}
    except Exception as error:
        failure = error
        output_path.unlink(missing_ok=True)
        raise
    finally:
        try:
            governor.stop_monitor()
            cleaned = cleanup_native_segments(output_path)
            diagnostic = {"elapsed_seconds": round(time.monotonic() - began, 3),
                          "segment_reports": segment_reports, "intermediate_cleanup": cleaned,
                          "resource_report": governor.report()}
            if success_report is not None:
                success_report.update(diagnostic)
                try:
                    atomic_json(str(output_path) + ".json", success_report)
                except OSError:
                    output_path.unlink(missing_ok=True)
                    raise
            elif failure is not None:
                diagnostic.update({"status": "interrupted" if isinstance(failure, InterruptedError) else "failed",
                                   "error_type": type(failure).__name__, "error": str(failure)[:350]})
                try:
                    atomic_json(str(output_path) + ".failure.json", diagnostic)
                except OSError:
                    pass
        finally:
            if pipeline is not None:
                del pipeline
            gc.collect()
            torch.cuda.empty_cache()


def test_system_voice(root, language="zh"):
    if os.name != "nt" or language not in {"zh", "en"}:
        return False
    folder = Path(root) / ".studio" / "tmp"
    folder.mkdir(parents=True, exist_ok=True)
    script = folder / ("check_voice_" + language + ".ps1")
    sample = folder / ("check_voice_" + language + ".wav")
    outfile = str(sample).replace("'", "''")
    speech = "Hello, this is an English narration test." if language == "en" else "你好"
    script.write_text("Add-Type -AssemblyName System.Speech\n"
                      "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
                      "$c=@($s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like '" + language + "*' -and $_.Enabled })\n"
                      "if ($c.Count -eq 0) { throw 'REQUIRED_LANGUAGE_VOICE_MISSING' }\n"
                      "$s.SelectVoice($c[0].VoiceInfo.Name)\n"
                      "$s.SetOutputToWaveFile('" + outfile + "')\n"
                      "$s.Speak('" + speech + "')\n"
                      "$s.Dispose()\n", encoding="utf-8-sig")
    try:
        result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
                                 "Bypass", "-File", str(script)], capture_output=True, timeout=30,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        return result.returncode == 0 and sample.is_file() and sample.stat().st_size > 1000
    except (OSError, subprocess.TimeoutExpired):
        return False
    finally:
        script.unlink(missing_ok=True)
        sample.unlink(missing_ok=True)


def test_system_chinese_voice(root):
    return test_system_voice(root, "zh")


def voice_language_operational(root, language, force=False):
    if language not in {"zh", "en"}:
        return False
    if language == "zh":
        diagnostic = read_json(Path(root) / ".studio" / "ready.json", {}).get("diagnostic", {})
        backend = diagnostic.get("voice_backend", "sapi")
        return voice_backend_operational(root, backend, force=force)
    if os.name != "nt":
        return False
    key = str(Path(root).resolve()) + ":en"
    with VOICE_PROBE_LOCK:
        old = VOICE_PROBE_CACHE.get(key, {})
        if (old and time.monotonic() - old.get("at", 0) < VOICE_PROBE_SECONDS and
                (not force or old.get("deep"))):
            return bool(old.get("ok"))
        if force:
            available = test_system_voice(root, "en")
        else:
            command = ("Add-Type -AssemblyName System.Speech;"
                       "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                       "$v=@($s.GetInstalledVoices() | Where-Object {"
                       "$_.Enabled -and $_.VoiceInfo.Culture.Name -like 'en*'});"
                       "if($v.Count -lt 1){exit 2};$s.Dispose()")
            try:
                outcome = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                                          "-ExecutionPolicy", "Bypass", "-Command", command],
                                         capture_output=True, timeout=12,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                available = outcome.returncode == 0
            except (OSError, subprocess.TimeoutExpired):
                available = False
        VOICE_PROBE_CACHE[key] = {"at": time.monotonic(), "ok": available, "deep": bool(force)}
        return available


def voice_backend_operational(root, backend, force=False):
    if backend == "piper":
        return voice_download_complete(root, deep=force)
    if backend != "sapi" or os.name != "nt":
        return False
    key = str(Path(root).resolve())
    with VOICE_PROBE_LOCK:
        prior = VOICE_PROBE_CACHE.get(key, {})
        if (prior and time.monotonic() - prior["at"] < VOICE_PROBE_SECONDS and
                (not force or prior.get("deep"))):
            return bool(prior["ok"])
        try:
            if force:
                healthy = test_system_chinese_voice(root)
            else:
                command = ("Add-Type -AssemblyName System.Speech;"
                           "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                           "$v=@($s.GetInstalledVoices() | Where-Object {"
                           "$_.Enabled -and $_.VoiceInfo.Culture.Name -like 'zh*'});"
                           "if($v.Count -lt 1){exit 2};$s.Dispose()")
                result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                                         "-ExecutionPolicy", "Bypass", "-Command", command],
                                        capture_output=True, timeout=12,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
                healthy = result.returncode == 0
        except (OSError, ValueError, subprocess.TimeoutExpired):
            healthy = False
        VOICE_PROBE_CACHE[key] = {"at": time.monotonic(), "ok": healthy, "deep": bool(force)}
        return healthy


def ffmpeg_executable():
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def asset_sequence_for_scene(primary, extras, index, count, request):
    extras = list(extras or [])
    sequence = ([primary] if primary else []) + extras
    if primary and index == count - 1 and request.get("files", {}).get("尾帧"):
        sequence = extras + [primary]
    if not sequence:
        return []
    return sequence


def distribute_unused_assets(scenes, assignments, unused, request, seconds, fps=DEFAULT_FPS,
                             affinity=None):
    count = len(scenes)
    extras = {index: [] for index in range(count)}
    frames = [max(1, round(float(seconds[index]) * fps)) for index in range(count)]
    minimum = max(3, math.ceil(MIN_ASSET_SHOT_SECONDS * fps))
    remaining = []
    affinity = affinity or {}
    for asset_index, item in enumerate(unused):
        possibilities = [index for index in range(count)
                         if (len(extras[index]) + (1 if index in assignments else 0) < MAX_ASSETS_PER_SCENE and
                             (len(extras[index]) + (2 if index in assignments else 1)) * minimum <= frames[index])]
        if not possibilities:
            remaining.append(item)
            continue
        matches = affinity.get(asset_index)
        if matches and len(matches) == count:
            place = max(possibilities, key=lambda index: (
                float(matches[index]) if math.isfinite(float(matches[index])) else -1.0,
                -((len(extras[index]) + (1 if index in assignments else 0)) / max(1, frames[index])),
                -index))
        else:
            place = min(possibilities, key=lambda index: (
                (len(extras[index]) + (1 if index in assignments else 0)) / max(1, frames[index]),
                len(extras[index]), index))
        extras[place].append(item)
    if remaining:
        raise RuntimeError("所选素材超过当前成片的可观看时长，仍有 %d 个未能安排。请增加时长或减少素材，程序不会悄悄丢弃" % len(remaining))
    return {index: items for index, items in extras.items() if items}


def montage_frame_allocation(seconds, items, fps):
    count = len(items)
    if count <= 0:
        raise ValueError("镜头素材为空")
    total = round(float(seconds) * fps)
    minimum = max(3, math.ceil(MIN_ASSET_SHOT_SECONDS * fps))
    if count * minimum > total:
        raise RuntimeError("当前镜头 %.2f 秒不足以完整展示 %d 个素材，建议增加片长" % (seconds, count))
    base = max(minimum, total // count)
    counts = [base] * count
    remain = total - sum(counts)
    for index in range(remain):
        counts[index % count] += 1
    if sum(counts) != total:
        raise RuntimeError("素材编排帧数不一致")
    return [number / fps for number in counts]


def repair_action_for(code):
    if code in {"SPEECH_REVIEW_UNAVAILABLE", "SEMANTIC_REVIEW_UNAVAILABLE",
                "TEMPORAL_REVIEW_UNAVAILABLE", "EXACT_TEXT_REVIEW_UNAVAILABLE",
                "EXACT_TEXT_REVIEW_INCOMPLETE", "HARD_QUANTITY_REVIEW_UNAVAILABLE"}:
        return "restart_reviewer_and_recheck"
    if code == "SOURCE_REQUIREMENT_UNVERIFIED":
        return "stop_unverifiable_constraint"
    if code == "HARD_QUANTITY_MISSING_IN_PLAN":
        return "replan_scene_and_rerender"
    if code in {"HARD_QUANTITY_UNVERIFIED", "HARD_QUANTITY_MISMATCH"}:
        return "repair_scene_visual"
    if code in {"EXACT_TEXT_UNVERIFIED", "SCENE_SEMANTIC_UNVERIFIED",
                "SCENE_FRAME_INVALID", "FINAL_SEMANTIC_MISMATCH"}:
        return "repair_scene_visual"
    if code == "CAPTION_TIMELINE_MISSING":
        return "rebuild_timeline"
    if code in {"MIXED_VOICE_MISSING", "MIXED_SPEECH_MISMATCH", "MIXED_AUDIO_EXTRACTION_FAILED",
                "SPEECH_REVIEW_INCONCLUSIVE", "AUDIO_LOW", "AUDIO_SCAN_FAILED"}:
        return "remix_audio"
    if code in {"CAPTION_VISIBILITY", "CAPTION_TIMELINE_MISMATCH", "SPEECH_MISMATCH",
                "SPEECH_SOURCE_MISMATCH", "SPEECH_SOURCE_MISSING"}:
        return "reencode_caption_keep_visual"
    if code in {"TEMPORAL_FLICKER", "TEMPORAL_FREEZE", "TEMPORAL_JITTER"}:
        return "repair_motion"
    if code == "SUPPLIED_SEMANTIC_CONFLICT":
        return "replace_optional_supplied_visual"
    if code in {"DECODE_FAILURE", "DURATION_MISMATCH", "DURATION_UNREADABLE",
                "OUTPUT_MISSING", "UNWANTED_AUDIO"}:
        return "rebuild_edit_and_container"
    return "stop_unknown_failure"


def image_font(size):
    from PIL import ImageFont
    fonts = [Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / name for name in
             ("msyh.ttc", "msyhbd.ttc", "simhei.ttf", "simsun.ttc", "arial.ttf")]
    fonts.extend([Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"), Path("/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc")])
    for path in fonts:
        if path.exists():
            try:
                return ImageFont.truetype(str(path), size)
            except OSError:
                continue
    return ImageFont.load_default()


def wrap_text(text, font, width, max_lines=None, truncate=False):
    lines = []
    for paragraph in re.split(r"[\r\n]+", str(text)):
        tokens = re.findall(r"[A-Za-z0-9]+|[^A-Za-z0-9\s]|\s+", paragraph)
        current = ""
        for token in tokens:
            if not current and not token.strip():
                continue
            if font.getlength(current + token) <= width:
                current += token
                continue
            if current.strip():
                lines.append(current.rstrip())
                current = ""
            if token.strip():
                if font.getlength(token) <= width:
                    current = token
                else:
                    for char in token:
                        if current and font.getlength(current + char) > width:
                            lines.append(current.rstrip())
                            current = ""
                        current += char
        if current.strip():
            lines.append(current.rstrip())
    if max_lines is not None and len(lines) > max_lines:
        if not truncate:
            raise ValueError("字幕需要分页显示，不允许隐藏正文")
        lines = lines[:max_lines]
        tail = lines[-1]
        while tail and font.getlength(tail + "…") > width:
            tail = tail[:-1]
        lines[-1] = tail + "…"
    return lines


def normalized_caption(value):
    return re.sub(r"\s+", "", str(value))


def paginate_caption(caption, size, seconds, fps=DEFAULT_FPS):
    text = str(caption).strip()
    if not text:
        return []
    font = image_font(max(MIN_CAPTION_FONT, int(size[1] * .044)))
    lines = wrap_text(text, font, int(size[0] * CAPTION_MAX_WIDTH_FRACTION))
    pages = ["\n".join(lines[i:i + MAX_CAPTION_LINES])
             for i in range(0, len(lines), MAX_CAPTION_LINES)]
    if not pages or len(pages) > MAX_CAPTION_SEGMENTS:
        raise ValueError("旁白太长，无法在单镜头中完整显示，请缩短文案或增加镜头数量")
    if normalized_caption("".join(pages)) != normalized_caption(text):
        raise ValueError("分段字幕文本未能完整覆盖原始旁白")
    frames = round(float(seconds) * fps)
    minimum = max(3, round(.2 * fps))
    if frames < minimum * len(pages):
        raise ValueError("字幕过密，当前镜头时长无法完整呈现全部文字")
    weights = [max(1, narration_units(part)) for part in pages]
    remaining = frames - minimum * len(pages)
    exact = [remaining * weight / sum(weights) for weight in weights]
    extras = [int(value) for value in exact]
    for index in sorted(range(len(extras)), key=lambda i: exact[i] - extras[i], reverse=True)[:remaining - sum(extras)]:
        extras[index] += 1
    cursor = 0
    result = []
    for page, extra in zip(pages, extras):
        following = cursor + minimum + extra
        result.append({"text": page, "start": round(cursor / fps, 6), "end": round(following / fps, 6)})
        cursor = following
    return result


def frame_with_caption(source, output, size, caption, title="", transparent=False):
    from PIL import Image, ImageDraw, ImageFilter, ImageOps
    width, height = size
    if transparent:
        canvas = Image.new("RGBA", size, (0, 0, 0, 0))
    else:
        with Image.open(source) as original:
            original.draft("RGB", (width * 2, height * 2))
            original.thumbnail((width * 2, height * 2), Image.Resampling.LANCZOS)
            image = ImageOps.exif_transpose(original).convert("RGB")
        backdrop = ImageOps.fit(image, size, method=Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(max(3, width // 100)))
        foreground = ImageOps.contain(image, size, method=Image.Resampling.LANCZOS)
        backdrop.paste(foreground, ((width - foreground.width) // 2, (height - foreground.height) // 2))
        canvas = backdrop.convert("RGBA")
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    text = str(caption or "").strip()
    scale = max(MIN_CAPTION_FONT, int(height * .044))
    font = image_font(scale)
    lines = wrap_text(text, font, int(width * CAPTION_MAX_WIDTH_FRACTION), MAX_CAPTION_LINES)
    row = int(scale * 1.4)
    pad = max(10, int(height * .025))
    block_height = len(lines) * row + 2 * pad
    top = height - block_height - int(height * .045)
    if lines:
        draw.rounded_rectangle((int(width * .035), top, int(width * .965), top + block_height), radius=pad,
                               fill=(0, 0, 0, 170))
        for index, line in enumerate(lines):
            left = int((width - font.getlength(line)) / 2)
            draw.text((left, top + pad + index * row), line, font=font, fill=(250, 250, 252, 255), stroke_width=0)
    if title:
        label_font = image_font(max(14, int(height * .032)))
        short = wrap_text(title, label_font, int(width * .85), 1, truncate=True)
        if short:
            tw = int(label_font.getlength(short[0]))
            draw.rounded_rectangle((int(width * .04), int(height * .04), int(width * .04) + tw + 2 * pad,
                                    int(height * .04) + int(label_font.size * 1.6)), radius=pad // 2,
                                   fill=(0, 0, 0, 125))
            draw.text((int(width * .04) + pad, int(height * .045)), short[0], font=label_font, fill="white")
    result = Image.alpha_composite(canvas, layer)
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    result.save(output)
    return output


def flat_image_requested(text):
    text = str(text or "")
    return bool(re.search(
        r"纯(?:黑|白|红|蓝|绿|黄|灰|粉|紫|金|银)(?:色)?(?:背景|画面|屏幕|镜头)|"
        r"(?:全黑|全白|纯黑|纯白)(?:画面|背景|屏幕|镜头|开场|结尾)|"
        r"(?:纯色|单色|纯黑色|纯白色)(?:背景|画面|屏幕|镜头)|黑场|白场|"
        r"\b(?:solid[- ]colou?r|flat[- ]colou?r|single[- ]colou?r|"
        r"black\s+screen|white\s+screen|fade\s+to\s+black|"
        r"monochrome\s+(?:background|frame))\b", text, re.I))


def validate_image(path, allow_flat=False, scene_text=None):
    from PIL import Image, ImageStat
    try:
        with Image.open(path) as picture:
            picture.verify()
        with Image.open(path) as picture:
            if min(picture.size) < 128:
                return False, "尺寸过小"
            picture.draft("RGB", (256, 256))
            picture.thumbnail((256, 256))
            gray = picture.convert("L").resize((128, 128))
            spread = ImageStat.Stat(gray).stddev[0]
            if spread < 8 and not (allow_flat or flat_image_requested(scene_text)):
                return False, "画面过于平坦，且当前分镜未要求纯色场景"
        return True, "通过"
    except (OSError, ValueError) as error:
        return False, str(error)


def caption_visible(reference, actual):
    from PIL import Image, ImageOps
    with Image.open(reference) as template, Image.open(actual) as frame:
        reference_image = template.convert("RGBA")
        picture = ImageOps.fit(frame.convert("RGB"), reference_image.size)
        width, height = reference_image.size
        region = (0, int(height * .55), width, height)
        candidate = reference_image.crop(region)
        observed = picture.crop(region)
        source = candidate.getdata()
        dest = observed.getdata()
        meaningful = matched = 0
        glyph_brightness = panel_brightness = panel_pixels = 0
        for rgba, rgb in zip(source, dest):
            brightness = sum(rgb) / 3
            if rgba[3] > 235 and min(rgba[:3]) > 225:
                meaningful += 1
                glyph_brightness += brightness
                if min(rgb) >= 145:
                    matched += 1
            elif 100 <= rgba[3] <= 230 and max(rgba[:3]) <= 45:
                panel_pixels += 1
                panel_brightness += brightness
        threshold = max(18, width * height // 16000)
        contrast = ((glyph_brightness / meaningful) - (panel_brightness / panel_pixels)
                    if meaningful and panel_pixels else 0)
        readable = (meaningful >= threshold and panel_pixels >= threshold * 2
                    and matched / meaningful >= .7 and contrast >= 38)
        return readable, {"white_text_pixels": meaningful,
                          "visible_ratio": round(matched / meaningful, 3) if meaningful else 0,
                          "text_panel_contrast": round(contrast, 2), "panel_pixels": panel_pixels}


def extract_json_object(text):
    begin = str(text).find("{")
    if begin < 0:
        return None
    level = 0
    quoted = False
    escaped = False
    for position in range(begin, len(text)):
        char = text[position]
        if escaped:
            escaped = False
        elif char == "\\" and quoted:
            escaped = True
        elif char == '"':
            quoted = not quoted
        elif not quoted:
            if char == "{":
                level += 1
            elif char == "}":
                level -= 1
                if level == 0:
                    try:
                        return json.loads(text[begin:position + 1])
                    except ValueError:
                        return None
    return None


def validate_plan(plan, count):
    if not isinstance(plan, dict) or not isinstance(plan.get("scenes"), list):
        return False
    scenes = plan["scenes"]
    if len(scenes) != count:
        return False
    if not all(isinstance(scene, dict) and isinstance(scene.get("visual_prompt"), str)
               and len(scene["visual_prompt"].strip()) >= 10
               and isinstance(scene.get("narration"), str)
               and len(scene["narration"].strip()) >= 3 for scene in scenes):
        return False
    return True


def review_failure_type(review):
    if not isinstance(review, dict):
        return "generation_failed"
    if (review.get("temporal_review_passed") is False or
            review.get("action_motion_passed") is False):
        return "motion_insufficient"
    if review.get("technical_passed") is False:
        return "invalid_media"
    if float(review.get("cosine") or 0) < float(review.get("required_cosine", MIN_CLIP_COSINE)):
        return "subject_mismatch"
    if float(review.get("margin") if review.get("margin") is not None else -1) < float(
            review.get("required_margin", MIN_CLIP_MARGIN)):
        return "semantic_ambiguous"
    return "composition_or_continuity"


def visual_constraints(text):
    source = str(text).lower()
    colors = {"红色": "red", "蓝色": "blue", "绿色": "green", "黄色": "yellow",
              "黑色": "black", "白色": "white", "紫色": "purple", "粉色": "pink",
              "金色": "gold", "银色": "silver"}
    anchors = [english for chinese, english in colors.items() if chinese in source]
    anchors.extend(re.findall(r"\b(?:red|blue|green|yellow|black|white|purple|pink|gold|silver)\b", source))
    subjects = {"孩子": "children", "小孩": "children", "儿童": "children", "男孩": "boys",
                "女孩": "girls", "宝宝": "babies", "婴儿": "babies", "人物": "people",
                "人": "people", "男性": "men", "男人": "men", "女性": "women", "女人": "women",
                "猫": "cats", "小猫": "cats", "狗": "dogs", "小狗": "dogs", "马": "horses",
                "树": "trees", "花": "flowers", "汽车": "cars", "轿车": "cars",
                "车": "vehicles", "卡车": "trucks", "自行车": "bicycles", "鸟": "birds",
                "飞机": "airplanes", "椅子": "chairs", "房子": "houses", "建筑": "buildings",
                "角色": "characters", "演员": "actors", "学生": "students", "机器人": "robots",
                "气球": "balloons", "星星": "stars", "桌子": "tables", "杯子": "cups",
                "苹果": "apples", "橙子": "oranges", "手机": "phones", "电脑": "computers"}
    chinese_count = re.compile(r"(?<!\d)(?P<count>\d{1,3}|[一二两三四五六七八九十百]{1,4})"
                               r"\s*(?:个|只|人|位|辆|台|棵|朵|把|条|头|匹|枚|架|张|名|颗|对|组)?"
                               r"\s*(?P<subject>" + "|".join(sorted(subjects, key=len, reverse=True)) + r")")
    for match in chinese_count.finditer(source):
        count = chinese_duration_number(match.group("count"))
        if count and count.is_integer() and count <= 100:
            anchors.append("%d %s" % (int(count), subjects[match.group("subject")]))
    english_subjects = (r"children|kids|boys|girls|babies|people|persons|men|women|cats?|dogs?|"
                        r"horses?|trees?|flowers?|cars?|vehicles?|trucks?|bicycles?|birds?|"
                        r"airplanes?|chairs?|houses?|buildings?|characters?|actors?|students?|"
                        r"robots?|balloons?|stars?|tables?|cups?|apples?|oranges?|phones?|computers?")
    english_counts = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4,
                      "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
                      "ten": 10, "eleven": 11, "twelve": 12}
    for match in re.finditer(r"\b(?P<count>\d{1,3}|" + "|".join(english_counts) +
                             r")\s+(?:(?:young|old|small|big|happy|white|black|red|blue|"
                             r"green|yellow|tiny|large|little|adult|cute|beautiful)\s+){0,3}"
                             r"(?P<subject>" + english_subjects + r")\b", source):
        token = match.group("count")
        count = int(token) if token.isdigit() else english_counts.get(token)
        if count and count <= 100:
            anchors.append("%d %s" % (count, match.group("subject")))
    return list(dict.fromkeys(anchors))



def strict_visual_quantities(prompt):
    source = str(prompt)
    targets = []
    for anchor in visual_constraints(source):
        found = re.fullmatch(r"(\d+)\s+([a-z]+)", anchor)
        if not found:
            continue
        count, subject = int(found.group(1)), found.group(2)
        targets.append({"count": count, "subject": subject, "anchor": anchor,
                        "comparison": "exact", "requires_instance_detection": True})
    return targets[:MAX_VISUAL_CONSTRAINT_PROBES]


def exact_screen_text_requirements(prompt):
    source = str(prompt)
    requirement = (r"(?:画面(?:上|中)?(?:必须|需要|要)?(?:显示|写上|写着)|"
                   r"屏幕(?:上|中)?(?:必须|需要|要)?(?:显示|写上|写着)|"
                   r"(?:招牌|标牌|牌子)(?:上)?(?:写着|显示|是)|"
                   r"(?:必须|务必|需要|要)显示(?:文字|文本|字样)?|(?:显示|写上)(?:文字|文本|字样)|"
                   r"on[ -]?screen\s+text|display\s+(?:the\s+)?(?:text|words?)|"
                   r"sign\s+(?:that\s+)?(?:says|reads))")
    pattern = re.compile(requirement + r"\s*[:：=为是]?\s*(?P<content>[^\n\r，,。.!！?？;；]{1,110})", re.I)
    result = []
    for match in pattern.finditer(source):
        content = match.group("content").strip()
        quoted = re.match(r"^[\"'“‘「『]([^\"'”’」』]{1,80})[\"'”’」』]", content)
        if quoted:
            value = quoted.group(1).strip()
        else:
            value = re.split(r"(?:\s*(?:然后|接着|并且|同时|再|且|而且|背景|持续|字体|位置|颜色|大小|时长|片长|秒后|秒时)\b|[（(])", content, maxsplit=1)[0]
            value = re.sub(r"^(?:屏幕|画面|上的?|中的?|字幕|文字|文本|字样)[:：]?", "", value).strip()
            value = value.strip(' \"\'“”‘’「」『』：:')
        if not value or len(value) > 80 or value in {"文字", "文本", "一些文字", "一段文字", "一行文字", "字幕", "指定文字"}:
            continue
        result.append(value)
    unique = list(dict.fromkeys(result))
    if len(unique) > MAX_VISUAL_TEXT_PROBES:
        raise RuntimeError("用户指定的准确屏幕文字条目超过当前可逐条OCR复核的数量，不能静默省略")
    return unique


def exact_text_probe_schedule(phrase, scenes, scene_durations, overlay_records, captions, fps, max_probes=MAX_VISUAL_TEXT_PROBES):
    timelines = []
    cursor = 0.0
    for index, duration in enumerate(scene_durations or []):
        duration = float(duration)
        overlays = overlay_records.get(index, []) if isinstance(overlay_records, dict) else []
        if not isinstance(overlays, list):
            overlays = []
        caption = captions[index] if isinstance(captions, list) and index < len(captions) else {}
        if not isinstance(caption, dict):
            caption = {}
        segments = list(overlays) + list(caption.get("segments", []))
        for item in segments:
            if not isinstance(item, dict):
                continue
            texts = item.get("required_screen_text", [])
            active = (phrase in texts if isinstance(texts, list) else False) or (
                normalized_caption(phrase) in normalized_caption(item.get("text", "")))
            if not active:
                continue
            start, end = float(item.get("start", 0)), float(item.get("end", duration))
            if 0 <= start < end <= duration + 1 / max(1, fps):
                timelines.append((index, cursor + start, cursor + min(duration, end), "explicit_text_overlay"))
        cursor += duration
    if not timelines:
        cursor = 0.0
        for index, duration in enumerate(scene_durations or []):
            scene = scenes[index] if index < len(scenes) else {}
            if (phrase in str(scene.get("visual_prompt", "")) or
                    phrase in str(scene.get("narration", ""))):
                timelines.append((index, cursor, cursor + float(duration), "scene_plan_only"))
            cursor += float(duration)
    if not timelines:
        cursor = 0.0
        for index, duration in enumerate(scene_durations or []):
            timelines.append((index, cursor, cursor + float(duration), "unlocated_text"))
            cursor += float(duration)
    points = []
    for index, start, end, kind in timelines:
        length = end - start
        if length <= 0:
            continue
        fractions = (.25, .5, .75) if length >= 6 / max(1, fps) else (.5,)
        for fraction in fractions:
            position = round(start + length * fraction, 5)
            points.append({"scene": index, "position": position, "basis": kind,
                           "window": [round(start, 5), round(end, 5)]})
    unique = list({(entry["scene"], entry["position"]): entry for entry in points}.values())
    return {"probes": unique[:max_probes], "expected_probes": len(unique),
            "incomplete": len(unique) > max_probes,
            "timelines": len(timelines), "overlay_grounded": bool(timelines and
                all(entry[3] == "explicit_text_overlay" for entry in timelines))}


def quantity_subject_label(subject):
    exceptions = {"children": "child", "people": "person", "men": "man", "women": "woman",
                  "babies": "baby", "bicycles": "bicycle", "horses": "horse",
                  "vehicles": "vehicle", "phones": "phone", "buses": "bus",
                  "characters": "person", "actors": "person", "students": "person"}
    return exceptions.get(subject, subject[:-1] if subject.endswith("s") and not subject.endswith("ss") else subject)


def independent_instance_count(detections, low=DETECTOR_SCORE_LOW, high=DETECTOR_SCORE_HIGH,
                               overlap=DETECTOR_NMS_IOU):
    chosen = []
    for item in sorted(detections, key=lambda value: value["score"], reverse=True):
        score = float(item["score"])
        box = item["box"]
        if score < low or len(box) != 4 or not all(math.isfinite(float(v)) for v in box):
            continue
        x1, y1, x2, y2 = map(float, box)
        if x2 <= x1 or y2 <= y1:
            continue
        keep = True
        for previous in chosen:
            a, b, c, d = previous["box"]
            intersection = max(0, min(x2, c) - max(x1, a)) * max(0, min(y2, d) - max(y1, b))
            union = (x2 - x1) * (y2 - y1) + (c - a) * (d - b) - intersection
            if union > 0 and intersection / union >= overlap:
                keep = False
                break
        if keep:
            chosen.append({"score": score, "box": [x1, y1, x2, y2]})
    return {"strong_count": sum(item["score"] >= high for item in chosen),
            "possible_count": len(chosen),
            "instances": [{"confidence": round(item["score"], 4),
                           "box": [round(value, 1) for value in item["box"]]} for item in chosen]}

def quantity_comparison_prompts(anchor):
    match = re.fullmatch(r"(\d+)\s+([a-z]+)", str(anchor).strip().lower())
    if not match:
        return []
    amount, subject = int(match.group(1)), match.group(2)
    alternatives = sorted({max(0, amount - 1), amount + 1, amount + 2} - {amount})
    labels = [amount] + alternatives
    singular = {"children": "child", "people": "person", "men": "man", "women": "woman",
                "babies": "baby", "bicycles": "bicycle", "vehicles": "vehicle",
                "horses": "horse", "phones": "phone", "buses": "bus"}.get(
                    subject, subject[:-1] if subject.endswith("s") and not subject.endswith("ss") else subject)
    return [("A detailed photograph showing no %s, none visible." % subject if count == 0 else
             "A detailed photograph showing exactly %d %s, all clearly visible, no others." % (
                 count, singular if count == 1 else subject)) for count in labels]

def visual_constraints_retained(text, anchors):
    normalized = re.sub(r"\s+", " ", str(text).lower())
    count_words = {1: "one|a|an", 2: "two", 3: "three", 4: "four", 5: "five",
                   6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
                   11: "eleven", 12: "twelve"}
    aliases = {"children": "children|kids|child", "people": "people|persons?|humans?",
               "men": "men|males?", "women": "women|females?", "babies": "bab(?:y|ies)|infants?",
               "vehicles": "vehicles?|cars?|automobiles?", "cars": "cars?|automobiles?|vehicles?",
               "airplanes": "airplanes?|planes?|aircraft", "bicycles": "bicycles?|bikes?",
               "phones": "phones?|smartphones?", "characters": "characters?|roles?",
               "houses": "houses?|homes?", "buildings": "buildings?|structures?"}
    for anchor in anchors:
        quantity = re.fullmatch(r"(\d+) ([a-z]+)", str(anchor).lower())
        if quantity:
            number, kind = quantity.groups()
            count = int(number)
            units = aliases.get(kind, re.escape(kind.rstrip("s")) + r"s?")
            numbers = re.escape(number) + ("|" + count_words[count] if count in count_words else "")
            pattern = (r"\b(?:" + numbers + r")\b(?:[\s,-]+[a-z]+){0,4}[\s,-]+"
                       r"(?:" + units + r")\b")
            if not re.search(pattern, normalized, re.I):
                return False
        elif not re.search(r"\b" + re.escape(str(anchor)) + r"\b", normalized, re.I):
            return False
    return True

def refine_visual_prompt(prompt, review, attempt, user_constraints=""):
    original = re.sub(r"\s+", " ", str(prompt)).strip()[:360]
    corrections = {
        "generation_failed": "Use a simple, recognizable scene with stable geometry and clear subject boundaries.",
        "invalid_media": "Avoid artifacts, invalid textures and incoherent shapes; keep a fully visible subject.",
        "subject_mismatch": "Make the exact subject and requested attributes visually unmistakable.",
        "semantic_ambiguous": "Emphasize the original scene rather than a generic landscape or unrelated symbols.",
        "motion_insufficient": "Visible progression and changing physical positions, not a still image.",
        "composition_or_continuity": "Preserve scene identity with natural perspective and consistent lighting."
    }
    cause = review_failure_type(review)
    anchors = visual_constraints(user_constraints + " " + original)
    keep = (" Keep these explicit attributes unchanged: " + ", ".join(anchors[:12]) + ".") if anchors else ""
    return (original + " " + corrections[cause] + keep +
            " Keep all explicitly requested subjects, quantities and colors unchanged.")[:610]


def visual_review_record(technical_passed, semantic=None, constraint_passed=True,
                         supplied=False, reason=""):
    semantic_ok = semantic.get("passed") if isinstance(semantic, dict) else None
    state = ("invalid" if not technical_passed else "constraint_failed" if not constraint_passed else
             "unreviewed" if semantic_ok is None else "accepted" if semantic_ok else
             "supplied_conflict" if supplied else "rejected")
    return {"technical_passed": bool(technical_passed), "semantic_passed": semantic_ok,
            "constraints_passed": bool(constraint_passed),
            "overall_passed": bool(technical_passed and constraint_passed and semantic_ok is True),
            "review_status": state, "failure_type": review_failure_type(semantic) if semantic_ok is False else "",
            "reason": str(reason)[:200], "user_supplied": bool(supplied),
            "passed": bool(technical_passed and constraint_passed and semantic_ok is True)}


def normalize_spoken_text(value):
    return "".join(re.findall(r"[\u3400-\u9fffA-Za-z0-9]+", str(value).lower()))


def voice_presence_correlation(original, mixed, limit_seconds=MAX_VOICE_CORRELATION_SECONDS):
    import numpy as np
    arrays = []
    for path in (original, mixed):
        with wave.open(str(path), "rb") as stream:
            if (stream.getnchannels() != 1 or stream.getsampwidth() != 2 or
                    stream.getframerate() != SPEECH_RATE):
                raise ValueError("语音相关性检查需要 16 kHz 单声道 PCM")
            raw = stream.readframes(int(limit_seconds * SPEECH_RATE))
        arrays.append(np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0)
    first, second = arrays
    count = min(len(first), len(second))
    if count < SPEECH_RATE // 3:
        return 0.0
    first = first[:count].astype(np.float64)
    second = second[:count].astype(np.float64)
    first -= first.mean()
    second -= second.mean()
    denominator = math.sqrt(float(np.dot(first, first)) * float(np.dot(second, second)))
    if denominator < 1e-7:
        return 0.0
    length = 1 << (2 * count - 1).bit_length()
    cross = np.fft.irfft(np.fft.rfft(second, n=length) *
                         np.conj(np.fft.rfft(first, n=length)), n=length)
    shift = min(int(MAX_VOICE_ALIGNMENT_SECONDS * SPEECH_RATE), count // 4)
    values = np.concatenate((cross[-shift:], cross[:shift + 1]))
    return max(0.0, min(1.0, float(np.max(values)) / denominator))


def speech_record_verified(review):
    if review.get("status") != "reviewed":
        return False
    original = review.get("source")
    mixed = review.get("mixed")
    if not isinstance(original, dict) or not isinstance(mixed, dict):
        return False
    if original.get("status") == "empty_expected":
        return mixed.get("status") == "empty_expected"
    if original.get("status") != "matched":
        return False
    if mixed.get("status") == "matched":
        return True
    return bool(
        mixed.get("status") == "needs_manual_check"
        and float(mixed.get("score", 0)) >= MIN_SPEECH_SIMILARITY
        and float(review.get("voice_correlation", 0)) >= MIN_STRONG_VOICE_CORRELATION
        and float(review.get("mixed_rms", 0)) >= MIN_MIXED_VOICE_RMS
    )


def speech_review_failure(review):
    state = review.get("status")
    if state == "missing_voice":
        return "SPEECH_SOURCE_MISSING"
    if state == "mix_extract_failed":
        return "MIXED_AUDIO_EXTRACTION_FAILED"
    if state == "recognition_unavailable":
        return "SPEECH_REVIEW_UNAVAILABLE"
    if state == "mix_voice_missing":
        return "MIXED_VOICE_MISSING"
    if state != "reviewed":
        return "SPEECH_REVIEW_UNAVAILABLE"
    original = review.get("source", {})
    mixed = review.get("mixed", {})
    if not isinstance(original, dict) or not isinstance(mixed, dict):
        return "SPEECH_REVIEW_UNAVAILABLE"
    if original.get("status") == "suspected_mismatch":
        return "SPEECH_SOURCE_MISMATCH"
    if mixed.get("status") == "suspected_mismatch":
        return "MIXED_SPEECH_MISMATCH"
    if (mixed.get("observed_length", 0) == 0 and
            original.get("status") == "matched"):
        return "MIXED_SPEECH_MISMATCH"
    if speech_record_verified(review):
        return None
    return "SPEECH_REVIEW_INCONCLUSIVE"


def speech_match(expected, observed):
    expected_text = normalize_spoken_text(expected)
    observed_text = normalize_spoken_text(re.sub(r"\[\d+秒\]", " ", str(observed)))
    if not expected_text:
        return {"score": 1.0, "status": "empty_expected", "expected_length": 0,
                "observed_length": len(observed_text)}
    score = difflib.SequenceMatcher(None, expected_text, observed_text, autojunk=False).ratio()
    if len(expected_text) < MIN_SPEECH_REVIEW_CHARS:
        status = "matched" if expected_text == observed_text else "not_confident"
    elif score < MIN_SPEECH_SIMILARITY:
        status = "suspected_mismatch"
    elif score < MIN_SPEECH_STRONG_MATCH:
        status = "needs_manual_check"
    else:
        status = "matched"
    return {"score": round(score, 4), "status": status,
            "expected_length": len(expected_text), "observed_length": len(observed_text),
            "observed_excerpt": observed_text[:90]}


def fallback_plan(prompt, count, seconds):
    trimmed = re.sub(r"\s+", " ", prompt).strip()[:220]
    phrases = [part.strip() for part in re.split(r"[。！？；;，,\n]+", trimmed) if part.strip()]
    if not phrases:
        phrases = ["用户指定的主题"]
    stages = ("交代核心主题", "展现重要细节", "推进关键内容", "呈现不同视角", "强化重点信息", "收束主题与情绪")
    views = ("wide establishing shot", "medium narrative shot", "detailed close-up", "side angle",
             "cinematic perspective", "gentle concluding shot")
    scenes = []
    for i in range(count):
        index = min(len(stages) - 1, int(i * len(stages) / count))
        focus = phrases[i % len(phrases)]
        introduction = ("开场先看" if i == 0 else "最后回到" if i == count - 1 else "接着呈现")
        narration = short_narration(introduction + focus, 30)
        visual = ("A coherent cinematic %s illustrating: %s. Consistent subject identity, realistic details, "
                  "natural lighting, purposeful composition" % (views[index], focus))
        scenes.append({"narration": narration, "visual_prompt": visual[:330],
                       "seconds": round(seconds / count, 2)})
    return {"title": trimmed[:36] or "AI 创作", "mood": "inspiring", "scenes": scenes}


def normalize_plan(proposed, prompt, count, seconds):
    fallback = fallback_plan(prompt, count, seconds)
    if not isinstance(proposed, dict):
        return fallback
    given = proposed.get("scenes")
    if not isinstance(given, list):
        given = []
    scenes = []
    for index in range(count):
        entry = given[index] if index < len(given) and isinstance(given[index], dict) else {}
        baseline = fallback["scenes"][index]
        narration = str(entry.get("narration", "")).strip()
        visual = str(entry.get("visual_prompt", "")).strip()
        scenes.append({"narration": narration[:130] if narration_units(narration) >= 3 else baseline["narration"],
                       "visual_prompt": visual[:340] if len(visual) >= 10 else baseline["visual_prompt"],
                       "seconds": baseline["seconds"]})
    mood = str(proposed.get("mood", "inspiring"))
    if mood not in {"warm", "calm", "mysterious", "energetic", "inspiring"}:
        mood = "inspiring"
    title = str(proposed.get("title") or fallback["title"]).strip()[:45]
    return {"title": title, "mood": mood, "scenes": scenes}

def pdf_ocr_text(path, pages=None):
    import numpy as np
    import pypdfium2
    from rapidocr import RapidOCR
    engine = RapidOCR()
    document = pypdfium2.PdfDocument(str(path))
    count = len(document)
    targets = pages if pages is not None else range(count)
    extracted = {}
    total = 0
    try:
        for index in targets:
            if index < 0 or index >= count or total >= MAX_DOCUMENT_TEXT:
                break
            page = document[index]
            try:
                width, height = page.get_size()
                usable = max(0, memory_info().get("available", 0) - MIN_SYSTEM_MEMORY_HEADROOM)
                if usable < 128 * 1024 * 1024:
                    raise MemoryError("文档 OCR 所需内存不足")
                max_pixels = max(256 * 256, min(6 * 1024 * 1024, usable // 40))
                scale = min(OCR_PAGE_SCALE, 2400 / max(width, height),
                            math.sqrt(max_pixels / max(1.0, width * height)))
                if scale < .65:
                    raise RuntimeError("该PDF页面过大，当前安全内存无法以可靠清晰度完成OCR")
                with page.render(scale=scale).to_pil() as bitmap:
                    image = np.asarray(bitmap.convert("RGB"))
                answer = engine(image)
                lines = [str(item).strip() for item in (getattr(answer, "txts", None) or [])
                         if str(item).strip()]
                extracted[index] = " ".join(lines)[:max(0, MAX_DOCUMENT_TEXT - total)]
                total += len(extracted[index])
            finally:
                page.close()
    finally:
        document.close()
    return extracted


def read_docx_structured(path):
    import xml.etree.ElementTree as ET
    word = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    drawing = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    embed = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed"
    relation = "{http://schemas.openxmlformats.org/package/2006/relationships}"
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        xml_size = sum(item.file_size for item in archive.infolist()
                       if item.filename.endswith((".xml", ".rels")))
        if xml_size > MAX_DOCUMENT_BYTES:
            raise ValueError("DOCX 展开后的 XML 大小超过安全限制")
        if "word/document.xml" not in names:
            raise ValueError("DOCX 缺少正文结构")
        if archive.getinfo("word/document.xml").file_size > MAX_DOCUMENT_XML_BYTES:
            raise ValueError("DOCX 正文结构超过安全限制")
        structure = ET.fromstring(archive.read("word/document.xml"))
        references = {}
        if "word/_rels/document.xml.rels" in names:
            links = ET.fromstring(archive.read("word/_rels/document.xml.rels"))
            for item in links.findall(relation + "Relationship"):
                target = item.attrib.get("Target", "")
                if item.attrib.get("TargetMode") == "External" or not target:
                    continue
                normalized = posixpath.normpath(posixpath.join("word", target))
                if normalized.startswith("word/") and normalized in names:
                    references[item.attrib.get("Id", "")] = normalized
        cache = {}
        seen = set()
        output = []
        incomplete = False
        ocr_engine = None
        def extract_image(rid):
            nonlocal incomplete, ocr_engine
            source = references.get(rid)
            if not source:
                incomplete = True
                return DOC_VISUAL_UNVERIFIED_MARKER
            if source in cache:
                return cache[source]
            if len(cache) >= MAX_DOCX_EMBEDDED_IMAGES:
                incomplete = True
                return DOC_VISUAL_UNVERIFIED_MARKER
            item = archive.getinfo(source)
            if item.file_size > MAX_DOCX_EMBEDDED_BYTES:
                incomplete = True
                return DOC_VISUAL_UNVERIFIED_MARKER
            try:
                from PIL import Image
                import numpy as np
                from rapidocr import RapidOCR
                with Image.open(io.BytesIO(archive.read(source))) as bitmap:
                    if bitmap.width * bitmap.height > MAX_DOCX_EMBEDDED_IMAGE_PIXELS:
                        bitmap.thumbnail((2400, 2400))
                    picture = np.asarray(bitmap.convert("RGB"))
                if ocr_engine is None:
                    ocr_engine = RapidOCR()
                recognized = ocr_engine(picture)
                words = [str(value).strip() for value in (getattr(recognized, "txts", None) or [])
                         if str(value).strip()]
                text = " ".join(words)[:1800]
            except (ImportError, OSError, ValueError, RuntimeError, zipfile.BadZipFile):
                text = ""
            incomplete = True
            cache[source] = ("[嵌入图片 %s OCR文字：%s] " % (Path(source).name, text)
                             if text else "[嵌入图片 %s 无可靠文本识别] " % Path(source).name) + DOC_VISUAL_UNVERIFIED_MARKER
            return cache[source]
        def paragraph(element):
            fragments = []
            for node in element.iter():
                if node.tag == word + "t" and node.text:
                    fragments.append(node.text)
                elif node.tag == word + "tab":
                    fragments.append("\t")
                elif node.tag in {word + "br", word + "cr"}:
                    fragments.append("\n")
                elif node.tag == drawing + "blip":
                    key = node.attrib.get(embed)
                    if key and key not in seen:
                        seen.add(key)
                        fragments.append(" " + extract_image(key) + " ")
            return "".join(fragments).strip()
        def visit(container):
            for child in container:
                if child.tag == word + "p":
                    text = paragraph(child)
                    if text:
                        output.append(text)
                elif child.tag == word + "tbl":
                    output.append("[文档表格]")
                    for row in child.findall(word + "tr"):
                        cells = []
                        for cell in row.findall(word + "tc"):
                            cells.append("；".join(filter(None, (paragraph(n) for n in cell.iter(word + "p")))))
                        output.append("\t".join(cells))
                else:
                    visit(child)
        visit(structure)
        if incomplete and DOC_VISUAL_UNVERIFIED_MARKER not in " ".join(output):
            output.append(DOC_VISUAL_UNVERIFIED_MARKER)
        return "\n".join(output)[:MAX_DOCUMENT_TEXT]


def document_text(path):
    path = Path(path)
    extension = path.suffix.lower()
    size = path.stat().st_size
    if size > MAX_DOCUMENT_BYTES:
        raise ValueError("文档超过可安全解析的大小上限（%d MB）" % (MAX_DOCUMENT_BYTES // (1024 * 1024)))
    if extension in {".txt", ".md", ".csv", ".json", ".srt"}:
        with path.open("rb") as handle:
            contents = handle.read(min(size, MAX_DOCUMENT_BYTES))
        if contents.startswith((b"\xff\xfe", b"\xfe\xff")):
            encodings = ("utf-16", "utf-8-sig", "gb18030")
        elif contents[:128].count(b"\x00") > 12:
            odd_nulls = contents[1:128:2].count(0)
            even_nulls = contents[0:128:2].count(0)
            encodings = (("utf-16-le" if odd_nulls > even_nulls else "utf-16-be"), "utf-8-sig", "gb18030")
        else:
            encodings = ("utf-8-sig", "gb18030")
            try:
                utf8_text = contents[:2048].decode("utf-8-sig")
                utf8_error = None
            except UnicodeDecodeError as error:
                utf8_text = ""
                utf8_error = error
            unusual_controls = sum(ord(char) < 32 and char not in "\n\r\t" for char in utf8_text)
            suspicious_utf8 = bool(utf8_text and unusual_controls > max(2, len(utf8_text) // 80))
            if suspicious_utf8 or (utf8_error is not None and not (
                    utf8_error.reason == "unexpected end of data" and utf8_error.start >= len(contents) - 4)):
                ratings = []
                for candidate in ("utf-16-le", "utf-16-be"):
                    try:
                        sample = contents[:2048].decode(candidate)
                    except UnicodeDecodeError:
                        continue
                    meaningful = sum("\u3400" <= char <= "\u9fff" for char in sample)
                    controls = sum(ord(char) < 32 and char not in "\n\r\t" for char in sample)
                    if len(sample) >= 8 and controls == 0:
                        ratings.append((meaningful / len(sample), candidate))
                ratings.sort(reverse=True)
                if ratings and ratings[0][0] > .7 and (
                        len(ratings) == 1 or ratings[0][0] - ratings[1][0] > .1):
                    encodings = (ratings[0][1], "utf-8-sig", "gb18030")
        for encoding in encodings:
            try:
                return contents.decode(encoding)[:MAX_DOCUMENT_TEXT]
            except UnicodeDecodeError as error:
                if error.reason == "unexpected end of data" and error.start >= len(contents) - 4:
                    return contents[:error.start].decode(encoding)[:MAX_DOCUMENT_TEXT]
                continue
    if extension in {".htm", ".html"}:
        with path.open("rb") as handle:
            contents = handle.read(min(size, MAX_DOCUMENT_BYTES))
        return clean_html(contents.decode("utf-8-sig", errors="replace"))[:MAX_DOCUMENT_TEXT]
    if extension == ".pdf":
        from pypdf import PdfReader
        with path.open("rb") as stream:
            reader = PdfReader(stream, strict=False)
            count = len(reader.pages)
            if count == 0:
                return ""
            indexes = range(count)
            extracted = {}
            uncertain = []
            scanned = []
            for index in indexes:
                page = reader.pages[index]
                try:
                    fragment = (page.extract_text() or "").strip()
                except (RuntimeError, ValueError, TypeError, KeyError, OSError):
                    fragment = ""
                extracted[index] = fragment
                try:
                    resources = page.get("/Resources")
                    if hasattr(resources, "get_object"):
                        resources = resources.get_object()
                    has_xobjects = bool(resources and hasattr(resources, "get") and
                                        resources.get("/XObject"))
                    has_content = bool(page.get_contents())
                except (ValueError, TypeError, KeyError, OSError, RuntimeError):
                    has_xobjects = True
                    has_content = True
                if has_content and (len(re.sub(r"\s+", "", fragment)) < PDF_PAGE_TEXT_MIN_CHARS or
                                    has_xobjects):
                    scanned.append(index)
                    if len(re.sub(r"\s+", "", fragment)) < PDF_PAGE_TEXT_MIN_CHARS:
                        uncertain.append(index)
                extracted[(index, "contains_images")] = bool(has_xobjects)
        recognized = {}
        ocr_error = None
        if scanned:
            try:
                recognized = pdf_ocr_text(path, pages=scanned)
            except (ImportError, ModuleNotFoundError, RuntimeError, ValueError, OSError) as error:
                ocr_error = type(error).__name__
        result = []
        total = 0
        uncertain_set = set(uncertain)
        for index in indexes:
            fragment = extracted.get(index, "")
            scanned_text = str(recognized.get(index, "")).strip()
            if scanned_text and not fragment:
                fragment = scanned_text
            elif scanned_text and scanned_text not in fragment:
                fragment += " [扫描页补充] " + scanned_text
            if index in uncertain_set and not scanned_text:
                fragment = (fragment + "\n" if fragment else "") + (
                    PDF_OCR_MISSING_MARKER + " %d 页：%s]" % (
                        index + 1, "OCR 未安装" if ocr_error else "扫描内容无法辨认"))
            if extracted.get((index, "contains_images")):
                fragment += " " + DOC_VISUAL_UNVERIFIED_MARKER
            if fragment:
                entry = "[第 %d 页] %s" % (index + 1, fragment)
                entry = entry[:max(0, MAX_DOCUMENT_TEXT - total)]
                if entry:
                    result.append(entry)
                    total += len(entry)
                if total >= MAX_DOCUMENT_TEXT:
                    break
        if count > len(result) and sum(len(str(value)) for value in extracted.values()) >= MAX_DOCUMENT_TEXT:
            result.append("[文档超长：后续页面未完整纳入，请拆分为多个文件以可靠处理]")
        return "\n".join(result)[:MAX_DOCUMENT_TEXT]
    if extension == ".docx":
        return read_docx_structured(path)
    return ""


def document_text_controlled(path, root, log, cancel=None):
    path = Path(path)
    if path.suffix.lower() not in {".pdf", ".docx"}:
        return document_text(path)
    temporary = Path(root) / ".studio" / "tmp" / ("document_" + secrets.token_hex(12) + ".txt")
    try:
        estimated = min(600, max(90, int(path.stat().st_size / (128 * 1024)) + 90))
        if path.suffix.lower() == ".pdf":
            try:
                from pypdf import PdfReader
                with path.open("rb") as source:
                    page_count = len(PdfReader(source, strict=False).pages)
                estimated = max(estimated, min(7200, 90 + page_count * 18))
            except (ImportError, OSError, ValueError, RuntimeError):
                pass
        run_external([str(runtime_python(root)), str(Path(__file__).resolve()), "--read-document",
                      str(root), str(path), str(temporary)], root, log=log, cancel=cancel,
                     timeout=estimated, capture=True, env=shell_env(root, offline=True))
        return temporary.read_text(encoding="utf-8")[:MAX_DOCUMENT_TEXT]
    finally:
        temporary.unlink(missing_ok=True)



def localize_request_assets(root, request, job, cancel=None, log=None, prior=None):
    root = Path(root).resolve()
    job = Path(job).resolve()
    destination = job / "sources"
    destination.mkdir(parents=True, exist_ok=True)
    old_manifest = (prior or {}).get("source_manifest", [])
    old_manifest = old_manifest if isinstance(old_manifest, list) else []
    mapped = {}
    manifest = []
    for category, files in request.get("files", {}).items():
        output = []
        for index, filename in enumerate(files):
            if cancel is not None and cancel.is_set():
                raise InterruptedError("复制素材时已停止")
            original = str(filename)
            source = Path(original)
            saved = next((record for record in old_manifest if isinstance(record, dict) and
                          record.get("category") == category and record.get("index") == index and
                          record.get("name", "").casefold() == source.name.casefold()), None)
            if source.is_symlink():
                raise ValueError("禁止使用符号链接作为输入素材：" + source.name)
            if source.is_file() and saved is not None and verified_local_source(saved, root) and (
                    source.stat().st_size != saved["bytes"] or
                    file_integrity_hash(source) != saved["sample_hash"]):
                raise ValueError("外部素材已发生内容变化，请作为新任务重新启动：" + source.name)
            if not source.is_file() and saved is not None and verified_local_source(saved, root):
                source = Path(saved["copy"])
                if log:
                    log("外部素材已离线恢复：" + Path(original).name)
            if not source.is_file() or source.is_symlink():
                raise FileNotFoundError("原始文件不可访问，工作目录也没有完整副本：" + Path(original).name)
            resolved = source.resolve(strict=True)
            size = resolved.stat().st_size
            signature = file_integrity_hash(resolved)
            inside = resolved == root or root in resolved.parents
            if inside:
                target = resolved
            else:
                required = MIN_JOB_FREE + size + min(SOURCE_COPY_CHUNK * 4, size)
                if shutil.disk_usage(root).free < required:
                    raise RuntimeError("复制 %s 需要 %.2f GB 可用空间" % (
                        source.name, required / GB))
                identity = hashlib.sha256((category + ":" + source.name.casefold() + ":" +
                                           str(size) + ":" + signature).encode("utf-8")).hexdigest()[:24]
                target = destination / (identity + resolved.suffix.lower())
                if (not target.is_file() or target.is_symlink() or target.stat().st_size != size or
                        file_integrity_hash(target) != signature):
                    stage = target.with_suffix(target.suffix + ".partial")
                    try:
                        with resolved.open("rb") as reader, stage.open("wb") as writer:
                            while True:
                                if cancel is not None and cancel.is_set():
                                    raise InterruptedError("复制素材已停止")
                                block = reader.read(SOURCE_COPY_CHUNK)
                                if not block:
                                    break
                                writer.write(block)
                        if stage.stat().st_size != size or file_integrity_hash(stage) != signature:
                            raise RuntimeError("素材在复制期间发生变化：" + source.name)
                        os.replace(stage, target)
                    finally:
                        stage.unlink(missing_ok=True)
                if log:
                    log("已安全缓存素材：" + source.name)
            digest = (saved.get("sha256") if saved and saved.get("sample_hash") == signature and
                      target == Path(saved.get("copy", "")) and verified_local_source(saved, root)
                      else full_file_sha256(target))
            item = {"category": category, "index": index, "name": Path(original).name,
                    "original": original, "copy": str(target), "bytes": size,
                    "sample_hash": signature, "sha256": digest,
                    "stored_in_workspace": bool(inside)}
            manifest.append(item)
            mapped[original] = item
            output.append(str(target))
            if prior is not None:
                prior["source_manifest"] = manifest + [record for record in old_manifest
                    if isinstance(record, dict) and (record.get("category"), record.get("index")) not in
                    {(saved_item["category"], saved_item["index"]) for saved_item in manifest}]
                atomic_json(job / "job.json", prior)
        request["files"][category] = output
    if prior is not None:
        prior["source_manifest"] = manifest
        atomic_json(job / "job.json", prior)
    return mapped


def clean_html(data):
    data = re.sub(r"(?is)<(script|style|noscript|svg|nav|footer|header)\b[^>]*>.*?</\1>", " ", data)
    data = re.sub(r"(?is)<[^>]+>", " ", data)
    data = html.unescape(data)
    return re.sub(r"\s+", " ", data).strip()


def png_or_video_image(path, output, root, log, cancel=None):
    path = Path(path)
    if path.suffix.lower() in IMAGE_TYPES:
        return path
    flags = [ffmpeg_executable(), "-hide_banner", "-loglevel", "error", "-y", "-i", path,
             "-vf", "select=eq(n\\,0),scale=720:720:force_original_aspect_ratio=decrease",
             "-frames:v", "1", output]
    run_external(flags, root, log=log, cancel=cancel, timeout=FFMPEG_INPUT_TIMEOUT, capture=True)
    return Path(output)


def audio_seconds(path):
    try:
        with wave.open(str(path), "rb") as audio:
            return audio.getnframes() / audio.getframerate()
    except (OSError, wave.Error, ZeroDivisionError):
        return 0.0


def probe_media_seconds(source, ffmpeg=None):
    ffmpeg = ffmpeg or ffmpeg_executable()
    try:
        child = subprocess.run([ffmpeg, "-hide_banner", "-i", str(source)], capture_output=True,
                               timeout=30, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
        details = child.stderr.decode("utf-8", errors="replace")
        found = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", details)
        if found:
            hours, minutes, seconds = found.groups()
            return int(hours) * 3600 + int(minutes) * 60 + float(seconds)
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    return audio_seconds(source) if Path(source).suffix.lower() == ".wav" else 0.0

def normalized_wave(source, target, root, log, duration=30, cancel=None, timeout=FFMPEG_INPUT_TIMEOUT,
                    start_seconds=0):
    args = [ffmpeg_executable(), "-hide_banner", "-loglevel", "error", "-nostdin", "-y"]
    if start_seconds > 0:
        args.extend(["-ss", "%.6f" % float(start_seconds)])
    args.extend(["-i", str(source)])
    if duration is not None:
        args.extend(["-t", str(duration)])
    args.extend(["-vn", "-ac", "1", "-ar", str(SPEECH_RATE), "-c:a", "pcm_s16le", str(target)])
    run_external(args, root, log=log, cancel=cancel, timeout=timeout, capture=True)
    return Path(target)


def join_voice_audio(wavs, durations, output):
    if len(wavs) != len(durations):
        raise ValueError("旁白片段与镜头时长的数量不一致")
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(output), "wb") as dest:
        dest.setnchannels(1)
        dest.setsampwidth(2)
        dest.setframerate(SPEECH_RATE)
        for item, seconds in zip(wavs, durations):
            expected = round(seconds * SPEECH_RATE)
            actual = b""
            if item and Path(item).exists():
                with wave.open(str(item), "rb") as handle:
                    if (handle.getnchannels() != 1 or handle.getsampwidth() != 2
                            or handle.getframerate() != SPEECH_RATE):
                        raise ValueError("旁白音频不是 16kHz、16 位、单声道 PCM")
                    if handle.getnframes() > expected:
                        raise ValueError("旁白超过镜头时长，禁止静默截断：" + str(item))
                    actual = handle.readframes(expected)
            if len(actual) > expected * 2:
                actual = actual[:expected * 2]
            dest.writeframesraw(actual)
            rest = expected * 2 - len(actual)
            if rest > 0:
                dest.writeframesraw(bytes(rest))
        dest.writeframes(b"")
    return output



def planned_durations(seconds, count, fps=DEFAULT_FPS):
    if seconds <= 0 or count <= 0 or fps <= 0:
        raise ValueError("总时长、镜头数量和帧率必须大于零")
    total = round(float(seconds) * fps)
    minimum = 1 if count == 1 else max(1, math.ceil(MIN_MULTI_SCENE_SECONDS * fps))
    if total < minimum * count:
        raise ValueError("分镜数量超过视频时长所允许的可播放范围")
    base, remainder = divmod(total, count)
    return [(base + (index < remainder)) / fps for index in range(count)]


def narration_units(text):
    return len(re.findall(r"[\u3400-\u9fffA-Za-z0-9]", str(text)))


def reference_terms(text):
    text = str(text).lower()
    chinese = re.findall(r"[\u3400-\u9fff]+", text)
    english = set(re.findall(r"[a-z0-9]{3,}", text))
    terms = set(english)
    for part in chinese:
        terms.update(part[i:i + 2] for i in range(max(0, len(part) - 1)))
        terms.update(part[i:i + 3] for i in range(max(0, len(part) - 2)))
    return terms


def source_chunks(content, chunk_size=REFERENCE_CHUNK_CHARS):
    content = str(content).strip()
    if not content:
        return
    limit = max(128, int(chunk_size))
    for offset in range(0, len(content), limit):
        yield offset, content[offset:offset + limit]


def mandatory_phrases(source):
    triggers = r"(?:必须|务必|严格|不得|不能|禁止|仅能|只允许|一定要|不可|不可出现|以.*为准|must|shall|required|never|only|do not)"
    fragments = re.split(r"(?<=[。！？.!?;；\n])|(?<=，)(?=.{0,60}(?:必须|不得|禁止))", str(source))
    return list(dict.fromkeys(fragment.strip()[:200] for fragment in fragments
         if re.search(triggers, fragment, re.I) and fragment.strip()))

def source_requirements_from_records(records):
    keywords = re.compile(r"必须|务必|严格|不得|不能|禁止|仅能|只允许|一定要|不可|务须|需要(?:保持|遵守|采用)|"
                          r"\b(?:must|shall|required|never|only|do\s+not|prohibited|cannot)\b", re.I)
    results = []
    seen = set()
    for title, content in records:
        for fragment in re.finditer(r"[^。！？!?；;\n]+[。！？!?；;\n]?", str(content)):
            exact = fragment.group().strip()
            if not exact or not keywords.search(exact):
                continue
            clause = re.sub(r"\s+", " ", exact).strip()
            if not clause:
                continue
            if len(clause) > MAX_SOURCE_REQUIREMENT_CONTEXT:
                raise RuntimeError("原文包含超过本地模型单项上下文容量的硬性约束：" + str(title)[:90])
            tag = (str(title), clause)
            if tag in seen:
                continue
            seen.add(tag)
            record = {"id": len(results) + 1, "source": str(title)[:180],
                      "offset": fragment.start(), "length": len(exact), "text": clause,
                      "sha256": hashlib.sha256(exact.encode("utf-8")).hexdigest(),
                      "verification": "requires_plan_and_final_evidence"}
            results.append(record)
            if len(results) > MAX_SOURCE_REQUIREMENTS:
                raise RuntimeError("参考文档硬性约束超过当前离线模型能够逐条追踪的数量，拒绝遗漏")
    if sum(len(item["text"]) + 14 for item in results) > MAX_SOURCE_REQUIREMENT_CHARS:
        raise RuntimeError("参考材料硬性约束文本总量超过当前能够完整追踪的容量，不能只摘录一部分")
    return results


def source_requirements_context(records):
    text = "\n".join("[来源约束%d] %s" % (item["id"], item["text"]) for item in records)
    if len(text) > MAX_SOURCE_REQUIREMENT_CONTEXT:
        raise RuntimeError("参考材料硬性要求总量超过当前分镜上下文，可用模型无法全部保留；禁止静默截断")
    return text


def source_plan_quote_present(plan, check):
    scenes = plan.get("scenes", []) if isinstance(plan, dict) else []
    index = check.get("scene")
    quote = str(check.get("quote", "")).strip()
    return (type(index) is int and 0 <= index < len(scenes) and len(quote) >= 5 and
            quote in (str(scenes[index].get("narration", "")) + " " + str(scenes[index].get("visual_prompt", ""))))


def verify_source_requirements_in_plan(model, plan, requirements):
    if not requirements:
        return []
    source_requirements_context(requirements)
    scenes = plan.get("scenes", [])
    summarized = "\n".join("镜头%d 旁白：%s 画面：%s" % (i, scene["narration"], scene["visual_prompt"])
                            for i, scene in enumerate(scenes))
    results = []
    for requirement in requirements:
        model.check_stop()
        relevant = "\n".join("镜头%d 旁白：%s 画面：%s" % (i, scene["narration"], scene["visual_prompt"])
                             for i, scene in enumerate(scenes)) if len(summarized) < 2300 else summarized[:0]
        if not relevant:
            keyword = reference_terms(requirement["text"])
            matches = sorted(enumerate(scenes), key=lambda pair: -len(
                keyword & reference_terms(pair[1]["narration"] + pair[1]["visual_prompt"])))
            relevant = "\n".join("镜头%d 旁白：%s 画面：%s" % (
                i, scene["narration"], scene["visual_prompt"]) for i, scene in matches[:4])
        if len(relevant) > 2300:
            relevant = relevant[:2300]
        question = ("判断一项来源硬性约束是否由分镜具体覆盖，只返回JSON对象{\"scene\":整数,\"quote\":字符串}。"
                    "scene是从0开始的镜头编号，quote必须逐字抄录镜头旁白或画面描述中真实存在的至少5个连续字符，"
                    "并且这段话的含义必须满足约束。不能对应就返回{\"scene\":-1,\"quote\":\"\"}。"
                    "\n原始要求：" + requirement["text"] + "\n实际分镜：\n" + relevant)
        try:
            answer = model.chat([{"role": "system", "content": "严格核对原文要求与现有分镜，不得虚构引用。"},
                                 {"role": "user", "content": question}], tokens=160)
            parsed = extract_json_object(answer)
        except InterruptedError:
            raise
        except (RuntimeError, ValueError, TypeError):
            parsed = None
        record = {"id": requirement["id"], "source": requirement["source"],
                  "original_sha256": requirement["sha256"],
                  "scene": parsed.get("scene") if isinstance(parsed, dict) else None,
                  "quote": parsed.get("quote") if isinstance(parsed, dict) else "",
                  "stage": "model_judged_plus_exact_quote_check"}
        record["passed"] = source_plan_quote_present(plan, record)
        results.append(record)
        if not record["passed"]:
            raise RuntimeError("分镜规划没有逐项保留来源文档的硬性约束（%s，原文偏移%d）：%s" % (
                requirement["source"], requirement["offset"], requirement["text"][:150]))
    return results


def select_reference_snippets(prompt, records, budget=MAX_REFERENCE_BUDGET):
    records = [(str(title).strip()[:110], str(content).strip()) for title, content in records if str(content).strip()]
    if not records or budget < 180:
        return ""
    prompt_words = reference_terms(prompt)
    selections = []
    for origin, (title, content) in enumerate(records):
        paragraphs = [re.sub(r"\s+", " ", fragment).strip() for fragment in
                      re.split(r"(?<=[。！？.!?])\s*|[\n\r]+", content)]
        if not paragraphs:
            paragraphs = [content]
        window = []
        for paragraph in paragraphs:
            for offset in range(0, len(paragraph), 360):
                fragment = paragraph[offset:offset + 360]
                if not fragment.strip():
                    continue
                overlap = len(prompt_words & reference_terms(fragment))
                numbers = bool(re.search(r"\d{4}|\d+(?:[.%％]|万元|公里)", fragment))
                score = overlap * 5 + int(numbers) * 2 + min(2, len(fragment) / 140)
                window.append((score, offset, fragment))
        for rank, (score, offset, fragment) in enumerate(sorted(window, reverse=True)[:5]):
            selections.append((score, origin, rank, title, fragment))
    chosen = []
    used = 0
    for origin, (title, _) in enumerate(records):
        own = [item for item in selections if item[1] == origin]
        if not own:
            continue
        best = max(own, key=lambda item: item[0])
        entry = "%s：%s" % (best[3], best[4])
        allowance = max(90, min(360, budget // max(1, len(records)) - 16))
        entry = entry[:allowance]
        if used + len(entry) + 1 > budget:
            continue
        chosen.append(entry)
        used += len(entry) + 1
        selections.remove(best)
    for item in sorted(selections, key=lambda entry: entry[0], reverse=True):
        if used + 75 > budget:
            break
        entry = "%s（补充）：%s" % (item[3], item[4])
        entry = entry[:min(len(entry), budget - used - 1)]
        if len(entry) > 35:
            chosen.append(entry)
            used += len(entry) + 1
    return "\n".join(chosen)[:budget]



def semantic_timeline(seconds, scenes, fps=DEFAULT_FPS):
    if not scenes:
        return []
    total_frames = round(float(seconds) * fps)
    floor_frames = 1 if len(scenes) == 1 else max(1, math.ceil(MIN_MULTI_SCENE_SECONDS * fps))
    if total_frames < floor_frames * len(scenes):
        raise ValueError("镜头数量与要求的视频时长冲突，请减少分镜数量")
    weights = [max(1, narration_units(scene.get("narration", "")) +
                   min(16, len(str(scene.get("visual_prompt", ""))) // 28) +
                   (3 if index in (0, len(scenes) - 1) else 0))
               for index, scene in enumerate(scenes)]
    remaining = total_frames - floor_frames * len(scenes)
    exact = [remaining * weight / sum(weights) for weight in weights]
    extras = [int(value) for value in exact]
    for index in sorted(range(len(extras)), key=lambda i: exact[i] - extras[i], reverse=True)[:remaining - sum(extras)]:
        extras[index] += 1
    return [(floor_frames + value) / fps for value in extras]



def short_narration(text, limit):
    text = re.sub(r"\s+", "", str(text)).strip("，。！？；、 ")
    units = 0
    result = []
    for char in text:
        if re.match(r"[\u3400-\u9fffA-Za-z0-9]", char):
            if units >= limit:
                break
            units += 1
        result.append(char)
    value = "".join(result).rstrip("，。！？；、 ")
    return value + ("。" if value and value[-1] not in "。！？" else "")


def asset_cache_identity(asset):
    if not asset or not isinstance(asset, (tuple, list)) or len(asset) != 2:
        return asset
    kind, filename = asset
    path = Path(filename)
    try:
        stat = path.stat()
        return (kind, str(path.resolve()), stat.st_size, stat.st_mtime_ns, file_integrity_hash(path))
    except OSError:
        return (kind, str(path), "missing")


def scene_cache_key(scene, seconds, aspect, quality, asset, size, fps, signature=""):
    content = (scene.get("narration"), scene.get("visual_prompt"), round(seconds, 5),
               aspect, quality, asset_cache_identity(asset), tuple(size), fps, PIPELINE_VERSION, signature)
    return hashlib.sha256(repr(content).encode("utf-8")).hexdigest()


def wav_rms(path):
    with wave.open(str(path), "rb") as handle:
        if handle.getsampwidth() != 2 or handle.getnchannels() != 1:
            raise ValueError("仅支持 16 位单声道 WAV 检查")
        samples = array.array("h")
        total_energy = 0
        count = 0
        while True:
            raw = handle.readframes(65536)
            if not raw:
                break
            samples.frombytes(raw)
            if sys.byteorder != "little":
                samples.byteswap()
            total_energy += sum(value * value for value in samples)
            count += len(samples)
            samples = array.array("h")
        return math.sqrt(total_energy / count) / 32768.0 if count else 0.0


def generate_music(output, seconds, mood, seed):
    import numpy as np
    chords = {
        "warm": [(0, 4, 7), (5, 9, 12), (9, 12, 16), (7, 11, 14)],
        "calm": [(0, 3, 7), (8, 12, 15), (5, 8, 12), (7, 10, 14)],
        "mysterious": [(0, 3, 6), (10, 13, 17), (7, 10, 14), (8, 11, 15)],
        "energetic": [(0, 4, 7), (7, 11, 14), (9, 12, 16), (5, 9, 12)],
        "inspiring": [(0, 4, 7), (9, 12, 16), (5, 9, 12), (7, 11, 14)],
    }
    value = str(mood).lower().strip()
    palette = next((chords[key] for key in chords if key in value), chords["inspiring"])
    length = int(seconds * SPEECH_RATE)
    base_note = 48 + (seed % 4)
    beat = 0.55 if value != "energetic" else 0.38
    rnd = random.Random(seed)
    phases = [rnd.uniform(0, math.tau) for _ in range(4)]
    chord_table = np.asarray(palette, dtype=np.int32)
    with wave.open(str(output), "wb") as writer:
        writer.setnchannels(1)
        writer.setsampwidth(2)
        writer.setframerate(SPEECH_RATE)
        chunk_size = SPEECH_RATE * 2
        for start in range(0, length, chunk_size):
            t = np.arange(start, min(length, start + chunk_size), dtype=np.float64) / SPEECH_RATE
            bars = np.floor(t / (beat * 4)).astype(np.int32)
            chords_now = chord_table[bars % len(palette)]
            sound = np.zeros(len(t), dtype=np.float64)
            for layer in range(chords_now.shape[1]):
                freq = 440 * 2.0 ** ((base_note + chords_now[:, layer] - 69) / 12)
                phase = math.tau * freq * t + phases[layer]
                sound += .22 * np.sin(phase) + .08 * np.sin(phase * 2 - phases[layer])
            bass = 440 * 2.0 ** ((base_note + chords_now[:, 0] - 81) / 12)
            sound += .20 * np.sin(math.tau * bass * t)
            arp_indexes = np.floor(t / (beat / 2)).astype(np.int32) % chords_now.shape[1]
            arp = chords_now[np.arange(len(t)), arp_indexes]
            arp_freq = 440 * 2.0 ** ((base_note + arp + 12 - 69) / 12)
            sound += .14 * np.sin(math.tau * arp_freq * t) * np.exp(-4 * ((t % (beat / 2)) / beat))
            envelope = np.minimum(1, np.minimum(t / 1.2, np.maximum(0, (seconds - t) / 1.6)))
            swell = .65 + .15 * np.sin(math.tau * ((t % (beat * 4)) / (beat * 4)))
            samples = (np.clip(sound * swell * envelope, -1, 1) * 13000).astype("<i2")
            writer.writeframesraw(samples.tobytes())
        writer.writeframes(b"")
    return output

def assess_visual_similarity(scores):
    if len(scores) < 5 or any(not math.isfinite(float(value)) for value in scores):
        raise RuntimeError("语义审校分数不完整，无法完成有效比较")
    match, subject = float(scores[0]), float(scores[1])
    negatives = [float(value) for value in scores[2:]]
    negative_peak = max(negatives)
    margin = max(match, subject) - negative_peak
    required_cosine = max(MIN_CLIP_ABSOLUTE_COSINE,
                          min(MIN_CLIP_COSINE + .045, max(MIN_CLIP_COSINE - .018,
                                                         negative_peak + MIN_CLIP_MARGIN)))
    required_margin = max(MIN_CLIP_ABSOLUTE_MARGIN,
                          min(MIN_CLIP_MARGIN + .018, MIN_CLIP_MARGIN + max(0.0, negative_peak - .14) * .08))
    subject_margin = subject - negative_peak
    passed = (match >= required_cosine and margin >= required_margin and
              subject_margin >= MIN_CLIP_ABSOLUTE_MARGIN)
    return {"cosine": round(match, 4), "subject_cosine": round(subject, 4),
            "negative_peak": round(negative_peak, 4), "margin": round(margin, 4),
            "subject_margin": round(subject_margin, 4),
            "required_cosine": round(required_cosine, 4),
            "required_margin": round(required_margin, 4),
            "status": REVIEW_PASS if passed else REVIEW_FAIL,
            "method": "CLIP 对比原始镜头、主体和负面锚点的自适应启发式评分，无法核实数量、身份或真实动作",
            "passed": bool(passed)}


class LocalModels:
    def __init__(self, root, notify, stop, quality="智能", resources=None):
        self.root = Path(root)
        self.notify = notify
        self.stop = stop
        self.quality = quality
        self.resources = resources if resources is not None else ResourceGovernor(root)
        self.torch = importlib.import_module("torch")
        self.torch.set_num_threads(available_threads())
        self.resources.attach_runtime(self.torch)
        try:
            self.torch.set_num_interop_threads(max(1, min(2, available_threads())))
        except RuntimeError:
            pass
        self.gpu = gpu_info()
        self.selected_gpu = None
        self.device = "cpu"
        selected = select_torch_gpu(self.torch, CUDA_MIN_FREE_BYTES + MIN_GPU_HEADROOM)
        if selected:
            try:
                self.torch.cuda.set_device(selected["index"])
                self.selected_gpu = selected["index"]
                self.gpu = {**self.gpu, **selected}
                self.device = "cuda"
                self.resources.attach_cuda(self.torch, self.selected_gpu)
            except (RuntimeError, AssertionError, ValueError):
                self.device = "cpu"
                self.selected_gpu = None
                self.resources.attach_cuda()
        self.dtype = self.torch.float16 if self.device == "cuda" else self.torch.float32
        self.model_choices = {item[2]: item[2] for item in MODEL_SPECS}
        free_ram = memory_info()["available"]
        selected_free = 0
        if self.device == "cuda":
            try:
                selected_free = self.torch.cuda.mem_get_info()[0]
            except (RuntimeError, AssertionError):
                pass
        if quality in {"智能", "精细"}:
            for profile in OPTIONAL_MODEL_CATALOG:
                role = profile["role"]
                optional_folder = OPTIONAL_MODEL_FOLDERS[role]
                factor = 1.0 if quality == "精细" else 1.25
                minimum_ram = int(profile["min_free_ram"] * factor)
                minimum_gpu = int(profile["min_free_gpu_mb"] * 1024 * 1024 * factor)
                if (free_ram >= minimum_ram and (self.device != "cuda" or selected_free >= minimum_gpu)
                        and optional_model_verified(model_path(self.root, optional_folder), role)):
                    self.model_choices[role] = optional_folder
                    self.notify("设备资源允许，已采用完整摘要验收的增强 AI 模型：" + role)
        self.tokenizer = None
        self.director = None
        self.painter = None
        self.inspector = None
        self.inspector_processor = None
        self.inspector_failed = False
        self.detector = None
        self.detector_processor = None
        self.listener = None
        self.listener_processor = None
        label = ("GPU %d · %s" % (self.selected_gpu, self.gpu["name"]) if self.device == "cuda"
                 else "CPU 资源保护模式")
        self.notify("运行设备：" + label)

    def model_folder(self, role):
        return model_path(self.root, self.model_choices.get(role, role))

    def revert_model(self, role, error):
        if self.model_choices.get(role, role) == role:
            return False
        self.notify("选装模型不兼容当前设备，改用已验收的内置模型：" + role + " / " + str(error)[:140])
        self.model_choices[role] = role
        self.unload_director() if role == "director" else None
        self.unload_painter() if role == "painter" else None
        self.unload_inspector() if role == "inspector" else None
        if role == "listener":
            self.listener = self.listener_processor = None
        return True

    def check_stop(self):
        if self.stop.is_set():
            raise InterruptedError("已停止")

    def unload_director(self):
        self.director = None
        self.tokenizer = None
        gc.collect()
        try:
            if self.torch.cuda.is_available():
                self.torch.cuda.empty_cache()
        except (RuntimeError, AssertionError):
            pass

    def unload_painter(self):
        self.painter = None
        gc.collect()
        try:
            if self.torch.cuda.is_available():
                self.torch.cuda.empty_cache()
        except (RuntimeError, AssertionError):
            pass

    def unload_inspector(self):
        self.inspector = None
        self.inspector_processor = None
        gc.collect()

    def switch_to_cpu(self, reason):
        self.notify("GPU 资源不足，自动切换 CPU：" + str(reason)[:140])
        self.unload_director()
        self.unload_painter()
        if self.inspector is not None and memory_info()["available"] < MODEL_SWITCH_FREE_BYTES:
            self.unload_inspector()
        self.device = "cpu"
        self.selected_gpu = None
        self.resources.attach_cuda()
        self.dtype = self.torch.float32

    def load_director(self):
        if self.director is not None:
            return
        self.resources.adaptive_pause("director_load", self.stop, self.notify)
        self.resources.ensure("director_load", required=MIN_DIRECTOR_USABLE_RAM)
        if self.painter is not None:
            self.unload_painter()
        if self.inspector is not None and memory_info()["available"] < MODEL_SWITCH_FREE_BYTES:
            self.unload_inspector()
        if self.detector is not None:
            self.unload_detector()
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.notify("加载本地中文导演模型")
        folder = str(self.model_folder("director"))
        for attempt in range(2):
            self.check_stop()
            try:
                self.tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True, use_fast=True)
                self.director = AutoModelForCausalLM.from_pretrained(
                    folder, torch_dtype=self.dtype, local_files_only=True, low_cpu_mem_usage=True)
                self.director.to(self.device)
                self.director.eval()
                return
            except (RuntimeError, MemoryError) as error:
                self.unload_director()
                if self.device == "cuda" and is_memory_error(error) and attempt == 0:
                    self.switch_to_cpu(error)
                    continue
                if self.revert_model("director", error) and attempt == 0:
                    folder = str(self.model_folder("director"))
                    continue
                if is_memory_error(error):
                    raise RuntimeError("本机剩余内存不足，无法加载中文文案模型") from error
                raise

    def chat(self, messages, tokens=650):
        self.check_stop()
        for attempt in range(2):
            self.load_director()
            payload = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            batch = None
            try:
                budget = min(MAX_DIRECTOR_CONTEXT, max(2048, int(self.tokenizer.model_max_length)
                              if 0 < self.tokenizer.model_max_length < 100000 else MAX_DIRECTOR_CONTEXT))
                input_limit = max(512, budget - int(tokens) - 24)
                token_count = len(self.tokenizer(payload, add_special_tokens=False).input_ids)
                if token_count > input_limit:
                    raise ValueError("本地语言模型上下文不足，拒绝无提示截断：%d/%d tokens" % (
                        token_count, input_limit))
                batch = self.tokenizer([payload], return_tensors="pt", truncation=False).to(self.device)
                with self.torch.inference_mode():
                    sample = self.director.generate(**batch, max_new_tokens=tokens, do_sample=True,
                                                    temperature=0.60, top_p=0.90, repetition_penalty=1.12,
                                                    pad_token_id=self.tokenizer.eos_token_id)
                return self.tokenizer.decode(sample[0][batch.input_ids.shape[1]:], skip_special_tokens=True).strip()
            except (RuntimeError, MemoryError) as error:
                batch = None
                if self.device == "cuda" and is_memory_error(error) and attempt == 0:
                    self.switch_to_cpu(error)
                    continue
                if is_memory_error(error):
                    raise RuntimeError("本机剩余内存不足，无法完成文案推理") from error
                raise

    def digest_text(self, source, purpose, limit, preserve_mandatory=True):
        source = str(source).strip()
        if len(source) <= limit:
            return source
        clauses = mandatory_phrases(source) if preserve_mandatory else []
        required = "\n".join(clauses)
        if len(required) > limit:
            raise RuntimeError("%s硬性要求过多，当前模型上下文无法完整保留；拒绝静默省略" % purpose)
        summaries = []
        for offset, fragment in source_chunks(source, min(REFERENCE_CHUNK_CHARS, 700)):
            self.check_stop()
            answer = self.chat([
                {"role": "system", "content": "只概括输入材料里的已知事实，不虚构内容。保留全部数字、实体、否定和限制。"},
                {"role": "user", "content": "提取与视频创作有关的具体要求、事实和时间线，最多160字。\n" + fragment}
            ], tokens=230)
            if len(answer.strip()) < 4:
                raise RuntimeError("%s第%d个分块无法可靠归纳" % (purpose, offset // 700 + 1))
            summaries.append(answer.strip()[:320])
        digest = "\n".join(summaries)
        for round_index in range(8):
            if len(digest) <= max(0, limit - len(required) - 8):
                break
            stage = []
            for _, fragment in source_chunks(digest, min(REFERENCE_CHUNK_CHARS, 700)):
                self.check_stop()
                answer = self.chat([
                    {"role": "system", "content": "以保留所有实体、数字、否定为首要目标，合并材料中的事实，不新增事实。"},
                    {"role": "user", "content": "将材料压缩为不超过110字的事实与限制：\n" + fragment}
                ], tokens=160)
                if not answer.strip():
                    raise RuntimeError("%s摘要无法继续压缩" % purpose)
                stage.append(answer.strip()[:240])
            if len("\n".join(stage)) >= len(digest) and round_index >= 1:
                raise RuntimeError("%s无法无损收敛到本机上下文预算" % purpose)
            digest = "\n".join(stage)
        combined = (required + "\n" + digest).strip() if required else digest
        if len(combined) > limit:
            raise RuntimeError("%s超过本地模型上下文范围，不会截断用户要求" % purpose)
        return combined

    def decide_media(self, prompt, reference, requested):
        policy = dict(requested)
        answers = {key: key for key in ("narration", "subtitles", "music")
                   if policy.get(key + "_policy") == "auto"}
        if answers:
            brief_prompt = self.digest_text(prompt, "媒体决策要求", 640)
            brief_reference = self.digest_text(reference, "媒体决策参考", 310, preserve_mandatory=False)
            output = None
            for attempt in range(PLAN_RETRIES):
                self.check_stop()
                answer = self.chat([
                    {"role": "system", "content": "你是电影声音与文字设计师，只返回一个合法JSON对象，不要解释。"},
                    {"role": "user", "content": "根据创作要求自主决定是否需要旁白narration、字幕subtitles、背景音乐music，"
                     "恰好输出三个布尔键。无需声音和文字的纯视觉作品可全false；不要默认全部true。"
                     "如有用户明确要求或禁止，绝不能违背。需求：" + brief_prompt +
                     "\n素材要点：" + brief_reference +
                     "\n不可更改的策略：" + json.dumps({key: policy.get(key + "_policy") for key in answers},
                                                  ensure_ascii=False)}
                ], tokens=170)
                try:
                    candidate = extract_json_object(answer)
                except (ValueError, TypeError):
                    candidate = None
                if isinstance(candidate, dict) and all(type(candidate.get(k)) is bool for k in answers):
                    output = candidate
                    break
            if output is None:
                raise RuntimeError("本地AI无法可靠决定作品的旁白/字幕/配乐方案，拒绝使用预设组合伪装智能决策")
            for key in answers:
                policy[key] = output[key]
        if policy["mute_all"]:
            policy.update({"narration": False, "subtitles": False, "music": False, "source_audio": False})
        return policy

    def plan(self, prompt, reference, scenes, seconds, media=None, source_requirements=None):
        media = media or media_preferences(prompt)
        source_requirements = list(source_requirements or [])
        mandatory_source = source_requirements_context(source_requirements)
        anchors = visual_constraints(prompt)
        screen = exact_screen_text_requirements(prompt)
        voice_rule = (("narration须为自然英文旁白。" if media.get("voice_language") == "en" else
                       "narration须为自然中文旁白。") if media["narration"] else
                      "narration仅作为内部叙事说明，不会生成任何旁白。")
        subtitle_rule = ("成片必须配与旁白对应的字幕。" if media["subtitles"] else
                         "禁止额外字幕与标题，但用户明确指定的画面文字仍然必须显示。" if screen else
                         "成片严禁任何字幕、片头标题和额外文字叠加。")
        music_rule = ("作品完全静音。" if media["mute_all"] else
                      "禁止配乐。" if not media["music"] else "")
        restrictions = (voice_rule + subtitle_rule + music_rule +
                        "不得改变用户指定的人物数量、颜色、动作、场景、素材或排除事项。")
        locked = ("\n全部必须保留的准确画面文字：" + "；".join(screen)) if screen else ""
        source_prompt = self.digest_text(prompt, "用户提示词", 680)
        source_reference = self.digest_text(reference, "参考材料", 290,
                                            preserve_mandatory=not bool(source_requirements))
        constraints = ", ".join(anchors)
        context = ("不可改变的硬性限制：" + restrictions + locked + "\n"
                   "明确视觉锚点：" + constraints + "\n"
                   "创作任务：" + source_prompt + "\n参考材料：" + source_reference +
                   ("\n来源材料完整硬性约束：" + mandatory_source if mandatory_source else ""))
        if len(context) > 2350:
            raise RuntimeError("用户硬性要求与上下文长度冲突，不能静默删减需求")
        outline = []
        title, mood = prompt[:40] or "视频作品", "inspiring"
        for offset in range(0, scenes, PLAN_OUTLINE_BATCH_SCENES):
            self.check_stop()
            count = min(PLAN_OUTLINE_BATCH_SCENES, scenes - offset)
            former = "；".join(outline[max(0, len(outline) - 2):]) or "完整作品开篇"
            accepted_outline = None
            for attempt in range(PLAN_RETRIES):
                self.check_stop()
                try:
                    answer = self.chat([
                        {"role": "system", "content": "你是严谨的本地电影导演，严格输出一个JSON对象，不要Markdown。"},
                        {"role": "user", "content":
                         "分批规划全片故事。输出JSON字段title、mood、outline（恰好" + str(count) +
                         "条简短中文主题）；mood为warm/calm/mysterious/energetic/inspiring之一。"
                         "本批是全片第%d至%d幕，共%d幕，完整时长%s秒。上一批结尾：%s。"
                         "每幕主题不同，连贯承接前文。\n%s" % (
                             offset + 1, offset + count, scenes, seconds, former[:250], context)}
                    ], tokens=min(1120, 230 + count * 110))
                    draft = extract_json_object(answer)
                    if (isinstance(draft, dict) and isinstance(draft.get("outline"), list) and
                            len(draft["outline"]) == count and
                            all(isinstance(item, str) and len(item.strip()) >= 2 for item in draft["outline"])):
                        proposed = [item.strip()[:120] for item in draft["outline"]]
                        fingerprints = [re.sub(r"[\W_]+", "", item.lower()) for item in outline + proposed]
                        if len(set(fingerprints)) == len(fingerprints):
                            accepted_outline = proposed
                            if offset == 0:
                                title = str(draft.get("title") or title).strip()[:45]
                                proposed_mood = str(draft.get("mood", mood)).lower()
                                if proposed_mood in {"warm", "calm", "mysterious", "energetic", "inspiring"}:
                                    mood = proposed_mood
                            break
                except InterruptedError:
                    raise
                except (RuntimeError, ValueError, TypeError, OSError) as error:
                    self.notify("故事大纲分批重试：" + str(error)[:110])
            if accepted_outline is None:
                raise RuntimeError("第%d至%d幕故事大纲生成或唯一性校验失败，禁止以重复模板代替AI规划" % (
                    offset + 1, offset + count))
            outline.extend(accepted_outline)
            self.notify("已规划 %d/%d 幕故事结构" % (len(outline), scenes))
        all_scenes = []
        narration_language = "natural English" if media.get("voice_language") == "en" else "自然中文"
        for offset in range(0, scenes, PLAN_BATCH_SCENES):
            self.check_stop()
            count = min(PLAN_BATCH_SCENES, scenes - offset)
            context_outline = "\n".join("%d: %s" % (i + 1, outline[i]) for i in range(
                max(0, offset - 1), min(scenes, offset + count + 1)))
            former = all_scenes[-1]["visual_prompt"][:165] if all_scenes else "开篇，建立世界和人物"
            prompt_batch = (
                "只输出JSON对象，结构为{\"scenes\":[{\"narration\":\"" +
                narration_language + "\",\"visual_prompt\":\"detailed English cinematic prompt\"}]}。"
                "严格生成" + str(count) + "幕，分别对应全片第" + str(offset + 1) + "至" +
                str(offset + count) + "幕；每个narration至少3字，每个visual_prompt至少10字符。"
                "visual_prompt具体说明主体、准确数量、动作、构图、光线、连续性与禁止事项。"
                "每幕内容和视角不同，所有主体的身份与衣着沿用前幕。"
                "\n全片大纲节选：\n" + context_outline +
                "\n上一幕视觉：" + former + "\n" + context)
            accepted = None
            failures = []
            for attempt in range(PLAN_RETRIES):
                self.check_stop()
                suffix = ("\n上次输出缺少分镜或JSON不合法。请重新输出完整且恰好" + str(count) +
                          "幕，不要截断、不许补占位内容。" if attempt else "")
                try:
                    answer = self.chat([
                        {"role": "system", "content": "严格的电影分镜JSON生成器，只输出完整合法JSON。"},
                        {"role": "user", "content": prompt_batch + suffix}
                    ], tokens=min(1500, 220 + PLAN_TOKENS_PER_SCENE * count))
                    parsed = extract_json_object(answer)
                    if validate_plan(parsed, count):
                        accepted = parsed["scenes"]
                        break
                    failures.append("未返回完整" + str(count) + "幕的有效JSON")
                except InterruptedError:
                    raise
                except (RuntimeError, TypeError, ValueError, OSError) as error:
                    failures.append(type(error).__name__ + ": " + str(error)[:120])
                self.notify("第%d–%d幕分镜规划校验未通过，重新规划（%d/%d）" % (
                    offset + 1, offset + count, attempt + 1, PLAN_RETRIES))
            if accepted is None:
                raise RuntimeError("第%d–%d幕无法得到完整可靠的AI分镜，拒绝用模板占位冒充已生成：%s" % (
                    offset + 1, offset + count, "；".join(failures[-2:])))
            for scene in accepted:
                all_scenes.append({"narration": str(scene["narration"]).strip()[:250],
                                   "visual_prompt": str(scene["visual_prompt"]).strip()[:650],
                                   "seconds": round(seconds / scenes, 3)})
            self.notify("已规划并校验 %d/%d 幕分镜" % (len(all_scenes), scenes))
        planned = {"title": title, "mood": mood, "scenes": all_scenes,
                   "plan_source": "local_model_verified_batches",
                   "outline": outline}
        if not validate_plan(planned, scenes):
            raise RuntimeError("完整分镜未通过最终格式校验")
        full_visual = " ".join(item["visual_prompt"] for item in planned["scenes"])
        for phrase in screen:
            if phrase not in full_visual:
                raise RuntimeError("分镜未保留指定屏幕文字：" + phrase)
        if anchors and not visual_constraints_retained(full_visual, anchors):
            missing = [anchor for anchor in anchors if not visual_constraints_retained(full_visual, [anchor])]
            raise RuntimeError("分镜规划未保留用户明确指定的视觉属性：" + ", ".join(missing[:18]) +
                               "。拒绝自动补占位分镜，请调整提示词或选用更强的本地语言模型")
        return planned

    def refine_visual(self, original, review, attempt, user_request):
        base = refine_visual_prompt(original, review, attempt, user_request)
        if attempt == 0:
            return base
        try:
            failure = review_failure_type(review)
            proposal = self.chat([
                {"role": "system", "content": "You repair an image-generation description. Output only English, without adding or removing any people, colors, objects, counts, actions or other constraints. Do not change the user's intent."},
                {"role": "user", "content": "Original scene: " + original[:420] + "\nReason: " + failure +
                 "\nUser restrictions: " + user_request[:380] +
                 "\nRewrite to make the requested subjects clearer; output a single visual description."}
            ], tokens=230)
            required = visual_constraints(original + " " + user_request)
            if 30 <= len(proposal) <= 540 and visual_constraints_retained(proposal, required):
                return (proposal.strip() + " Original constraints: " + original[:260] +
                        " Fixed user attributes: " + ", ".join(required[:10]))[:700]
        except InterruptedError:
            raise
        except (RuntimeError, ValueError, OSError) as error:
            self.notify("修复建议已改用约束保留规则：" + str(error)[:100])
        return base

    def load_painter(self):
        if self.painter is not None:
            return
        self.resources.adaptive_pause("painter_load", self.stop, self.notify)
        self.resources.ensure("painter_load", required=MIN_PAINTER_USABLE_RAM)
        if self.director is not None:
            self.unload_director()
        if self.inspector is not None and memory_info()["available"] < MODEL_SWITCH_FREE_BYTES:
            self.unload_inspector()
        from diffusers import DiffusionPipeline, DPMSolverMultistepScheduler
        self.notify("加载本地图像扩散模型")
        for attempt in range(2):
            self.check_stop()
            try:
                self.painter = DiffusionPipeline.from_pretrained(str(self.model_folder("painter")),
                                                                 torch_dtype=self.dtype, local_files_only=True,
                                                                 low_cpu_mem_usage=True)
                if hasattr(self.painter, "scheduler"):
                    self.painter.scheduler = DPMSolverMultistepScheduler.from_config(self.painter.scheduler.config)
                if self.device == "cpu" and hasattr(self.painter, "enable_attention_slicing"):
                    self.painter.enable_attention_slicing()
                self.painter.to(self.device)
                self.painter.set_progress_bar_config(disable=True)
                return
            except (RuntimeError, MemoryError) as error:
                self.unload_painter()
                if self.device == "cuda" and is_memory_error(error) and attempt == 0:
                    self.switch_to_cpu(error)
                    continue
                if self.revert_model("painter", error) and attempt == 0:
                    continue
                if is_memory_error(error):
                    raise RuntimeError("本机剩余内存不足，无法加载图像生成模型") from error
                raise

    def paint(self, prompt, output, seed, mode, aspect="横屏 16:9", resource_scale=1.0,
              min_dimensions=None):
        self.check_stop()
        self.resources.adaptive_pause("image_generation", self.stop, self.notify)
        self.resources.budget("image_generation", ram_bytes=MIN_PAINTER_USABLE_RAM,
                              disk_bytes=64 * 1024 * 1024)
        self.load_painter()
        try:
            gpu_free = self.torch.cuda.mem_get_info()[0] if self.device == "cuda" else 0
        except (RuntimeError, AssertionError):
            gpu_free = 0
        resolution, steps = self.resources.image_profile(mode, self.device, gpu_free)
        reduction = max(.55, min(1.0, float(resource_scale)))
        if reduction < 1:
            resolution = max(MIN_IMAGE_DIMENSION, round(resolution * reduction / 8) * 8)
            steps = max(6, int(steps * max(.7, reduction)))
        ratio = 9 / 16 if "竖屏" in aspect else 1 if "方形" in aspect else 16 / 9
        pixels = min(MAX_IMAGE_PIXELS, resolution ** 2)
        width = max(MIN_IMAGE_DIMENSION, int(math.sqrt(pixels * ratio)) // 8 * 8)
        height = max(MIN_IMAGE_DIMENSION, int(math.sqrt(pixels / ratio)) // 8 * 8)
        pixels = width * height
        if min_dimensions and (width < min_dimensions[0] or height < min_dimensions[1]):
            raise RuntimeError("画面资源预算不足以达到成片质量底线：至少%d×%d，当前%d×%d" % (
                min_dimensions[0], min_dimensions[1], width, height))
        self.notify("自适应生图：%d×%d · %d 步 · %s" % (width, height, steps, self.device))
        generator = self.torch.Generator(device=self.device).manual_seed(int(seed))
        params = {"prompt": prompt, "width": width, "height": height,
                  "num_inference_steps": steps, "guidance_scale": 7.0, "generator": generator}
        try:
            with self.torch.inference_mode():
                result = self.painter(**params).images[0]
        except (RuntimeError, MemoryError) as error:
            if not is_memory_error(error):
                raise
            if self.device != "cuda":
                raise RuntimeError("CPU 内存不足，已停止图像生成以免系统受影响") from error
            self.torch.cuda.empty_cache()
            resized_pixels = max(MIN_IMAGE_DIMENSION ** 2, int(pixels * .60))
            params.update({"width": max(MIN_IMAGE_DIMENSION, int(math.sqrt(resized_pixels * ratio)) // 8 * 8),
                           "height": max(MIN_IMAGE_DIMENSION, int(math.sqrt(resized_pixels / ratio)) // 8 * 8),
                           "num_inference_steps": min(steps, 12),
                           "generator": self.torch.Generator(device="cuda").manual_seed(int(seed))})
            if min_dimensions and (params["width"] < min_dimensions[0] or
                                   params["height"] < min_dimensions[1]):
                raise RuntimeError("显存不足且降低分辨率会突破成片质量底线；不生成低质替代画面") from error
            try:
                self.notify("GPU 显存不足，自动降分辨率重试")
                with self.torch.inference_mode():
                    result = self.painter(**params).images[0]
            except (RuntimeError, MemoryError) as gpu_retry_error:
                if not is_memory_error(gpu_retry_error):
                    raise
                self.switch_to_cpu(gpu_retry_error)
                self.load_painter()
                fallback_pixels = MIN_IMAGE_DIMENSION * MIN_IMAGE_DIMENSION * 2
                params.update({"width": max(MIN_IMAGE_DIMENSION, int(math.sqrt(fallback_pixels * ratio)) // 8 * 8),
                               "height": max(MIN_IMAGE_DIMENSION, int(math.sqrt(fallback_pixels / ratio)) // 8 * 8),
                               "num_inference_steps": min(8, steps),
                               "generator": self.torch.Generator(device="cpu").manual_seed(int(seed))})
                if min_dimensions and (params["width"] < min_dimensions[0] or
                                       params["height"] < min_dimensions[1]):
                    raise RuntimeError("CPU 安全资源配置无法达到成片最低画质，不进行静默降级") from gpu_retry_error
                try:
                    with self.torch.inference_mode():
                        result = self.painter(**params).images[0]
                except (RuntimeError, MemoryError) as retry_error:
                    if is_memory_error(retry_error):
                        raise RuntimeError("CPU 也无法安全生成图像，已暂停避免影响其他程序") from retry_error
                    raise
        if min_dimensions and (result.width < min_dimensions[0] or
                               result.height < min_dimensions[1]):
            raise RuntimeError("最终生成图像未达到视频输出质量底线，不得放大伪装合格素材")
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        result.save(output)
        return output

    def load_inspector(self):
        if self.inspector is not None:
            return
        self.resources.adaptive_pause("inspector_load", self.stop, self.notify)
        self.resources.ensure("inspector_load", required=MIN_INSPECTOR_USABLE_RAM)
        if self.inspector_failed:
            raise RuntimeError("画面语义审校尚未通过：设备资源不足或 CLIP 模型加载失败")
        if self.detector is not None:
            self.unload_detector()
        from transformers import CLIPModel, CLIPProcessor
        folder = str(self.model_folder("inspector"))
        self.notify("加载本地画面审校模型")
        failure = None
        for attempt in range(2):
            try:
                free = memory_info()["available"]
                if free and free < MODEL_SWITCH_FREE_BYTES and self.painter is not None:
                    self.notify("为语义审校释放图像生成模型占用的内存")
                    self.unload_painter()
                self.inspector_processor = CLIPProcessor.from_pretrained(
                    folder, local_files_only=True, use_fast=False)
                self.inspector = CLIPModel.from_pretrained(
                    folder, local_files_only=True, torch_dtype=self.torch.float32)
                self.inspector.to("cpu")
                self.inspector.eval()
                return
            except (RuntimeError, MemoryError, OSError) as error:
                failure = error
                self.inspector = None
                self.inspector_processor = None
                if attempt == 0:
                    self.revert_model("inspector", error)
                    folder = str(self.model_folder("inspector"))
                self.unload_painter()
        self.inspector_failed = True
        raise RuntimeError("画面语义审校无法完成，不会把普通图像检查冒充 AI 审校：%s" % failure) from failure

    def image_similarity(self, picture, description):
        self.check_stop()
        from PIL import Image
        self.load_inspector()
        focus = re.split(r"[.;]", description.strip(), maxsplit=1)[0].strip()[:150]
        prompts = [description[:220], focus or description[:150],
                   "a completely empty flat color", "random noise and corrupted pixels",
                   "unrecognizable blurry unrelated objects"]
        with Image.open(picture) as image:
            batch = self.inspector_processor(text=prompts, images=image.convert("RGB"),
                                             return_tensors="pt", padding=True, truncation=True)
        with self.torch.inference_mode():
            picture_features = self.inspector.get_image_features(pixel_values=batch["pixel_values"])
            text_features = self.inspector.get_text_features(input_ids=batch["input_ids"],
                                                             attention_mask=batch["attention_mask"])
            picture_features = picture_features / picture_features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
            scores = (picture_features @ text_features.T)[0].tolist()
        return assess_visual_similarity(scores)

    def unload_detector(self):
        self.detector = None
        self.detector_processor = None
        gc.collect()

    def load_detector(self):
        if self.detector is not None:
            return
        self.check_stop()
        self.resources.adaptive_pause("instance_detector", self.stop, self.notify)
        self.resources.budget("instance_detector", ram_bytes=MIN_INSPECTOR_USABLE_RAM)
        self.unload_painter()
        self.unload_inspector()
        self.unload_director()
        from transformers import OwlViTForObjectDetection, OwlViTProcessor
        folder = str(self.model_folder("detector"))
        if not model_download_complete(self.root, MODEL_SPECS[-1]):
            raise RuntimeError("独立目标检测器权重不完整，禁止假装精确数量已得到验证")
        self.notify("加载已完成哈希验收的离线目标检测器")
        self.detector_processor = OwlViTProcessor.from_pretrained(folder, local_files_only=True)
        self.detector = OwlViTForObjectDetection.from_pretrained(
            folder, local_files_only=True, torch_dtype=self.torch.float32, use_safetensors=True)
        self.detector.eval().to("cpu")

    def image_quantity_evidence(self, picture, anchor):
        self.check_stop()
        match = re.fullmatch(r"(\d+)\s+([a-z]+)", str(anchor).strip().lower())
        if not match:
            raise RuntimeError("无法解析目标数量约束")
        expected, subject = int(match.group(1)), quantity_subject_label(match.group(2))
        if expected < 1:
            raise RuntimeError("零目标的排除约束须另行复核")
        from PIL import Image
        self.load_detector()
        with Image.open(picture) as source:
            image = source.convert("RGB")
            batch = self.detector_processor(text=[["a photo of a " + subject]],
                                            images=image, return_tensors="pt")
            with self.torch.inference_mode():
                result = self.detector(**batch)
            boxes = self.detector_processor.post_process_object_detection(
                result, target_sizes=[(image.height, image.width)], threshold=DETECTOR_SCORE_LOW)[0]
        detected = independent_instance_count([
            {"score": score.item(), "box": box.tolist()} for score, box in
            zip(boxes["scores"], boxes["boxes"])])
        passed = detected["strong_count"] == expected and detected["possible_count"] == expected
        return {"anchor": anchor, "subject": subject, "expected": expected, **detected,
                "passed": bool(passed), "method": "离线 OWL-ViT 开放词汇检测与重叠框抑制",
                "assurance": "model_detection_not_absolute_ground_truth",
                "thresholds": {"weak": DETECTOR_SCORE_LOW, "strong": DETECTOR_SCORE_HIGH,
                               "nms_iou": DETECTOR_NMS_IOU}}

    def compare_image_continuity(self, before, after):
        self.check_stop()
        from PIL import Image
        self.load_inspector()
        with Image.open(before) as first, Image.open(after) as second:
            pair = self.inspector_processor(images=[first.convert("RGB"), second.convert("RGB")],
                                            return_tensors="pt")
        with self.torch.inference_mode():
            features = self.inspector.get_image_features(pixel_values=pair["pixel_values"])
            features = features / features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
            similarity = float((features[0] * features[1]).sum().item())
        return {"cosine": round(similarity, 4), "threshold": VISUAL_CONTINUITY_THRESHOLD,
                "passed": similarity >= VISUAL_CONTINUITY_THRESHOLD,
                "scope": "CLIP 粗略检查相邻画面风格及主体；不构成人物身份识别"}

    def match_asset_scores(self, scene_prompts, image_paths):
        self.check_stop()
        if not scene_prompts or not image_paths:
            return []
        from PIL import Image, ImageOps
        self.load_inspector()
        strings = [str(prompt).strip()[:240] or "a cinematic scene" for prompt in scene_prompts]
        encoded = self.inspector_processor(text=strings, return_tensors="pt", padding=True, truncation=True)
        with self.torch.inference_mode():
            text_features = self.inspector.get_text_features(input_ids=encoded["input_ids"],
                                                            attention_mask=encoded["attention_mask"])
            text_features = text_features / text_features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
        result = []
        for filename in image_paths:
            self.check_stop()
            try:
                with Image.open(filename) as source:
                    source.draft("RGB", (UI_PREVIEW_IMAGE_LIMIT, UI_PREVIEW_IMAGE_LIMIT))
                    photo = ImageOps.exif_transpose(source).convert("RGB")
                    photo.thumbnail((UI_PREVIEW_IMAGE_LIMIT, UI_PREVIEW_IMAGE_LIMIT))
                    pixels = self.inspector_processor(images=photo, return_tensors="pt")
                with self.torch.inference_mode():
                    image_features = self.inspector.get_image_features(pixel_values=pixels["pixel_values"])
                    image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-8)
                    scores = (image_features @ text_features.T)[0].tolist()
                result.append([float(value) for value in scores])
            except InterruptedError:
                raise
            except (OSError, ValueError, RuntimeError) as error:
                self.notify("素材语义匹配跳过一个无法读取的预览：" + str(error)[:100])
                result.append(None)
        return result

    def transcribe(self, source, work, logger, max_seconds=None, include_timestamps=True, language=None,
                   start_seconds=0):
        self.check_stop()
        import numpy as np
        source = Path(source)
        stat = source.stat()
        maximum = max(1.0, float(max_seconds) if max_seconds is not None
                      else ASR_WINDOW_SECONDS * MAX_ASR_USER_WINDOWS)
        windows_count = min(MAX_ASR_USER_WINDOWS, math.ceil(maximum / ASR_WINDOW_SECONDS))
        start_seconds = max(0.0, float(start_seconds))
        fingerprint = hashlib.sha256(json.dumps([
            str(source.resolve()), stat.st_size, stat.st_mtime_ns, round(start_seconds, 4),
            file_integrity_hash(source), MODEL_REVISIONS[MODEL_SPECS[2][1]],
            SPEECH_RATE, ASR_WINDOW_SECONDS, windows_count, include_timestamps, language or "auto",
            str(self.model_folder("listener"))],
            ensure_ascii=False).encode("utf-8")).hexdigest()
        cache = self.root / ".studio" / "cache" / "transcripts"
        cache.mkdir(parents=True, exist_ok=True)
        record_path = cache / (fingerprint + ".json")
        previous = read_json(record_path, {})
        if previous.get("fingerprint") == fingerprint and isinstance(previous.get("text"), str):
            self.notify("复用已完成的离线声音识别结果")
            return previous["text"]
        pcm = Path(work) / ("audio_" + fingerprint[:16] + ".wav")
        normalized_wave(source, pcm, self.root, logger, duration=maximum, start_seconds=start_seconds,
                        cancel=self.stop, timeout=max(FFMPEG_INPUT_TIMEOUT, int(maximum * 2)))
        candidates = []
        with wave.open(str(pcm), "rb") as audio:
            for segment in range(windows_count):
                self.check_stop()
                raw = audio.readframes(SPEECH_RATE * ASR_WINDOW_SECONDS)
                if not raw:
                    break
                values = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
                if len(values) < SPEECH_RATE // 4:
                    continue
                windows = values[:len(values) // 1600 * 1600].reshape(-1, 1600)
                energy = np.sqrt(np.mean(windows * windows, axis=1))
                if float(np.percentile(energy, 75)) < .004 or float(np.mean(energy > .007)) < .07:
                    continue
                candidates.append((segment, values))
        if not candidates:
            atomic_json(record_path, {"fingerprint": fingerprint, "text": "", "speech_windows": 0,
                                      "checked": now_stamp()})
            return ""
        from transformers import WhisperForConditionalGeneration, WhisperProcessor
        if self.listener is None:
            self.notify("加载本地语音识别模型")
            folder = str(self.model_folder("listener"))
            self.listener_processor = WhisperProcessor.from_pretrained(folder, local_files_only=True)
            self.listener = WhisperForConditionalGeneration.from_pretrained(folder, local_files_only=True)
            self.listener.to("cpu")
            self.listener.eval()
        gpu = None
        if self.painter is None and self.director is None and self.inspector is None and self.detector is None:
            requirements = ASR_GPU_BASE_FREE_BYTES + MIN_GPU_HEADROOM
            gpu = select_torch_gpu(self.torch, requirements,
                                   preferred=self.gpu if self.selected_gpu is not None else None)
        device = "cuda:%d" % gpu["index"] if gpu else "cpu"
        if gpu:
            try:
                self.resources.adaptive_pause("asr_gpu", self.stop, self.notify)
                self.listener.to(device)
                self.notify("语音识别使用空闲 NVIDIA GPU；完成后自动释放显存")
            except (RuntimeError, MemoryError) as error:
                self.notify("GPU 语音识别环境不可用，改用CPU：" + str(error)[:100])
                self.listener.to("cpu")
                device = "cpu"
        transcriptions = []
        try:
            for segment, values in candidates:
                self.check_stop()
                data = self.listener_processor(values, sampling_rate=SPEECH_RATE, return_tensors="pt")
                params = {"max_new_tokens": 120, "task": "transcribe"}
                if language:
                    params["language"] = language
                try:
                    with self.torch.inference_mode():
                        ids = self.listener.generate(data.input_features.to(device), **params)
                except (RuntimeError, MemoryError) as error:
                    if device == "cpu" or not is_memory_error(error):
                        raise
                    self.notify("语音识别显存变化，安全切换CPU以免影响其它程序")
                    self.listener.to("cpu")
                    self.torch.cuda.empty_cache()
                    device = "cpu"
                    with self.torch.inference_mode():
                        ids = self.listener.generate(data.input_features, **params)
                content = self.listener_processor.batch_decode(ids, skip_special_tokens=True)[0].strip()
                if content:
                    transcriptions.append(("[%.1f秒] " % (start_seconds + segment * ASR_WINDOW_SECONDS) if include_timestamps else "")
                                          + content)
        finally:
            if device != "cpu":
                self.listener.to("cpu")
                if self.torch.cuda.is_available():
                    self.torch.cuda.empty_cache()
        result = " ".join(transcriptions)
        atomic_json(record_path, {"fingerprint": fingerprint, "text": result,
                                  "speech_windows": len(candidates), "checked": now_stamp()})
        files = sorted(cache.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True)
        for old in files[MAX_ASR_CACHE_ENTRIES:]:
            old.unlink(missing_ok=True)
        return result

    def close(self):
        self.unload_painter()
        self.unload_inspector()
        self.unload_detector()
        self.listener = None
        self.listener_processor = None
        self.unload_director()
        gc.collect()


def evaluate_delivery_review_coverage(scene_count, semantic_reviews, semantic_unreviewed,
                                      temporal_unreviewed, speech_reviews, capabilities, narration):
    covered = {review.get("scene") for review in semantic_reviews if review.get("passed") is True}
    missing = sorted(set(range(scene_count)) - covered)
    conflicts = [record for record in semantic_unreviewed
                 if record.get("status") == "user_supplied_conflict"]
    temporal_issues = [record for record in temporal_unreviewed
                       if record.get("status") != REVIEW_NOT_APPLICABLE]
    recognized_speech = (not narration or bool(capabilities.get("speech_review")) and
                         len(speech_reviews) == scene_count and
                         all(speech_record_verified(record) for record in speech_reviews))
    report = {"expected_scenes": scene_count, "semantic_reviewed_scenes": sorted(covered),
              "semantic_unreviewed": len(semantic_unreviewed),
              "temporal_unreviewed": len(temporal_issues),
              "speech_checked": bool(recognized_speech),
              "review_method": "离线 CLIP/ASR/连续帧启发式复核；不能保证人物身份、准确数量或事实真实性"}
    if not capabilities.get("semantic_review"):
        report.update({"delivery_allowed": False, "failure_code": "SEMANTIC_REVIEW_UNAVAILABLE",
                       "failure": "离线语义审校组件未就绪，不能将技术检查冒充 AI 审校"})
    elif conflicts:
        report.update({"delivery_allowed": False, "failure_code": "SUPPLIED_SEMANTIC_CONFLICT",
                       "scene": conflicts[0].get("scene"),
                       "failure": "用户素材与分镜要求的 AI 语义评分冲突，需要重新匹配素材或生成画面"})
    elif missing or semantic_unreviewed:
        report.update({"delivery_allowed": False, "failure_code": "SCENE_SEMANTIC_UNVERIFIED",
                       "scene": missing[0] if missing else semantic_unreviewed[0].get("scene"),
                       "failure": "有镜头尚未获得独立 AI 语义复检通过，禁止交付"})
    elif temporal_issues:
        report.update({"delivery_allowed": False,
                       "failure_code": ("TEMPORAL_REVIEW_UNAVAILABLE" if
                                        temporal_issues[0].get("status") == REVIEW_UNAVAILABLE else
                                        "TEMPORAL_FLICKER"),
                       "scene": temporal_issues[0].get("scene"),
                       "failure": "有镜头连续帧检查未通过或不可用，禁止交付"})
    elif not recognized_speech:
        failed_speech = next((review for review in speech_reviews
                              if not speech_record_verified(review)), {})
        speech_issue = (speech_review_failure(failed_speech) if failed_speech else
                        "SPEECH_REVIEW_UNAVAILABLE")
        report.update({"delivery_allowed": False,
                       "failure_code": speech_issue or "SPEECH_REVIEW_INCONCLUSIVE",
                       "scene": failed_speech.get("scene"),
                       "failure": "成片旁白尚无足够证据证明逐镜头正确，禁止交付"})
    elif scene_count <= 0:
        report.update({"delivery_allowed": False, "failure_code": "SCENE_SEMANTIC_UNVERIFIED",
                       "failure": "缺少镜头审校清单，禁止交付"})
    else:
        report["delivery_allowed"] = True
    report["semantic_pass"] = bool(scene_count > 0 and not missing and
                                    not semantic_unreviewed and capabilities.get("semantic_review"))
    return report



def missing_plan_quantities(plan, prompt):
    if not validate_plan(plan, len(plan.get("scenes", [])) if isinstance(plan, dict) else 0):
        return []
    visuals = " ".join(scene["visual_prompt"] for scene in plan["scenes"])
    return [item["anchor"] for item in strict_visual_quantities(prompt)
            if not visual_constraints_retained(visuals, [item["anchor"]])]


class StudioJob:
    def __init__(self, root, request, notify, cancel, log, emit=None):
        self.root = Path(root)
        self.request = request
        self.media = media_preferences(request.get("prompt", ""))
        self.notify = notify
        self.cancel = cancel
        self.log = log
        self.emit = emit or (lambda payload: None)
        self.resources = ResourceGovernor(root)
        self.piper_worker = None
        self.feature_warnings = set()
        self.run_started = time.monotonic()
        jobs_folder = self.root / ".studio" / "jobs"
        old = find_resumable_job(self.root, request)
        digest = request_fingerprint(request, old[1] if old else None)
        resume_key = request_resume_key(request)
        self.timestamp = now_stamp()
        self.name = slug(request["prompt"], 22)
        self.job = old[0] if old else jobs_folder / (self.timestamp + "_" + self.name)
        self.job.mkdir(parents=True, exist_ok=True)
        self.result_dir = Path(old[1]["result_dir"]) if old and old[1].get("result_dir") else self.root / "成品" / self.job.name
        self.result_dir.mkdir(parents=True, exist_ok=True)
        if old and isinstance(old[1].get("media_preferences"), dict):
            saved = old[1]["media_preferences"]
            policy = media_preferences(request.get("prompt", ""))
            if all(saved.get(name + "_policy") == policy.get(name + "_policy") for name in
                   ("narration", "subtitles", "music")):
                self.media = saved
        self.data = old[1] if old else {"app": APP_VERSION, "started": datetime.datetime.now().isoformat(),
                                         "request": request, "request_digest": digest,
                                         "resume_key": resume_key, "system": {"memory": memory_info(), "gpu": gpu_info(),
                                                    "cpu_count": os.cpu_count()}, "events": [], "warnings": []}
        self.data.update({"status": "运行中", "result_dir": str(self.result_dir),
                          "resumed": bool(old), "request_digest": digest,
                          "resume_key": resume_key, "media_preferences": self.media})
        self.data.setdefault("warnings", [])
        atomic_json(self.job / "job.json", self.data)
        self.models = None
        self.ffmpeg = ffmpeg_executable()
        self.fps = DEFAULT_FPS
        old_size = self.data.get("resolution")
        old_fps = self.data.get("fps")
        if isinstance(old_size, list) and len(old_size) == 2 and all(
                isinstance(value, int) and value >= 256 and value % 2 == 0 for value in old_size):
            self.size = tuple(old_size)
        else:
            self.size = self.choose_size()
        if isinstance(old_fps, int) and 12 <= old_fps <= 60:
            self.fps = old_fps
        self.data["resolution"] = list(self.size)
        self.data["fps"] = self.fps
        atomic_json(self.job / "job.json", self.data)
        diagnostic = read_json(self.root / ".studio" / "ready.json", {}).get("diagnostic") or read_json(
            self.root / ".studio" / "basic_ready.json", {}).get("diagnostic", {})
        self.voice_backend = diagnostic.get("voice_backend", "sapi")
        self.cache_signature = hashlib.sha256((model_signature(self.root, include_optional=True) + self.voice_backend +
                                                PIPELINE_VERSION + json.dumps(self.media, sort_keys=True)
                                                ).encode("utf-8")).hexdigest()
        self.capabilities = require_request_capabilities(self.root, request)
        self.data["capabilities_at_start"] = self.capabilities
        self.data["review_summary"] = {"approved": 0, "user_semantic_warning": 0, "not_checked": 0}
        self.scene_extra_assets = {}
        self.motion_safe_scenes = set()
        self.force_generated_scenes = set()
        self.continuity_required = bool(VISUAL_CONTINUITY_PATTERN.search(self.request.get("prompt", "")))
        atomic_json(self.job / "job.json", self.data)

    def warn(self, message):
        if message not in self.data["warnings"]:
            self.data["warnings"].append(message)
        self.log(message)

    def repair_plan(self, plan, obligation, suggested_scene=None):
        scenes = plan["scenes"]
        if not scenes:
            raise RuntimeError("缺少可修改的分镜，拒绝生成虚假的修复记录")
        anchor = str(obligation).strip()
        if not anchor:
            raise RuntimeError("缺少明确的分镜修复约束")
        if isinstance(suggested_scene, int) and 0 <= suggested_scene < len(scenes):
            target = suggested_scene
        else:
            subject = re.sub(r"^\d+\s+", "", anchor)
            target = max(range(len(scenes)), key=lambda index: len(
                reference_terms(subject) & reference_terms(scenes[index]["visual_prompt"])))
        original = dict(scenes[target])
        preserved = visual_constraints(original["visual_prompt"])
        prior = (scenes[target - 1]["visual_prompt"][:300] if target else "开场")
        following = (scenes[target + 1]["visual_prompt"][:300] if target + 1 < len(scenes) else "收尾")
        requirement = ("用户原始要求：" + self.request["prompt"][:900] +
                       "\n必须修复的精确约束：" + anchor +
                       "\n前一镜：" + prior + "\n后一镜：" + following +
                       "\n原镜头：" + original["visual_prompt"][:550] +
                       "\n保留原镜头的主体身份、动作和已有硬性约束：" + ", ".join(preserved))
        accepted = None
        for attempt in range(PLAN_RETRIES):
            self.models.check_stop()
            response = self.models.chat([
                {"role": "system", "content": "你是视频分镜修复导演，只返回严格的JSON对象，不改变用户需求。"},
                {"role": "user", "content": "输出 {\"scenes\":[{\"narration\":\"中文\",\"visual_prompt\":\"English visual prompt\"}]}，恰好一幕。"
                 "必须原样包含精确数字物体锚点 " + anchor + "，明确其可见、位置和不出现额外物体。"
                 "其它视觉属性不得删除；请做真实的分镜修复，不要只附加一个虚假标签。\n" + requirement}
            ], tokens=min(950, PLAN_TOKENS_PER_SCENE + 330))
            proposed = extract_json_object(response)
            if validate_plan(proposed, 1):
                candidate = proposed["scenes"][0]
                visual = candidate["visual_prompt"].strip()
                if visual_constraints_retained(visual, [anchor] + preserved):
                    accepted = {"narration": candidate["narration"].strip(),
                                "visual_prompt": visual, "seconds": original["seconds"]}
                    break
            self.log("分镜修复仍未保留约束，第 %d 次重试" % (attempt + 1))
        if accepted is None:
            raise RuntimeError("AI 未能修复硬性数量分镜要求：" + anchor + "；保留失败证据，拒绝未经审校的成片")
        scenes[target] = accepted
        plan.setdefault("repair_history", []).append({"at": now_stamp(), "scene": target,
                "obligation": anchor, "before": original, "after": dict(accepted)})
        self.data["assigned_assets"] = {}
        atomic_json(self.job / "storyboard.json", plan)
        atomic_json(self.job / "job.json", self.data)
        self.log("AI 已重新规划第 %d 幕，相关镜头缓存将在生成阶段失效" % (target + 1))
        return set(range(target, len(scenes))) if self.continuity_required else {target}

    def unused_asset_affinity(self, scenes, unused):
        if not self.capabilities.get("semantic_review") or not unused:
            return {}
        previews, indexes = [], []
        for number, (kind, path) in enumerate(unused):
            self.models.check_stop()
            filename = path
            if kind == "video":
                filename = self.job / ("unused_match_%02d_%s.png" % (
                    number, hashlib.sha256(str(path).encode("utf-8")).hexdigest()[:10]))
                try:
                    png_or_video_image(path, filename, self.root, self.log, cancel=self.cancel)
                except (OSError, RuntimeError, TimeoutError, ValueError) as error:
                    self.log("附加视频素材的语义预览不可用：" + str(error)[:160])
                    continue
            previews.append(filename)
            indexes.append(number)
        if not previews:
            return {}
        try:
            scores = self.models.match_asset_scores([scene["visual_prompt"] for scene in scenes], previews)
            return {index: scores[position] for position, index in enumerate(indexes)
                    if position < len(scores) and scores[position] is not None}
        except InterruptedError:
            raise
        except (OSError, RuntimeError, ValueError, MemoryError) as error:
            self.log("附加素材语义排序不可用，回退到时长容量分配：" + str(error)[:200])
            return {}

    def assign_assets(self, scenes):
        count = len(scenes)
        previous = self.data.get("assigned_assets")
        request_signature = hashlib.sha256(json.dumps(
            {"files": self.request.get("files", {}),
             "scenes": [scene.get("visual_prompt", "") for scene in scenes]},
            ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        if (isinstance(previous, dict) and previous.get("count") == count and
                previous.get("request_signature") == request_signature):
            stored = previous.get("items")
            if isinstance(stored, dict):
                recovered = {}
                for key, value in stored.items():
                    if (str(key).isdigit() and int(key) < count and isinstance(value, list)
                            and len(value) == 2 and value[0] in {"image", "video"}
                            and Path(value[1]).is_file()):
                        recovered[int(key)] = tuple(value)
                    else:
                        break
                else:
                    addition = previous.get("additional", {})
                    if isinstance(addition, dict) and all(
                            str(key).isdigit() and int(key) < count and isinstance(values, list) and
                            all(isinstance(pair, list) and len(pair) == 2 and pair[0] in {"image", "video"}
                                and Path(pair[1]).is_file() for pair in values)
                            for key, values in addition.items()):
                        self.scene_extra_assets = {int(key): [tuple(pair) for pair in values]
                                                   for key, values in addition.items()}
                        self.log("已恢复上次确定的镜头素材分配与附加素材")
                        return recovered
        supplied = self.request["files"]
        assigned = {}
        if supplied.get("首帧"):
            assigned[0] = ("image", supplied["首帧"][0])
        if supplied.get("尾帧") and not (count == 1 and supplied.get("首帧")):
            assigned[count - 1] = ("image", supplied["尾帧"][0])
        available = [index for index in range(count) if index not in assigned]
        candidates = ([('video', name) for name in supplied.get('视频', [])]
                      + [('image', name) for name in supplied.get('图片', [])])
        chosen = set()
        if available and len(candidates) > 1:
            try:
                self.log("根据分镜语义自动匹配用户素材")
                pool = candidates[:min(len(candidates), ASSET_MATCH_LIMIT,
                                       max(len(available), len(available) * ASSET_MATCH_FACTOR))]
                paths = []
                indexes = []
                for source_index, (kind, filename) in enumerate(pool):
                    if self.cancel.is_set():
                        raise InterruptedError("已停止")
                    if kind == 'video':
                        preview = self.job / ("asset_match_%02d.png" % source_index)
                        try:
                            if not preview.is_file():
                                png_or_video_image(filename, preview, self.root, self.log, self.cancel)
                            filename = str(preview)
                        except (RuntimeError, OSError, TimeoutError) as error:
                            self.log("视频素材无法参与自动匹配：" + str(error)[:160])
                            continue
                    paths.append(filename)
                    indexes.append(source_index)
                scores = (self.models.match_asset_scores(
                    [scenes[index]["visual_prompt"] for index in available], paths)
                    if self.capabilities["semantic_review"] else [])
                pairs = []
                for asset_i, row in enumerate(scores):
                    if row is None:
                        continue
                    for scene_i, similarity in enumerate(row):
                        if math.isfinite(similarity):
                            pairs.append((similarity, indexes[asset_i], available[scene_i]))
                pairs.sort(key=lambda item: item[0], reverse=True)
                for similarity, source_index, scene_index in pairs:
                    if scene_index not in assigned and source_index not in chosen:
                        assigned[scene_index] = candidates[source_index]
                        chosen.add(source_index)
                        self.log("镜头 %d 匹配素材 %s（相关性 %.3f）" % (
                            scene_index + 1, Path(candidates[source_index][1]).name, similarity))
            except InterruptedError:
                raise
            except (OSError, ValueError, RuntimeError, MemoryError) as error:
                self.log("智能素材匹配不可用，按输入顺序继续：" + str(error)[:220])
        remaining = (index for index in available if index not in assigned)
        for source_index, candidate in enumerate(candidates):
            if source_index in chosen:
                continue
            scene_index = next(remaining, None)
            if scene_index is None:
                break
            assigned[scene_index] = candidate
            chosen.add(source_index)
        unused = [asset for source_index, asset in enumerate(candidates) if source_index not in chosen]
        native_available = (self.request.get("visual_mode", "").startswith("原生AI视频")
                            and self.capabilities["native_video"])
        if not self.capabilities["image_generation"] and not native_available:
            alternatives = [("video", name) for name in supplied.get("视频", [])] + [
                ("image", name) for kind in ("图片", "首帧", "尾帧") for name in supplied.get(kind, [])]
            if not alternatives and len(assigned) < count:
                raise RuntimeError("缺少离线画面生成模型和可用素材，请先完成扩展安装")
            for scene_index in range(count):
                if scene_index not in assigned:
                    assigned[scene_index] = alternatives[scene_index % len(alternatives)]
            self.warn("使用用户素材剪辑；扩展 AI 审校未验收时将明确标记为未审校，不冒充语义通过")
        durations = [float(scene.get("seconds", self.request["duration"] / count)) for scene in scenes]
        affinity = self.unused_asset_affinity(scenes, unused)
        self.scene_extra_assets = distribute_unused_assets(scenes, assigned, unused, self.request,
                                                          durations, self.fps, affinity=affinity)
        if unused:
            self.log("已为 %d 个额外素材分配可观看的子镜头，不会静默丢弃" % len(unused))
        self.data["assigned_assets"] = {"count": count, "request_signature": request_signature,
                                        "items": {str(index): list(value) for index, value in assigned.items()},
                                        "additional": {str(i): [list(item) for item in values]
                                                       for i, values in self.scene_extra_assets.items()}}
        atomic_json(self.job / "job.json", self.data)
        return assigned

    def publish_event(self, kind, **fields):
        self.emit({"type": kind, **fields})

    def rewrite_narration(self, text, seconds, strength=1):
        limit = max(6, min(int(max(1, seconds - SPEECH_END_MARGIN) * 3.2 / strength),
                           int(narration_units(text) * .85)))
        if narration_units(text) <= limit:
            return text
        try:
            result = self.models.chat([
                {"role": "system", "content": "你是中文短视频配音编辑，只输出一句精炼的旁白，不增加新事实。"},
                {"role": "user", "content": "将以下旁白压缩为不超过%d个汉字，不要标题、解释或引号：%s" % (limit, text[:220])}
            ], tokens=100)
            revised = result.splitlines()[0].strip().strip('"“”') if result else ""
            if narration_units(revised) >= 3 and narration_units(revised) <= limit:
                return revised
        except InterruptedError:
            raise
        except Exception as error:
            self.log("旁白缩写改用规则兜底：" + str(error)[:180])
        return short_narration(text, limit)

    def fit_speech(self, scene, stem, duration):
        text = scene["narration"]
        for attempt in range(3):
            self.models.check_stop()
            track = self.create_speech(text, stem)
            length = audio_seconds(track)
            maximum = duration - SPEECH_END_MARGIN
            if length <= maximum:
                scene["narration"] = text
                return track
            ratio = length / maximum
            if ratio <= MAX_SPEECH_SPEEDUP:
                compressed = self.job / (stem + "_fitted.wav")
                run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(track),
                              "-filter:a", "atempo=%.5f" % (ratio * 1.01), "-c:a", "pcm_s16le",
                              "-ar", str(SPEECH_RATE), "-ac", "1", str(compressed)],
                             self.root, log=self.log, cancel=self.cancel, timeout=120, capture=True)
                if audio_seconds(compressed) <= duration:
                    scene["narration"] = text
                    return compressed
            if attempt < 2:
                text = self.rewrite_narration(text, maximum, strength=1.3 + attempt * .3)
                scene["narration"] = text
                self.log("旁白超出单镜头时长，已缩写并重新合成：第 %d 次" % (attempt + 1))
                atomic_json(self.job / "storyboard.json", self.active_plan)
        raise RuntimeError("旁白仍超过镜头时长，已停止避免被截断；请检查该段文字与语音模型")

    def validate_clip(self, clip, seconds):
        if not clip.is_file() or clip.stat().st_size < 1500:
            raise RuntimeError("视频片段尚未成功写入")
        output = run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-xerror",
                               "-i", str(clip), "-map", "0:v:0", "-an", "-progress", "pipe:1",
                               "-f", "null", "-"], self.root, cancel=self.cancel,
                              timeout=max(FFMPEG_INPUT_TIMEOUT, int(seconds * 8)), capture=True)
        times = re.findall(r"out_time_(?:us|ms)=(\d+)", output)
        frames = re.findall(r"(?:^|\n)frame=\s*(\d+)", output)
        if not times or not frames:
            raise RuntimeError("视频片段无法完成逐帧解码和长度检查")
        duration = int(times[-1]) / 1000000
        count = int(frames[-1])
        if abs(duration - seconds) > CLIP_DURATION_TOLERANCE or abs(count - round(seconds * self.fps)) > max(
                2, math.ceil(CLIP_DURATION_TOLERANCE * self.fps)):
            raise RuntimeError("视频片段编码时长或帧数异常：%.3f秒 / %d帧" % (duration, count))
        return True

    def reusable_scene(self, cached, key, clip, duration):
        if (cached.get("passed") is not True or cached.get("key") != key
                or not isinstance(cached.get("duration"), (float, int))
                or abs(cached["duration"] - duration) > 1 / self.fps
                or not isinstance(cached.get("image"), dict)
                or not clip.is_file() or clip.stat().st_size < 2000):
            return False
        voice = cached.get("voice")
        picture = cached["image"]
        if (not picture.get("source") or not Path(picture["source"]).is_file() or
                not cached.get("visual_signature") or
                file_integrity_hash(picture["source"]) != cached["visual_signature"]):
            return False
        if self.media["narration"]:
            if (not isinstance(voice, str) or not Path(voice).is_file() or
                    audio_seconds(voice) < .15 or audio_seconds(voice) > duration or
                    not cached.get("voice_signature") or
                    file_integrity_hash(voice) != cached["voice_signature"]):
                return False
        elif voice is not None or cached.get("voice_signature") is not None:
            return False
        layers = picture.get("overlays", [])
        if (not isinstance(layers, list) or bool(layers) != self.media["subtitles"] or
                not all(isinstance(item, dict) and Path(item.get("path", "")).is_file()
                        and full_file_sha256(item["path"]) == item.get("sha256") for item in layers)):
            return False
        try:
            return self.validate_clip(clip, duration)
        except (RuntimeError, OSError, TimeoutError):
            return False

    def choose_size(self):
        aspect = self.request.get("aspect", "横屏 16:9")
        free_ram = memory_info()["available"]
        gpu = gpu_info()
        free_disk = shutil.disk_usage(self.root).free
        if free_ram < 3 * GB or free_disk < 4 * GB:
            side = 512
        elif gpu["free_mb"] >= 9000 and free_ram >= 12 * GB and self.request["quality"] == "精细":
            side = 1280
        elif gpu["free_mb"] >= 5000 and free_ram >= 6 * GB:
            side = 960
        elif free_ram >= 8 * GB:
            side = 768
        else:
            side = 640
        if "竖屏" in aspect:
            return (int(side * 9 / 16) // 2 * 2, side)
        if "方形" in aspect:
            return (side, side)
        return (side, int(side * 9 / 16) // 2 * 2)

    def step(self, message, percent=None):
        if self.resources.resource_stop_reason:
            raise RuntimeError("资源安全保护：" + self.resources.resource_stop_reason)
        if self.cancel.is_set():
            raise InterruptedError("已停止")
        self.notify(message, percent)
        self.log(message)
        sample = self.resources.snapshot(message)
        self.data["events"].append({"at": now_stamp(), "step": message, "percent": percent,
                                    "elapsed_seconds": round(time.monotonic() - self.run_started, 2),
                                    "ram_available": sample["ram_available"],
                                    "gpu_free": sample["gpu_free"],
                                    "disk_free": sample["disk_free"]})
        self.data["resource_report"] = {"peak_ram_pressure": round(self.resources.peak_ram_pressure, 3),
                                        "minimum_available_ram": self.resources.lowest_available_ram,
                                        "minimum_available_gpu": self.resources.lowest_available_gpu}
        if len(self.data["events"]) > 350:
            self.data["events"] = self.data["events"][-300:]
        atomic_json(self.job / "job.json", self.data)

    def gather_inputs(self):
        records = []
        analysis = []
        mandatory = bool(DOCUMENT_REQUIRED_PATTERN.search(self.request.get("prompt", "")))
        unreadable = []
        incomplete = []
        for filename in self.request["files"].get("文档", []):
            self.models.check_stop()
            try:
                content = document_text_controlled(filename, self.root, self.log, self.cancel)
                if content:
                    records.append(("文档 %s" % Path(filename).name, content))
                    coverage = ("partial" if len(content) >= MAX_DOCUMENT_TEXT - 256 or
                                PDF_OCR_MISSING_MARKER in content or
                                DOC_VISUAL_UNVERIFIED_MARKER in content else "extracted")
                    pages_report = None
                    if Path(filename).suffix.lower() == ".pdf":
                        try:
                            from pypdf import PdfReader
                            with Path(filename).open("rb") as pdf_handle:
                                pdf_pages = len(PdfReader(pdf_handle, strict=False).pages)
                            pages_report = {"total": pdf_pages, "sampled": pdf_pages,
                                            "unreadable": len(re.findall(re.escape(PDF_OCR_MISSING_MARKER), content))}
                            if pdf_pages > 0 and "文档超长" in content:
                                coverage = "partial"
                        except (OSError, ValueError, ImportError):
                            pages_report = {"status": "count_unavailable"}
                    if coverage == "partial":
                        incomplete.append(Path(filename).name)
                    analysis.append({"kind": "document", "file": Path(filename).name,
                                     "status": coverage, "characters": len(content),
                                     "pdf_pages": pages_report,
                                     "max_characters": MAX_DOCUMENT_TEXT,
                                     "possible_truncation": coverage == "partial"})
                else:
                    analysis.append({"kind": "document", "file": Path(filename).name,
                                     "status": "no_text", "characters": 0})
                    unreadable.append(Path(filename).name)
                    self.warn("文档 %s 没有提取到文字，可能是扫描件或不支持的格式" % Path(filename).name)
            except InterruptedError:
                raise
            except Exception as error:
                analysis.append({"kind": "document", "file": Path(filename).name,
                                 "status": "failed", "failure": str(error)[:180]})
                unreadable.append(Path(filename).name)
                self.warn("文档无法读取或 OCR 不可用，已跳过 %s：%s" % (Path(filename).name, str(error)[:160]))
        if unreadable and mandatory:
            self.data["source_analysis"] = analysis
            atomic_json(self.job / "job.json", self.data)
            raise RuntimeError("提示词明确要求依据附件，但无法读取：" + "、".join(unreadable[:8]) +
                               "。已停止制作，避免生成没有依据的内容")
        if incomplete and mandatory:
            self.data["source_analysis"] = analysis
            atomic_json(self.job / "job.json", self.data)
            raise RuntimeError("用户要求严格依据附件，但仍有图表、图片或文本未可靠读取：" +
                               "、".join(incomplete[:8]) + "。请提供可复制文字或确保离线 OCR 可用")
        transcript_fields = []
        if self.request.get("audio_role") != "作为背景音乐":
            transcript_fields.append("音频")
        if (self.request.get("source_audio_role") != "静音原声" or
                re.search(r"识别.*(台词|对白|声音)|提取.*(台词|对白|语音)", self.request["prompt"])):
            transcript_fields.append("视频")
        if self.capabilities["speech_review"]:
            selected = [(field, filename) for field in transcript_fields
                        for filename in self.request["files"].get(field, [])]
            for index, (field, filename) in enumerate(selected):
                self.models.check_stop()
                try:
                    duration = probe_media_seconds(filename, self.ffmpeg)
                    if duration <= 0:
                        raise RuntimeError("无法确认媒体时长，不能安全断言语音已完整覆盖")
                    segments = []
                    offset = 0.0
                    while offset < duration - .05:
                        self.models.check_stop()
                        self.resources.adaptive_pause("asr_batch", self.cancel, self.log)
                        length = min(ASR_BATCH_SECONDS, duration - offset)
                        transcript = self.models.transcribe(filename, self.job, self.log,
                            max_seconds=length, start_seconds=offset)
                        if transcript:
                            segments.append(transcript)
                        offset += length
                        self.log("第%d份素材语音已处理 %.1f/%.1f 秒" % (index + 1, min(offset, duration), duration))
                    text = " ".join(segments)
                    analysis.append({"kind": field, "file": Path(filename).name,
                                     "status": "speech_recognized" if text else "no_speech_detected",
                                     "characters": len(text), "duration": round(duration, 3),
                                     "seconds_processed": round(offset, 3),
                                     "batches": math.ceil(duration / ASR_BATCH_SECONDS)})
                    if text:
                        records.append(("%s %s 中的声音" % (field, Path(filename).name), text))
                except InterruptedError:
                    raise
                except Exception as error:
                    analysis.append({"kind": field, "file": Path(filename).name,
                                     "status": "failed", "failure": str(error)[:180]})
                    self.warn("无法完整识别 %s 的声音：%s" % (Path(filename).name, str(error)[:130]))
                    if re.search(r"必须(?:使用|依据|理解|识别)|严格(?:依据|按照)|务必(?:使用|提取)|"
                                 r"根据(?:音频|视频|采访|录音)|完整(?:转写|识别)", self.request["prompt"]):
                        raise RuntimeError("用户要求依据语音素材，但语音分析未完整完成：" +
                                           Path(filename).name) from error
        elif any(self.request["files"].get(field) for field in transcript_fields):
            self.warn("离线语音识别尚未验收，音视频仍会参与剪辑，但不会声称已理解台词")
        self.models.listener = None
        self.models.listener_processor = None
        gc.collect()
        source_requirements = source_requirements_from_records(
            [(title, content) for title, content in records if title.startswith("文档 ")])
        source_requirements_context(source_requirements)
        source_index = []
        summarized = []
        for title, content in records:
            summaries = []
            for offset, chunk in source_chunks(content):
                self.models.check_stop()
                source_index.append({"source": title, "offset": offset, "length": len(chunk),
                                     "sha256": hashlib.sha256(chunk.encode("utf-8")).hexdigest()})
                if len(content) <= REFERENCE_CHUNK_CHARS:
                    summaries.append(chunk)
                else:
                    summaries.append(self.models.digest_text(chunk, "参考材料分块", 175, preserve_mandatory=False))
            summarized.append((title, "\n".join(summaries)))
        reference = select_reference_snippets(self.request["prompt"], summarized)
        self.data["source_chunk_index"] = source_index
        self.data["source_requirements"] = source_requirements
        self.data["source_requirement_audit_version"] = PIPELINE_VERSION
        self.data["source_requirement_plan_checks"] = []
        self.data["reference_digest_chunks"] = sum(len(item[1]) for item in summarized)
        self.data["source_analysis"] = analysis
        self.data["reference_coverage"] = {"required": mandatory, "failed": unreadable,
                                           "partial": incomplete, "selected_characters": len(reference)}
        self.data["reference_sources"] = [title for title, _ in records]
        self.data["reference_length"] = len(reference)
        atomic_json(self.job / "job.json", self.data)
        return reference

    def create_speech(self, text, stem):
        path = self.job / (stem + ".txt")
        ps1 = self.job / (stem + ".ps1")
        output = self.job / (stem + "_sapi.wav")
        piper_output = self.job / (stem + "_piper.wav")
        normalized = self.job / (stem + ".wav")
        path.write_text(text, encoding="utf-8-sig")
        english = self.media.get("voice_language") == "en"
        backends = ["sapi"] if english else [self.voice_backend, "sapi" if self.voice_backend == "piper" else "piper"]
        failures = []
        for backend in backends:
            if backend == "piper" and not voice_model_ready(self.root):
                continue
            try:
                if backend == "piper":
                    try:
                        if self.piper_worker is None:
                            self.piper_worker = PersistentPiper(self.root, self.cancel, self.log)
                        self.piper_worker.synthesize(path, piper_output)
                    except InterruptedError:
                        raise
                    except Exception as server_error:
                        self.log("常驻语音引擎不可用，切换单次离线合成：" + str(server_error)[:200])
                        if self.piper_worker is not None:
                            self.piper_worker.close()
                            self.piper_worker = None
                        run_external([str(runtime_python(self.root)), str(Path(__file__).resolve()),
                                      "--speak", str(self.root), str(path), str(piper_output)],
                                     self.root, cancel=self.cancel, timeout=MAX_SPEECH_RESPONSE_SECONDS,
                                     log=self.log, capture=True, env=shell_env(self.root, offline=True))
                    source = piper_output
                else:
                    output_ps = str(output).replace("'", "''")
                    input_ps = str(path).replace("'", "''")
                    culture = "en*" if english else "zh*"
                    ps1.write_text("Add-Type -AssemblyName System.Speech\n"
                                   "$voice=New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
                                   "$choices=@($voice.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like '" + culture + "' })\n"
                                   "if ($choices.Count -eq 0) { throw '缺少要求语言的系统离线语音' }\n"
                                   "$voice.SelectVoice($choices[0].VoiceInfo.Name)\n"
                                   "$voice.Rate=1\n"
                                   "$voice.SetOutputToWaveFile('" + output_ps + "')\n"
                                   "$voice.Speak([System.IO.File]::ReadAllText('" + input_ps +
                                   "',[System.Text.Encoding]::UTF8))\n"
                                   "$voice.Dispose()\n", encoding="utf-8-sig")
                    run_external(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                                  "-File", str(ps1)], self.root, log=self.log, cancel=self.cancel,
                                 timeout=90, capture=True)
                    source = output
                normalized_wave(source, normalized, self.root, self.log, duration=None, cancel=self.cancel)
                if audio_seconds(normalized) < .15:
                    raise RuntimeError("合成结果没有有效的语音时长")
                return normalized
            except InterruptedError:
                raise
            except Exception as error:
                failures.append("%s: %s" % (backend, str(error)[:200]))
                self.log("离线旁白尝试失败：" + failures[-1])
        raise RuntimeError("指定语言的离线旁白生成失败，请通过黑匣子检查语音组件：" + "；".join(failures))

    def native_subject_motion_evidence(self, paths):
        from PIL import Image, ImageChops, ImageStat
        ratios, centres, borders = [], [], []
        for first, second in zip(paths, paths[1:]):
            with Image.open(first) as before, Image.open(second) as after:
                a = before.convert("L").resize((128, 128))
                b = after.convert("L").resize((128, 128))
                delta = ImageChops.difference(a, b)
                centre = ImageStat.Stat(delta.crop((28, 28, 100, 100))).mean[0]
                total = ImageStat.Stat(delta).mean[0]
                outer = max(0, (total * 128 * 128 - centre * 72 * 72) / (128 * 128 - 72 * 72))
                centres.append(float(centre))
                borders.append(float(outer))
                ratios.append((centre + 1) / (outer + 1))
        return {"center_difference": round(sum(centres) / max(1, len(centres)), 3),
                "border_difference": round(sum(borders) / max(1, len(borders)), 3),
                "center_to_border_ratio": round(max(ratios, default=0), 3),
                "subject_motion_likely": bool(max(ratios, default=0) >= 1.16 and
                                              max(centres, default=0) >= MIN_NATIVE_TEMPORAL_DIFFERENCE)}

    def review_native_video(self, source, scene, index):
        metadata = read_json(str(source) + ".json", {})
        seconds = float(metadata.get("seconds", NATIVE_VIDEO_FRAMES / NATIVE_VIDEO_FPS))
        if seconds < 1 or not Path(source).is_file():
            raise RuntimeError("原生视频输出时长或文件异常")
        measurements = []
        stills = []
        for number, fraction in enumerate(NATIVE_REVIEW_FRACTIONS):
            self.models.check_stop()
            still = self.job / ("native_review_%02d_%d.png" % (index, number))
            extract_video_frame(self.ffmpeg, source, still,
                                max(0, (seconds - 1 / NATIVE_VIDEO_FPS) * fraction),
                                self.root, cancel=self.cancel, log=self.log)
            valid, reason = validate_image(still, scene_text=scene["visual_prompt"] + self.request["prompt"])
            if not valid:
                raise RuntimeError("原生视频关键帧%d异常：%s" % (number + 1, reason))
            check = self.models.image_similarity(still, scene["visual_prompt"])
            stills.append(still)
            measurements.append({"position": round(seconds * fraction, 3), **check})
        temporal = [round(image_mean_difference(first, second), 3)
                    for first, second in zip(stills, stills[1:])]
        motion_ok = (len(stills) >= MIN_MOTION_REVIEW_FRAMES and
                     max(temporal, default=0) >= MIN_NATIVE_TEMPORAL_DIFFERENCE and
                     all(value <= MAX_NATIVE_TEMPORAL_DIFFERENCE for value in temporal))
        seams = []
        for number, (before, after) in enumerate(native_seam_positions(metadata)):
            self.models.check_stop()
            positions = [max(0, before - 1 / NATIVE_VIDEO_FPS), before, after,
                         min(seconds - 1 / NATIVE_VIDEO_FPS, after + 1 / NATIVE_VIDEO_FPS)]
            paths = []
            for offset, position in enumerate(positions):
                still = self.job / ("native_seam_%02d_%02d_%d.png" % (index, number, offset))
                extract_video_frame(self.ffmpeg, source, still, position, self.root,
                                    cancel=self.cancel, log=self.log)
                valid, reason = validate_image(still, allow_flat=True)
                if not valid:
                    raise RuntimeError("原生视频拼接处无效：" + reason)
                paths.append(still)
            normal_left = image_mean_difference(paths[0], paths[1])
            jump = image_mean_difference(paths[1], paths[2])
            normal_right = image_mean_difference(paths[2], paths[3])
            limit = max(NATIVE_SEAM_DIFFERENCE_MAX, max(normal_left, normal_right) * 2.25 + 12)
            seams.append({"time": round(after, 4), "difference": round(jump, 3),
                          "neighbor_differences": [round(normal_left, 3), round(normal_right, 3)],
                          "limit": round(limit, 3), "passed": jump <= limit})
        seams_ok = all(item["passed"] for item in seams)
        action_required = requires_subject_motion(self.request.get("prompt", "") + " " +
                                                  scene.get("visual_prompt", ""))
        subject_motion = self.native_subject_motion_evidence(stills)
        motion_action_ok = (not action_required or subject_motion["subject_motion_likely"])
        required_matches = max(2, math.ceil(len(measurements) * .70))
        boundary_checks = []
        for label, image_path, position in (
                ("first", self.request["files"]["首帧"][0] if index == 0 and
                 self.request["files"].get("首帧") else None, 0.0),
                ("last", self.request["files"]["尾帧"][0] if index == len(self.active_plan["scenes"]) - 1 and
                 self.request["files"].get("尾帧") else None,
                 max(0, seconds - 2 / NATIVE_VIDEO_FPS))):
            if image_path:
                point = self.job / ("native_boundary_%02d_%s.png" % (index, label))
                extract_video_frame(self.ffmpeg, source, point, position, self.root,
                                    cancel=self.cancel, log=self.log)
                expected = self.job / ("native_boundary_expected_%02d_%s.png" % (index, label))
                frame_with_caption(image_path, expected, tuple(metadata["resolution"]), "", "")
                from PIL import Image, ImageChops, ImageStat
                with Image.open(expected) as a, Image.open(point) as b:
                    a = a.convert("RGB").resize((128, 128))
                    b = b.convert("RGB").resize((128, 128))
                    difference = sum(ImageStat.Stat(ImageChops.difference(a, b)).mean) / 3
                boundary_checks.append({"edge": label, "difference": round(difference, 3),
                                        "passed": difference <= BOUNDARY_FRAME_MEAN_DIFF_MAX})
        passed = (all(item["passed"] for item in boundary_checks) and
                  motion_ok and motion_action_ok and seams_ok and
                  sum(bool(item["passed"]) for item in measurements) >= required_matches and
                  sum(item["cosine"] for item in measurements) / len(measurements) >=
                  sum(item["required_cosine"] for item in measurements) / len(measurements) and
                  sum(item["margin"] for item in measurements) / len(measurements) >=
                  sum(item["required_margin"] for item in measurements) / len(measurements))
        return {"passed": passed, "cosine": round(sum(v["cosine"] for v in measurements) /
                                                  len(measurements), 4),
                "margin": round(sum(v["margin"] for v in measurements) / len(measurements), 4),
                "keyframes": measurements, "seconds": seconds,
                "temporal_differences": temporal, "temporal_review_passed": motion_ok,
                "seam_reviews": seams, "seam_review_passed": seams_ok,
                "boundary_checks": boundary_checks,
                "action_motion_required": action_required, "action_motion_passed": motion_action_ok,
                "subject_motion_evidence": subject_motion,
                "review_method": "CLIP 多帧语义 + 画面时序差分 + 中央主体相对背景动作启发式；不能证明动作细节完全正确"}

    def review_supplied_visual(self, path, scene, index, kind="image", obligated=False):
        path = Path(path)
        samples = [path]
        if kind == "video":
            samples = []
            for number, stamp in enumerate((0.0, .7, 1.8)):
                self.models.check_stop()
                identity = hashlib.sha256(str(path.resolve()).encode("utf-8")).hexdigest()[:12]
                filename = self.job / ("asset_review_%02d_%s_%d.png" % (index, identity, number))
                try:
                    run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                                  "-ss", "%.3f" % stamp, "-i", str(path), "-frames:v", "1",
                                  "-vf", "scale='min(480,iw)':-2", str(filename)],
                                 self.root, log=self.log, cancel=self.cancel, timeout=90, capture=True)
                    okay, _ = validate_image(filename, allow_flat=True)
                    if okay:
                        samples.append(filename)
                except InterruptedError:
                    raise
                except (RuntimeError, OSError, ValueError, TimeoutError):
                    continue
        if not samples:
            return {**visual_review_record(False, None, False, supplied=True, reason="素材无法提取有效画面"),
                    "samples": [], "kind": kind}
        quality = []
        for candidate in samples:
            valid, detail = validate_image(candidate, allow_flat=True)
            if not valid:
                return {**visual_review_record(False, None, False, supplied=True, reason=detail),
                        "samples": [str(item) for item in samples], "kind": kind}
            if self.capabilities["semantic_review"]:
                quality.append(self.models.image_similarity(candidate, scene["visual_prompt"]))
        semantic = None
        if quality:
            cosine = sum(float(item["cosine"]) for item in quality) / len(quality)
            margin = sum(float(item["margin"]) for item in quality) / len(quality)
            required_cosine = sum(float(item["required_cosine"]) for item in quality) / len(quality)
            required_margin = sum(float(item["required_margin"]) for item in quality) / len(quality)
            accepted_count = sum(item["passed"] for item in quality)
            accepted = (accepted_count >= math.ceil(len(quality) * .67) and
                        cosine >= required_cosine and margin >= required_margin)
            semantic = {"cosine": round(cosine, 4), "margin": round(margin, 4),
                        "required_cosine": round(required_cosine, 4),
                        "required_margin": round(required_margin, 4),
                        "samples_passed": accepted_count, "sample_count": len(quality),
                        "passed": bool(accepted),
                        "method": "CLIP 多帧正负锚点比较；不能核实动作、数量或身份事实"}
        record = visual_review_record(True, semantic, True, supplied=True,
                                     reason="用户指定素材优先保留" if obligated else "素材已通过技术解码检查")
        record.update({"samples": [str(item) for item in samples], "kind": kind,
                       "cosine": semantic.get("cosine") if semantic else None,
                       "margin": semantic.get("margin") if semantic else None,
                       "sample_reviews": quality, "obligated": bool(obligated)})
        if record["semantic_passed"] is False:
            self.data["review_summary"]["user_semantic_warning"] += 1
            self.warn("第 %d 幕用户素材与分镜语义评分偏低；已保留原素材，并标注未通过语义审校" % (index + 1))
        elif record["semantic_passed"] is None:
            self.data["review_summary"]["not_checked"] += 1
            self.warn("第 %d 幕素材仅完成技术检查；离线语义审校尚未验收" % (index + 1))
        else:
            self.data["review_summary"]["approved"] += 1
        self.publish_event("scene_review", index=index, total=len(self.active_plan["scenes"]),
                           state=record["review_status"], review=record["reason"])
        return record

    def prepare_native_videos(self, contexts, repair_round):
        prepared = {}
        model = native_video_model(self.root)
        if not self.request.get("visual_mode", "").startswith("原生AI视频"):
            return prepared
        if model is None:
            raise RuntimeError("原生模型尚未完整校验，禁止回退为图片动态运镜")
        image_mode = model[1] in {"CogVideoXImageToVideoPipeline", "AnimateDiffPipeline"}
        self.models.unload_director()
        for context in contexts:
            if context["cached"] or context.get("reuse_visual"):
                continue
            selected = context["selected"]
            head_boundary = (self.request["files"]["首帧"][0] if
                             context["index"] == 0 and self.request["files"].get("首帧") else None)
            tail_boundary = (self.request["files"]["尾帧"][0] if
                             context["index"] == len(contexts) - 1 and
                             self.request["files"].get("尾帧") else None)
            if selected and selected[0] == "video":
                continue
            if selected and selected[0] == "image" and not image_mode:
                raise RuntimeError("选定的原生模型无法按用户素材进行图生视频，拒绝自动改用静态运镜")
            index = context["index"]
            scene = context["scene"]
            prompt = scene["visual_prompt"]
            attempts = []
            for attempt in range(MAX_NATIVE_ATTEMPTS):
                self.models.check_stop()
                self.step("第 %d 幕 · 原生视频生成与关键帧审校" % (index + 1), 38)
                output = self.job / ("native_%02d_%d_%d.mp4" % (index, repair_round, attempt))
                prompt_file = self.job / ("native_prompt_%02d.txt" % index)
                prompt_file.write_text(prompt, encoding="utf-8")
                try:
                    self.resources.ensure("native_video", disk_required=MIN_JOB_FREE)
                    reference = (head_boundary or selected[1] if
                                 image_mode and selected and selected[0] == "image" and
                                 not tail_boundary else head_boundary)
                    if not reference and model[1] == "CogVideoXImageToVideoPipeline" and not tail_boundary:
                        raise RuntimeError("当前图生视频模型需要首帧或尾帧参考图片")
                    args = [str(runtime_python(self.root)), str(Path(__file__).resolve()),
                            "--render-native", str(self.root), str(prompt_file), str(output),
                            self.request["quality"], str(context["length"])]
                    args.extend([str(reference) if reference else "", self.request["aspect"],
                                 str(tail_boundary) if tail_boundary else "",
                                 str(getattr(self.cancel, "filename", ""))])
                    run_external(args, self.root, log=self.log, cancel=self.cancel,
                                 timeout=max(2700, int(context["length"] * 900)),
                                 env=shell_env(self.root, offline=True),
                                 stop_file=getattr(self.cancel, "filename", None),
                                 stop_grace=STOP_GRACE_SECONDS)
                    review = self.review_native_video(output, scene, index)
                    attempts.append({"prompt": prompt, "review": review,
                                     "repair_type": review_failure_type(review) if not review["passed"] else None})
                    if review["passed"]:
                        preview = self.job / ("native_preview_%02d.png" % index)
                        shutil.copy2(self.job / ("native_review_%02d_1.png" % index), preview)
                        prepared[index] = {"type": "native_video", "source": str(output),
                                           "thumbnail": str(preview),
                                           "metrics": {**review, **visual_review_record(True, review)},
                                           "review": "原生时序视频关键帧 AI 审校通过",
                                           "render_method": "native_temporal_diffusion",
                                           "attempts": attempts,
                                           "source_seconds": review["seconds"]}
                        break
                    prompt = self.models.refine_visual(scene["visual_prompt"], review, attempt,
                                                       self.request["prompt"])
                except InterruptedError:
                    raise
                except (OSError, ValueError, RuntimeError, MemoryError, TimeoutError) as error:
                    attempts.append({"prompt": prompt, "failure": str(error)[:400],
                                     "repair_type": "memory" if is_memory_error(error) else "generation_failed"})
                    self.log("第 %d 幕原生视频未通过：%s" % (index + 1, str(error)[:260]))
                    if is_memory_error(error):
                        break
                    prompt = refine_visual_prompt(scene["visual_prompt"], None, attempt,
                                                  self.request["prompt"])
            if index not in prepared:
                atomic_json(self.job / ("native_attempts_%02d.json" % index), attempts)
                raise RuntimeError("第%d幕原生视频连续帧生成/审校未通过，禁止降级为图片运镜；详见黑匣子" %
                                   (index + 1))
            atomic_json(self.job / ("native_attempts_%02d.json" % index), attempts)
        return prepared

    def prepare_generated_images(self, contexts, force_scenes, repair_round, native_prepared=None):
        pending = {}
        prepared = {}
        native_prepared = native_prepared or {}
        native_required = str(self.request.get("visual_mode", "")).startswith("原生AI视频")
        for context in contexts:
            index = context["index"]
            if context["cached"] or context.get("reuse_visual") or index in native_prepared:
                continue
            if context["selected"] and (not native_required or context["selected"][0] == "video"):
                continue
            if native_required:
                raise RuntimeError("第%d幕尚未生成合格原生视频，不能使用静态图片取代" % (index + 1))
            snapshot = self.job / ("approved_%02d.json" % index)
            recorded = read_json(snapshot, {})
            image = self.job / ("shot_%02d.png" % index)
            if (index not in force_scenes and recorded.get("key") == context["key"]
                    and recorded.get("review", {}).get("passed") is True and image.is_file()):
                okay, _ = validate_image(image, scene_text=context["scene"]["visual_prompt"] + self.request["prompt"])
                if okay:
                    prepared[index] = {"type": "image", "source": str(image), "review": "恢复已通过的画面",
                                       "metrics": {**recorded["review"],
                                                   **visual_review_record(True, recorded["review"])},
                                       "render_method": "generated_still_camera_motion",
                                       "attempts": recorded.get("attempts", [])}
                    continue
            pending[index] = {"context": context, "prompt": context["scene"]["visual_prompt"],
                              "attempts": [], "candidate": None, "resource_scale": 1.0}
        for attempt in range(MAX_SCENE_ATTEMPTS):
            if not pending:
                break
            self.step("批量生成画面 %d/%d · 待处理 %d 幕" % (
                attempt + 1, MAX_SCENE_ATTEMPTS, len(pending)),
                38 + int((attempt / MAX_SCENE_ATTEMPTS) * 20))
            for index, item in pending.items():
                self.models.check_stop()
                seed_text = "%s:%s:%s:%s" % (self.request["prompt"], index, attempt, repair_round)
                seed = int(hashlib.sha256(seed_text.encode("utf-8")).hexdigest()[:8], 16)
                candidate = self.job / ("candidate_%02d_%d_%d.png" % (index, repair_round, attempt))
                item["candidate"] = None
                try:
                    consistent = (" Consistent visual style and character identity across all shots, "
                              "harmonized cinematic color palette, realistic composition. ")
                    self.models.paint(item["prompt"] + consistent, candidate, seed,
                                      "快速" if item["resource_scale"] < .8 else self.request["quality"],
                                      self.request["aspect"], resource_scale=item["resource_scale"],
                                      min_dimensions=required_image_dimensions(self.size))
                    valid, reason = validate_image(candidate, scene_text=item["prompt"] + self.request["prompt"])
                    if valid:
                        item["candidate"] = candidate
                    else:
                        item["attempts"].append({"prompt": item["prompt"], "failure": reason,
                                                 "seed": seed, "resource_scale": item["resource_scale"],
                                                 "failure_type": "invalid_media"})
                        item["prompt"] = refine_visual_prompt(item["context"]["scene"]["visual_prompt"],
                                                              None, attempt, self.request["prompt"])
                except InterruptedError:
                    raise
                except (OSError, ValueError, RuntimeError, MemoryError) as error:
                    memory_failure = is_memory_error(error)
                    item["attempts"].append({"prompt": item["prompt"], "error": str(error)[:500],
                                             "seed": seed, "resource_scale": item["resource_scale"],
                                             "failure_type": "resource_exhausted" if memory_failure else
                                             "generation_failed"})
                    if memory_failure:
                        item["resource_scale"] = max(.55, item["resource_scale"] * .77)
                        self.models.unload_painter()
                        gc.collect()
                    else:
                        item["prompt"] = refine_visual_prompt(
                            item["context"]["scene"]["visual_prompt"], None, attempt,
                            self.request["prompt"])
                    self.log("第 %d 幕画面生成失败，准备定向修复：%s" % (index + 1, str(error)[:260]))
            self.models.unload_painter()
            for index, item in list(pending.items()):
                candidate = item["candidate"]
                if candidate is None:
                    continue
                try:
                    review = self.models.image_similarity(candidate, item["context"]["scene"]["visual_prompt"])
                except InterruptedError:
                    raise
                except (OSError, ValueError, RuntimeError, MemoryError) as error:
                    raise RuntimeError("第 %d 幕 AI 语义审校失败，不能冒充已通过：%s" % (
                        index + 1, str(error)[:300])) from error
                anchors = visual_constraints(item["context"]["scene"]["visual_prompt"])
                retained = visual_constraints_retained(item["prompt"], anchors)
                review["constraint_text_preserved"] = retained
                review["constraint_visual_verified"] = False
                review["constraint_status"] = "prompt_text_only" if retained else "prompt_text_mismatch"
                review["explicit_constraints"] = anchors[:16]
                review["verification_limits"] = "视觉约束使用CLIP审校；数量由独立开放词汇目标检测器审校"
                quantities = [obligation for obligation in strict_visual_quantities(self.request["prompt"])
                              if visual_constraints_retained(item["context"]["scene"]["visual_prompt"],
                                                             [obligation["anchor"]])]
                reviews = []
                for obligation in quantities:
                    evidence = self.models.image_quantity_evidence(candidate, obligation["anchor"])
                    reviews.append(evidence)
                review["quantity_checks"] = reviews
                review["passed"] = bool(review["passed"] and retained and
                                        all(record["passed"] for record in reviews))
                item["attempts"].append({"prompt": item["prompt"], "review": review,
                                         "resource_scale": item["resource_scale"]})
                self.log("第 %d 幕语义审校：相似度 %.3f、相对差值 %.3f · %s" % (
                    index + 1, review["cosine"], review["margin"],
                    "通过" if review["passed"] else "等待自动修复"))
                if review["passed"]:
                    shot = self.job / ("shot_%02d.png" % index)
                    shutil.copy2(candidate, shot)
                    prepared[index] = {"type": "image", "source": str(shot), "review": "本地 AI 语义审校通过",
                                       "metrics": {**review, **visual_review_record(True, review)},
                                       "render_method": "generated_still_camera_motion",
                                       "attempts": item["attempts"]}
                    atomic_json(self.job / ("approved_%02d.json" % index),
                                {"key": item["context"]["key"], "review": review,
                                 "attempts": item["attempts"], "time": now_stamp()})
                    del pending[index]
                else:
                    item["prompt"] = self.models.refine_visual(
                        item["context"]["scene"]["visual_prompt"], review, attempt,
                        self.request["prompt"])
                    if review.get("quantity_checks") and not all(
                            entry.get("passed") for entry in review["quantity_checks"]):
                        failed = [entry for entry in review["quantity_checks"] if not entry["passed"]]
                        item["prompt"] += " Mandatory distinct, fully separated, fully visible subjects: " + "; ".join(
                            "exactly %d %s (detected %d to %d; no extras, no occlusion, no duplicates)" % (
                                item["expected"], item["subject"],
                                item["strong_count"], item["possible_count"]) for item in failed)
                    item["attempts"][-1]["repair_type"] = review_failure_type(review)
                    item["attempts"][-1]["next_prompt"] = item["prompt"]
            if pending and memory_info()["available"] < MODEL_SWITCH_FREE_BYTES:
                self.models.unload_inspector()
        if pending:
            summaries = []
            for index, item in pending.items():
                atomic_json(self.job / ("attempts_%02d.json" % index), item["attempts"])
                summaries.append("第 %d 幕：%s" % (index + 1, str(item["attempts"][-1:])[:250]))
            raise RuntimeError("自动重新生成后仍有画面未通过 AI 审校：" + "；".join(summaries))
        self.models.unload_painter()
        if self.continuity_required:
            for index in range(1, len(contexts)):
                before = prepared.get(index - 1)
                after = prepared.get(index)
                if not before or not after or before.get("type") != "image" or after.get("type") != "image":
                    continue
                report = self.models.compare_image_continuity(before["source"], after["source"])
                for retry in range(MAX_SCENE_ATTEMPTS):
                    if report["passed"]:
                        break
                    self.step("相邻镜头风格差异明显，自动修复第 %d 幕" % (index + 1), 60)
                    self.models.unload_inspector()
                    candidate = self.job / ("continuity_repair_%02d_%02d.png" % (index, retry))
                    scene = contexts[index]["scene"]
                    seed = int(hashlib.sha256((self.request["prompt"] + str(index) + str(retry) +
                                                "continuity").encode("utf-8")).hexdigest()[:8], 16)
                    revision = (scene["visual_prompt"][:400] +
                                " The same main character, recurring costume, coherent color palette, "
                                " matching facial and hair traits from adjacent shots, cinematic continuity.")
                    self.models.paint(revision, candidate, seed, "快速", self.request["aspect"],
                                      resource_scale=max(.65, .90 - retry * .08),
                                      min_dimensions=required_image_dimensions(self.size))
                    valid, reason = validate_image(candidate, scene_text=scene["visual_prompt"] + self.request["prompt"])
                    if not valid:
                        report = {**report, "repair_failed": reason}
                        continue
                    semantics = self.models.image_similarity(candidate, scene["visual_prompt"])
                    if not semantics["passed"]:
                        report = {**report, "repair_semantic": semantics}
                        continue
                    report = self.models.compare_image_continuity(before["source"], candidate)
                    if report["passed"]:
                        shutil.copy2(candidate, after["source"])
                        after["metrics"] = {**semantics, **visual_review_record(True, semantics),
                                            "continuity": report}
                        after.setdefault("attempts", []).append({"seed": seed,
                                    "repair_type": "continuity_mismatch", "continuity": report,
                                    "review": semantics})
                        atomic_json(self.job / ("approved_%02d.json" % index),
                                    {"key": contexts[index]["key"], "review": after["metrics"],
                                     "attempts": after["attempts"], "time": now_stamp()})
                after.setdefault("metrics", {})["continuity"] = report
                if not report["passed"]:
                    raise RuntimeError("第 %d 幕与相邻镜头的主体/风格连贯性未通过启发式审校，不能声称一致：%s" %
                                       (index + 1, str(report)[:250]))
        self.models.unload_inspector()
        return prepared

    def compose_clips(self, plan, force_scenes=None, repair_round=0, preserve_visual=None):
        scenes = plan["scenes"]
        previous_timeline = [scene.get("seconds") for scene in scenes]
        minimum_duration = (1 / self.fps if len(scenes) == 1 else MIN_MULTI_SCENE_SECONDS)
        if all(isinstance(value, (int, float)) and value >= minimum_duration for value in previous_timeline) and (
                abs(sum(previous_timeline) - self.request["duration"]) <= 1 / self.fps):
            timeline = [float(value) for value in previous_timeline]
        else:
            timeline = semantic_timeline(self.request["duration"], scenes, self.fps)
        self.active_plan = plan
        assignments = self.assign_assets(scenes)
        force_scenes = set(force_scenes or [])
        preserve_visual = set(preserve_visual or [])
        contexts = []
        for index, scene in enumerate(scenes):
            self.models.check_stop()
            clip = self.job / ("clip_%02d.mp4" % index)
            checkpoint_file = self.job / ("scene_%02d.json" % index)
            cached = read_json(checkpoint_file, {})
            length = timeline[index]
            selected = assignments.get(index)
            extras = self.scene_extra_assets.get(index, [])
            if index in self.force_generated_scenes and not (index == 0 and self.request["files"].get("首帧")) and not (
                    index == len(scenes) - 1 and self.request["files"].get("尾帧")):
                selected = None
                extras = []
                self.log("第 %d 幕用户可选素材语义不符，改为 AI 重新生成画面" % (index + 1))
            extras_signature = hashlib.sha256(json.dumps(
                [(kind, file_integrity_hash(path)) for kind, path in extras], ensure_ascii=False
            ).encode("utf-8")).hexdigest() if extras else ""
            key_signature = self.cache_signature + ":" + extras_signature + ":" + str(self.request.get("visual_mode", ""))
            key = scene_cache_key(scene, length, self.request["aspect"], self.request["quality"],
                                  selected, self.size, self.fps, key_signature)
            reuse = index not in force_scenes and self.reusable_scene(cached, key, clip, length)
            saved_visual = cached.get("image") if index in preserve_visual and cached.get("passed") else None
            if saved_visual and (not isinstance(saved_visual, dict) or
                                 not Path(saved_visual.get("source", "")).is_file() or
                                 not cached.get("visual_signature") or
                                 file_integrity_hash(saved_visual["source"]) != cached["visual_signature"]):
                saved_visual = None
            if reuse:
                self.log("第 %d 幕已通过编码检查，可直接恢复" % (index + 1))
                track = Path(cached["voice"]) if self.media["narration"] else None
            else:
                if self.media["narration"]:
                    self.step("第 %d/%d 幕 · 准备中文旁白" % (index + 1, len(scenes)),
                              22 + int(index / len(scenes) * 15))
                    track = self.fit_speech(scene, "speech_%02d" % index, length)
                else:
                    track = None
                key = scene_cache_key(scene, length, self.request["aspect"], self.request["quality"],
                                      selected, self.size, self.fps, key_signature)
                atomic_json(self.job / "storyboard.json", plan)
            contexts.append({"index": index, "scene": scene, "clip": clip, "checkpoint": checkpoint_file,
                             "cached": cached if reuse else None, "length": length, "selected": selected,
                             "reuse_visual": saved_visual, "key": key, "track": track,
                             "extras": extras})
        if not (self.capabilities["image_generation"] or self.capabilities.get("native_video")):
            missing = [context["index"] + 1 for context in contexts if
                       not context["cached"] and not context["selected"] and not context.get("reuse_visual")]
            if missing:
                raise RuntimeError("以下镜头没有素材且离线生图尚未就绪：" + ", ".join(map(str, missing)))
        self.models.unload_director()
        native_prepared = self.prepare_native_videos(contexts, repair_round)
        self.step("集中生成和检查需要的画面", 38)
        prepared = self.prepare_generated_images(contexts, force_scenes, repair_round, native_prepared)
        clips, wavs, images, original_videos = [], [], [], []
        for context in contexts:
            index, scene, clip = context["index"], context["scene"], context["clip"]
            length, selected, track = context["length"], context["selected"], context["track"]
            self.publish_event("scene_active", index=index, total=len(scenes))
            if context["cached"]:
                visual = context["cached"]["image"]
            else:
                framefile = self.job / ("shot_%02d.png" % index)
                title = plan["title"] if index == 0 and self.media["subtitles"] else ""
                original_video = selected[1] if selected and selected[0] == "video" else None
                base = selected[1] if selected and selected[0] == "image" else None
                reused_visual = context.get("reuse_visual")
                if reused_visual:
                    if reused_visual.get("type") in {"native_video", "video"}:
                        if (index in self.motion_safe_scenes and
                                reused_visual.get("type") == "native_video"):
                            raise RuntimeError("原生镜头必须重新执行时序视频修复，禁止转为静态画面")
                        original_video = reused_visual["source"]
                    elif reused_visual.get("type") == "image":
                        base = reused_visual["source"]
                boundary_image = bool(base and (
                    (index == 0 and self.request["files"].get("首帧")) or
                    (index == len(scenes) - 1 and self.request["files"].get("尾帧"))))
                if index in native_prepared:
                    visual = dict(native_prepared[index])
                    original_video = visual["source"]
                    clipsrc = original_video
                elif original_video:
                    clipsrc = original_video
                    visual = dict(reused_visual) if reused_visual else {
                        "type": "video", "source": str(original_video),
                        "review": "已采用用户视频，并执行逐帧与语义检查",
                        "render_method": "supplied_video_edit"}
                    if not reused_visual:
                        visual["metrics"] = self.review_supplied_visual(
                            original_video, scene, index, kind="video")
                        if not visual["metrics"]["technical_passed"]:
                            raise RuntimeError("第 %d 幕用户视频无法解码，拒绝以无效素材继续" % (index + 1))
                    thumbnail = self.job / ("preview_%02d.png" % index)
                    try:
                        png_or_video_image(original_video, thumbnail, self.root, self.log, cancel=self.cancel)
                        visual["thumbnail"] = str(thumbnail)
                    except (OSError, RuntimeError, TimeoutError) as error:
                        self.log("视频预览不可用：" + str(error)[:200])
                else:
                    if base:
                        from PIL import Image, ImageOps
                        if Path(base).resolve() != framefile.resolve():
                            with Image.open(base) as source_image:
                                source_image.draft("RGB", (max(self.size) * 2, max(self.size) * 2))
                                source_image.thumbnail((max(self.size) * 2, max(self.size) * 2), Image.Resampling.LANCZOS)
                                picture = ImageOps.exif_transpose(source_image).convert("RGB")
                                picture.save(framefile)
                        visual = dict(reused_visual) if reused_visual else {
                            "type": "image", "source": str(framefile), "review": "采用用户提供的画面", "render_method": "supplied_still_camera_motion"}
                        if (index in self.motion_safe_scenes and visual.get("type") == "native_video"
                                and not requires_subject_motion(self.request["prompt"])):
                            visual.update({"type": "image", "source": str(framefile),
                                           "review": "原生动态画面闪烁，保留已审核关键帧改为安全静态镜头",
                                           "source_seconds": None})
                        if not reused_visual:
                            visual["metrics"] = self.review_supplied_visual(
                                framefile, scene, index, kind="image", obligated=boundary_image)
                            if not visual["metrics"]["technical_passed"]:
                                raise RuntimeError("第 %d 幕用户图片技术检查失败" % (index + 1))
                    else:
                        visual = prepared[index]
                    rendered = self.job / ("caption_%02d.png" % index)
                    frame_with_caption(framefile, rendered, self.size, "", "")
                    valid, reason = validate_image(rendered, allow_flat=bool(base),
                                                   scene_text=scene["visual_prompt"] + self.request["prompt"])
                    if not valid:
                        raise RuntimeError("第 %d 幕字幕合成后图片检查失败：%s" % (index + 1, reason))
                    visual["rendered"] = str(rendered)
                    clipsrc = rendered
                overlays = (self.build_caption_overlays(index, scene["narration"], length, title,
                    boundary_first=boundary_image and index == 0,
                    boundary_last=boundary_image and index == len(scenes) - 1)
                    if self.media["subtitles"] else [])
                overlays.extend(self.build_screen_text_overlays(index, scene, length, repair_round))
                visual["overlays"] = overlays
                visual["caption_mask"] = overlays[0]["path"] if overlays else None
                montage = self.encode_scene_montage(
                    clip, clipsrc, original_video, length, overlays, index, len(scenes), selected,
                    context.get("extras", []),
                    native_seconds=visual.get("source_seconds") if visual.get("type") == "native_video" else None,
                    boundary_image=boundary_image, primary_review=visual.get("metrics", {}),
                    repair_round=repair_round)
                if montage:
                    visual["montage"] = montage
                atomic_json(context["checkpoint"], {"passed": True, "duration": length,
                            "key": context["key"], "voice": str(track), "image": visual,
                            "voice_signature": file_integrity_hash(track) if track else None,
                            "visual_signature": file_integrity_hash(visual["source"]),
                            "clip": str(clip), "time": now_stamp()})
            clips.append(clip)
            wavs.append(str(track) if track else None)
            images.append(visual)
            montage = visual.get("montage", [])
            original_videos.append(montage if montage else
                                   ([{"kind": "video", "source": selected[1], "seconds": length}]
                                    if selected and selected[0] == "video" else []))
            metrics = visual.get("metrics", {})
            status = metrics.get("review_status", "unreviewed") if isinstance(metrics, dict) else "unreviewed"
            self.publish_event("scene_ready", index=index, total=len(scenes),
                               preview=visual.get("rendered") or visual.get("thumbnail") or
                               (visual.get("source") if visual.get("type") == "image" else ""),
                               review=visual.get("review", "检查已完成") + " · " + status)
            self.step("第 %d/%d 幕已完成，可断点恢复" % (index + 1, len(scenes)),
                      60 + int((index + 1) / len(scenes) * 20))
        voice = self.job / "voice.wav" if self.media["narration"] else None
        if voice is not None:
            join_voice_audio(wavs, timeline, voice)
        self.write_subtitle_timeline(scenes, timeline, wavs)
        self.original_videos = original_videos
        return clips, voice, sum(timeline), images

    def encode_scene_montage(self, clip, clipsrc, original_video, seconds, overlays, index,
                             scene_count, primary, extras, native_seconds=None, boundary_image=False,
                             primary_review=None, repair_round=0):
        effective_primary = primary or ("video" if original_video else "image", str(original_video or clipsrc))
        sequence = asset_sequence_for_scene(effective_primary, extras, index, scene_count, self.request)
        accepted = []
        evaluations = {}
        required_all = bool(re.search(
            r"(?:必须|务必|一定要|需要)(?:使用|保留|采用).{0,18}(?:所有|全部)(?:素材|图片|视频)|"
            r"(?:全部|所有)(?:素材|图片|视频).{0,18}(?:必须|务必|都要|都得|使用|保留|采用)|"
            r"(?:必须|务必).{0,12}(?:所有|全部)(?:素材|图片|视频)",
            self.request.get("prompt", "")))
        for slot, (kind, path) in enumerate(sequence):
            is_primary = bool(kind == effective_primary[0] and str(path) == str(effective_primary[1]))
            if is_primary:
                evaluations[slot] = primary_review if isinstance(primary_review, dict) else {}
                accepted.append((kind, path, slot, True))
                continue
            evaluation = self.review_supplied_visual(path, self.active_plan["scenes"][index], index, kind)
            if not evaluation.get("technical_passed"):
                raise RuntimeError("第 %d 幕额外素材无法正常解码：%s" % (index + 1, Path(path).name))
            if evaluation.get("semantic_passed") is not True:
                if required_all:
                    raise RuntimeError("用户要求必须使用全部素材，但第 %d 幕素材 %s 与分镜语义不符，不能冒充审校通过" % (
                        index + 1, Path(path).name))
                self.warn("第 %d 幕附加素材 %s 与分镜语义不符，已自动保留原文件但不加入成片" % (
                    index + 1, Path(path).name))
                self.data.setdefault("excluded_optional_assets", []).append({
                    "scene": index, "kind": kind, "source": str(path),
                    "reason": "semantic_review_failed", "review": evaluation})
                continue
            evaluations[slot] = evaluation
            accepted.append((kind, path, slot, False))
        if not accepted or sum(bool(primary) for _, _, _, primary in accepted) != 1:
            raise RuntimeError("场景素材顺序不完整，无法可靠合成视频")
        if len(accepted) <= 1:
            self.encode_clip(clip, clipsrc, original_video, seconds, overlays,
                             first=index == 0, last=index == scene_count - 1,
                             native_seconds=native_seconds,
                             boundary_hold=boundary_image or index in self.motion_safe_scenes)
            kind, source, slot, _ = accepted[0]
            return [{"kind": kind, "source": str(source), "seconds": seconds,
                     "start": 0.0, "end": float(seconds), "slot": 0, "primary": True,
                     "review": evaluations[slot]}]
        durations = montage_frame_allocation(seconds, accepted, self.fps)
        parts = []
        records = []
        cursor = 0.0
        for slot, ((kind, path, original_slot, is_primary), length) in enumerate(zip(accepted, durations)):
            actual_source = (original_video or clipsrc) if is_primary else str(path)
            video = actual_source if (kind == "video" or is_primary and original_video) else None
            native_length = native_seconds if is_primary and video else None
            if native_seconds is not None and kind == "image" and not is_primary:
                self.models.check_stop()
                native_extra = self.job / ("native_extra_%02d_%02d_%d.mp4" % (index, slot, repair_round))
                text_file = self.job / ("native_extra_prompt_%02d_%02d_%d.txt" % (index, slot, repair_round))
                text_file.write_text(self.active_plan["scenes"][index]["visual_prompt"], encoding="utf-8")
                run_external([str(runtime_python(self.root)), str(Path(__file__).resolve()),
                              "--render-native", str(self.root), str(text_file), str(native_extra),
                              self.request["quality"], str(max(1.0, length)), str(path),
                              self.request["aspect"], "", str(getattr(self.cancel, "filename", ""))],
                             self.root, log=self.log, cancel=self.cancel,
                             timeout=max(2700, int(max(1.0, length) * 900)),
                             env=shell_env(self.root, offline=True),
                             stop_file=getattr(self.cancel, "filename", None),
                             stop_grace=STOP_GRACE_SECONDS)
                check = self.review_native_video(native_extra, self.active_plan["scenes"][index], index)
                if not check["passed"]:
                    raise RuntimeError("第%d幕附加图片的原生时序视频未通过审校；不会改成图片运镜" % (index + 1))
                video = str(native_extra)
                actual_source = video
                native_length = check["seconds"]
                evaluations[original_slot] = check
            if is_primary and not video:
                actual_source = clipsrc
            part_file = self.job / ("scene_%02d_visual_%02d.mp4" % (index, slot))
            self.encode_clip(part_file, actual_source, video, length, first=True, last=True,
                             native_seconds=native_length,
                             boundary_hold=(boundary_image and is_primary or index in self.motion_safe_scenes))
            parts.append(part_file)
            records.append({"kind": "native_video" if native_length is not None else kind,
                            "source": str(path), "seconds": length,
                            "start": round(cursor, 6), "end": round(cursor + length, 6),
                            "slot": slot, "segment": str(part_file), "primary": is_primary,
                            "review": evaluations.get(original_slot, {})})
            cursor += length
        assembled = self.job / ("scene_%02d_montage.mp4" % index)
        self.concat_clips(parts, assembled)
        self.encode_clip(clip, assembled, assembled, seconds, overlays,
                         first=index == 0, last=index == scene_count - 1)
        return records

    def build_caption_overlays(self, index, text, seconds, title="", boundary_first=False, boundary_last=False):
        segments = paginate_caption(text, self.size, seconds, self.fps)
        overlays = []
        for page_index, segment in enumerate(segments):
            output = self.job / ("overlay_%02d_%02d.png" % (index, page_index))
            frame_with_caption(None, output, self.size, segment["text"],
                               title if page_index == 0 else "", transparent=True)
            reserved = (int(bool(boundary_first)) + int(bool(boundary_last)))
            available_frames = round(seconds * self.fps) - MIN_CAPTION_VISIBLE_FRAMES
            hold = (min(FIRST_LAST_HOLD_SECONDS, max(0, available_frames) / max(1, reserved) / self.fps)
                    if reserved else 0)
            start = max(segment["start"], hold if boundary_first else 0)
            end = min(segment["end"], seconds - hold if boundary_last else seconds)
            if end - start < MIN_CAPTION_VISIBLE_FRAMES / self.fps:
                raise ValueError("镜头 %d 的字幕显示时段过短，无法保证全部文字可读" % (index + 1))
            overlays.append({"path": str(output), "start": round(start, 6), "end": round(end, 6),
                             "text": segment["text"], "sha256": full_file_sha256(output)})
        if normalized_caption("".join(item["text"] for item in overlays)) != normalized_caption(text):
            raise RuntimeError("字幕页未完整覆盖旁白，禁止输出被截断的成片")
        return overlays

    def build_screen_text_overlays(self, index, scene, seconds, repair_round=0):
        phrases = exact_screen_text_requirements(self.request["prompt"])
        if not phrases:
            return []
        if re.search(r"(?:招牌|标牌|牌子|牌匾|路牌|门牌|标志牌)(?:上)?(?:必须|需要|要)?(?:显示|写着|写上|是)",
                     self.request["prompt"]):
            return []
        visuals = str(scene.get("visual_prompt", "")).lower()
        selected = [text for text in phrases if text.lower() in visuals]
        if not selected and index == 0 and not any(
                text.lower() in str(item.get("visual_prompt", "")).lower()
                for text in phrases for item in self.active_plan["scenes"]):
            selected = phrases
        if not selected:
            return []
        from PIL import Image, ImageDraw
        width, height = self.size
        canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(canvas)
        all_text = "\n".join(selected)
        maximum_width = width * .84
        maximum_height = height * .36
        font = None
        lines = None
        scale = min(1.5, 1.0 + max(0, repair_round) * .15)
        for size in range(max(16, round(height * .065 * scale)),
                          max(11, round(height * .022)) - 1, -2):
            attempt = image_font(size)
            wrapped = wrap_text(all_text, attempt, maximum_width)
            line_height = max(size * 1.34, (attempt.getbbox("中")[3] - attempt.getbbox("中")[1]) * 1.45)
            if wrapped and len(wrapped) * line_height <= maximum_height:
                font, lines = attempt, wrapped
                break
        if not font or not lines:
            raise RuntimeError("要求显示的屏幕文字超出安全可读版面，禁止截断交付")
        line_height = max(1, math.ceil(line_height))
        text_width = max(font.getlength(line) for line in lines)
        panel_width = min(width - 8, math.ceil(text_width + width * .095))
        panel_height = math.ceil(len(lines) * line_height + height * .065)
        left = (width - panel_width) // 2
        top = max(12, round(height * .085))
        draw.rounded_rectangle((left, top, left + panel_width, top + panel_height),
                               radius=max(6, round(height * .018)),
                               fill=(8, 15, 26, min(252, 220 + max(0, repair_round) * 12)))
        baseline = top + math.ceil(height * .032)
        for line in lines:
            x = round((width - font.getlength(line)) / 2)
            draw.text((x, baseline), line, font=font, fill=(255, 255, 255, 255),
                      stroke_width=max(1, round(height / 520)), stroke_fill=(0, 0, 0, 255))
            baseline += line_height
        output = self.job / ("required_screen_text_%02d.png" % index)
        canvas.save(output)
        return [{"path": str(output), "start": 0.0, "end": seconds,
                 "required_screen_text": selected, "sha256": full_file_sha256(output)}]

    def write_subtitle_timeline(self, scenes, durations, wavs):
        cursor = 0.0
        subtitles = []
        for index, (scene, duration) in enumerate(zip(scenes, durations)):
            info = read_json(self.job / ("scene_%02d.json" % index), {})
            segments = info.get("image", {}).get("overlays", [])
            text = scene["narration"] if self.media["subtitles"] else ""
            if (not isinstance(segments, list) or bool(segments) != self.media["subtitles"] or
                    normalized_caption("".join(str(part.get("text", "")) for part in segments)) !=
                    normalized_caption(text)):
                raise RuntimeError("第 %d 幕的字幕记录与用户的字幕要求不一致" % (index + 1))
            wav = wavs[index]
            if self.media["narration"] and (not wav or not Path(wav).is_file()):
                raise RuntimeError("第 %d 幕缺少请求的旁白文件" % (index + 1))
            if not self.media["narration"] and wav is not None:
                raise RuntimeError("第 %d 幕包含用户明确禁止的旁白" % (index + 1))
            subtitles.append({"index": index, "from": round(cursor, 5),
                              "to": round(cursor + duration, 5), "caption": text,
                              "segments": segments, "voice_file": str(wav) if wav else None,
                              "voice_sha256": file_integrity_hash(wav) if wav else None,
                              "voice_seconds": round(audio_seconds(wav), 3) if wav else 0.0})
            cursor += duration
        atomic_json(self.job / "subtitle_timeline.json", subtitles)
        return subtitles

    def encode_clip(self, clip, source, source_video, seconds, overlay=None, first=False, last=False,
                    native_seconds=None, boundary_hold=False):
        width, height = self.size
        fade = min(.28, seconds / 10)
        effects = []
        if not first:
            effects.append("fade=t=in:st=0:d=%.2f" % fade)
        if not last:
            effects.append("fade=t=out:st=%.3f:d=%.2f" % (max(.1, seconds - fade), fade))
        effects.append("format=yuv420p")
        effects = ",".join(effects)
        common = ["-threads", str(available_threads()), "-c:v", "libx264", "-preset", "veryfast",
                  "-crf", "24", "-pix_fmt", "yuv420p", "-r", str(self.fps), "-an", "-movflags", "+faststart"]
        args = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
        if source_video:
            if native_seconds is not None and "竖屏" in self.request.get("aspect", ""):
                filters = ["scale=%d:%d:force_original_aspect_ratio=decrease" % (width, height),
                           "pad=%d:%d:(ow-iw)/2:(oh-ih)/2:color=0x0d1727" % (width, height), "setsar=1"]
            else:
                filters = ["scale=%d:%d:force_original_aspect_ratio=increase" % (width, height),
                           "crop=%d:%d" % (width, height), "setsar=1"]
            if native_seconds is not None:
                source_length = max(.1, float(native_seconds))
                if source_length < seconds / NATIVE_VIDEO_MAX_SLOWDOWN:
                    raise RuntimeError("原生视频真实动态时长不足；不通过复制静止末帧伪装动态")
                stretch = seconds / source_length
                filters.append("setpts=%.6f*(PTS-STARTPTS)" % stretch)
                sample = self.resources.snapshot("native_frame_interpolation")
                supports_motion_interpolation = getattr(self, "_motion_interpolation_supported", None)
                if (self.fps > NATIVE_VIDEO_FPS and sample.get("cpu_busy") is not None and
                        sample["cpu_busy"] < RESOURCE_MONITOR_CPU_LIMIT * .82 and
                        supports_motion_interpolation is None):
                    try:
                        available_filters = run_external(
                            [self.ffmpeg, "-hide_banner", "-filters"], self.root,
                            cancel=self.cancel, timeout=30, capture=True)
                        supports_motion_interpolation = bool(re.search(r"\bminterpolate\b", available_filters))
                    except (OSError, RuntimeError, TimeoutError):
                        supports_motion_interpolation = False
                    self._motion_interpolation_supported = supports_motion_interpolation
                if (supports_motion_interpolation and self.fps > NATIVE_VIDEO_FPS and
                        sample.get("cpu_busy") is not None and
                        sample["cpu_busy"] < RESOURCE_MONITOR_CPU_LIMIT * .82):
                    filters.append("minterpolate=fps=%d:mi_mode=mci:mc_mode=aobmc:me_mode=bidir" % self.fps)
                else:
                    filters.append("fps=%d" % self.fps)
            else:
                filters.append("fps=%d" % self.fps)
            if native_seconds is None:
                args.extend(["-stream_loop", "-1"])
            args += ["-i", str(source_video)]
            visual = ",".join(filters + [effects])
        else:
            args += ["-loop", "1", "-framerate", str(self.fps), "-i", str(source)]
            zoomstep = max(.00015, .09 / max(1, seconds * self.fps))
            visual = ("scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
                      "zoompan=z='min(zoom+%.6f,1.09)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                      "d=1:s=%dx%d:fps=%d") % (width, height, width, height, zoomstep,
                                                 width, height, self.fps)
            if boundary_hold:
                visual = "scale=%d:%d,setsar=1,fps=%d" % (width, height, self.fps)
            visual += "," + effects
        layers = overlay if isinstance(overlay, list) else ([{"path": str(overlay), "start": 0, "end": seconds}]
                                                              if overlay else [])
        if layers:
            filters = ["[0:v]" + visual + "[background]"]
            previous = "background"
            for number, part in enumerate(layers, 1):
                args.extend(["-loop", "1", "-framerate", str(self.fps), "-i", str(part["path"])])
                following = "v" if number == len(layers) else "layer%d" % number
                last_frame = max(part["start"], part["end"] - CAPTION_SEGMENT_GAP_FRAMES / self.fps)
                filters.append("[%s][%d:v]overlay=0:0:shortest=1:enable='between(t,%.5f,%.5f)'[%s]" %
                               (previous, number, part["start"], last_frame, following))
                previous = following
            args += ["-filter_complex", ";".join(filters), "-map", "[v]"]
        else:
            args += ["-vf", visual]
        args += ["-t", "%.5f" % seconds] + common + [str(clip)]
        run_external(args, self.root, log=self.log, cancel=self.cancel,
                     timeout=max(240, int(seconds * 30)), capture=True)
        self.validate_clip(clip, seconds)

    def concat_clips(self, clips, output):
        concat_path = self.job / "concat.txt"
        concat_path.write_text("\n".join("file '%s'" % str(path).replace("\\", "/").replace("'", "'\\''")
                                          for path in clips), encoding="utf-8")
        run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
                      "-i", str(concat_path), "-c", "copy", str(output)], self.root, log=self.log,
                     cancel=self.cancel, timeout=300, capture=True)
        if output.stat().st_size < 2000:
            raise RuntimeError("片段合并失败")

    def build_original_audio(self, durations):
        videos = getattr(self, "original_videos", [])
        if (not self.media["source_audio"] or
                self.request.get("source_audio_role", "自动混合原声") == "静音原声"
                or not any(any(item.get("kind") == "video" for item in group)
                           if isinstance(group, list) else bool(group) for group in videos)):
            return None
        destination = self.job / "original_audio.wav"
        sound_count = 0
        with wave.open(str(destination), "wb") as writer:
            writer.setnchannels(1)
            writer.setsampwidth(2)
            writer.setframerate(SPEECH_RATE)
            for index, seconds in enumerate(durations):
                self.models.check_stop()
                expected = round(seconds * SPEECH_RATE)
                track = self.job / ("source_audio_%02d.wav" % index)
                raw = b""
                source = videos[index] if index < len(videos) else []
                segments = source if isinstance(source, list) else (
                    [{"kind": "video", "source": source, "seconds": seconds}] if source else [])
                copied = 0
                for slot, segment in enumerate(segments):
                    length = max(0.0, float(segment.get("seconds", 0)))
                    frame_count = min(max(0, expected - copied), round(length * SPEECH_RATE))
                    if not frame_count:
                        continue
                    part = bytes(frame_count * 2)
                    if segment.get("kind") == "video":
                        track = self.job / ("source_audio_%02d_%02d.wav" % (index, slot))
                        try:
                            run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
                                          "-stream_loop", "-1", "-i", str(segment["source"]), "-map", "0:a:0?",
                                          "-vn", "-t", "%.6f" % length, "-ar", str(SPEECH_RATE),
                                          "-ac", "1", "-c:a", "pcm_s16le", str(track)],
                                         self.root, log=self.log, cancel=self.cancel,
                                         timeout=max(FFMPEG_INPUT_TIMEOUT, int(length * 18)), capture=True)
                            if track.is_file():
                                with wave.open(str(track), "rb") as reader:
                                    if (reader.getnchannels() == 1 and reader.getsampwidth() == 2 and
                                            reader.getframerate() == SPEECH_RATE):
                                        data = reader.readframes(frame_count)[:frame_count * 2]
                                        part = data + bytes(max(0, frame_count * 2 - len(data)))
                                        if data:
                                            sound_count += 1
                        except InterruptedError:
                            raise
                        except (OSError, wave.Error, RuntimeError, TimeoutError) as error:
                            self.warn("第 %d 幕原视频 %s 音轨不可用，改为静音：%s" % (
                                index + 1, Path(segment["source"]).name, str(error)[:150]))
                    raw += part
                    copied += frame_count
                raw = raw[:expected * 2]
                writer.writeframesraw(raw)
                if len(raw) < expected * 2:
                    writer.writeframesraw(bytes(expected * 2 - len(raw)))
            writer.writeframes(b"")
        if not sound_count or wav_rms(destination) < .0001:
            destination.unlink(missing_ok=True)
            return None
        self.log("已保留 %d 段用户视频的原声，并自动对齐镜头时间线" % sound_count)
        return destination

    def background_audio_playlist(self, sources):
        if not sources:
            raise ValueError("未提供背景音乐")
        if len(sources) == 1:
            return sources[0]
        destination = self.job / "user_background_playlist.wav"
        args = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
        parts = []
        for index, path in enumerate(sources):
            if not Path(path).is_file():
                raise RuntimeError("背景音乐文件丢失：" + Path(path).name)
            args.extend(["-i", str(path)])
            parts.append("[%d:a]aresample=%d,aformat=sample_fmts=s16:channel_layouts=mono,"
                         "asetpts=PTS-STARTPTS[s%d]" % (index, SPEECH_RATE, index))
        filtergraph = ";".join(parts + ["".join("[s%d]" % index for index in range(len(sources))) +
                                        "concat=n=%d:v=0:a=1[music]" % len(sources)])
        args.extend(["-filter_complex", filtergraph, "-map", "[music]", "-c:a", "pcm_s16le", str(destination)])
        run_external(args, self.root, log=self.log, cancel=self.cancel,
                     timeout=max(180, int(len(sources) * FFMPEG_INPUT_TIMEOUT)), capture=True)
        if not destination.is_file() or destination.stat().st_size < 2000:
            raise RuntimeError("无法合并用户指定的多段背景音乐")
        self.log("已依照导入顺序合并 %d 段音频，不会只采用第一段" % len(sources))
        return destination


    def combine_audio(self, mute_video, voice, seconds, mood, seed, result,
                      voice_gain=1.1, background_gain=.17, ambient_gain=None):
        if self.media["narration"] and (not voice or wav_rms(voice) < .0007):
            raise RuntimeError("用户要求的中文旁白接近静音，不能作为已完成的配音交付")
        args = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(mute_video)]
        components = []
        if self.media["narration"]:
            position = len(components) + 1
            args.extend(["-i", str(voice)])
            components.append((position, "voice", voice_gain))
        if self.media["music"]:
            mus = self.job / "music.wav"
            supplied = self.request["files"].get("音频", [])
            if supplied and self.request.get("audio_role") == "作为背景音乐":
                source = self.background_audio_playlist(supplied)
                self.log("使用用户提供的背景音乐：" + str(source))
            else:
                generate_music(mus, seconds, mood, seed)
                source = mus
            position = len(components) + 1
            args.extend(["-stream_loop", "-1", "-i", str(source)])
            priority = self.request.get("source_audio_role") == "原声优先"
            components.append((position, "music", min(background_gain, .10) if priority else background_gain))
        ambient = getattr(self, "ambient_audio", None) if self.media["source_audio"] else None
        if ambient and Path(ambient).is_file():
            position = len(components) + 1
            args.extend(["-i", str(ambient)])
            priority = self.request.get("source_audio_role") == "原声优先"
            gain = (.65 if priority else AMBIENT_VOLUME) if ambient_gain is None else ambient_gain
            components.append((position, "ambient", gain))
        args.extend(["-map", "0:v:0"])
        if components:
            filters = []
            for position, name, gain in components:
                filters.append("[%d:a]aresample=%d,volume=%.4f[a_%s]" % (
                    position, SPEECH_RATE, gain, name))
            names = {name for _, name, _ in components}
            duck_targets = [name for name in ("music", "ambient") if name in names and "voice" in names]
            if duck_targets:
                filters.append("[a_voice]asplit=%d[voice_main]%s" % (
                    len(duck_targets) + 1, "".join("[voice_key_%s]" % name for name in duck_targets)))
            labels = ["[voice_main]" if duck_targets else "[a_voice]"] if "voice" in names else []
            for name in ("music", "ambient"):
                if name not in names:
                    continue
                if name in duck_targets:
                    filters.append("[a_%s][voice_key_%s]sidechaincompress="
                                   "threshold=0.025:ratio=6:attack=30:release=280[duck_%s]" % (
                                       name, name, name))
                    labels.append("[duck_%s]" % name)
                else:
                    labels.append("[a_%s]" % name)
            if len(labels) == 1:
                filters.append(labels[0] + "alimiter=limit=0.95[mix]")
            else:
                filters.append("".join(labels) + "amix=inputs=%d:duration=longest:dropout_transition=0:normalize=0,"
                               "alimiter=limit=0.95[mix]" % len(labels))
            args.extend(["-filter_complex", ";".join(filters), "-map", "[mix]", "-c:a", "aac", "-b:a", "160k"])
        else:
            args.append("-an")
        args.extend(["-c:v", "copy", "-t", "%.3f" % seconds, "-movflags", "+faststart", str(result)])
        run_external(args, self.root, log=self.log, cancel=self.cancel, timeout=300, capture=True)
        return result

    def inspect_temporal_bursts(self, source, durations):
        cursor = 0.0
        reviews = []
        for index, length in enumerate(durations):
            self.models.check_stop()
            checkpoint = read_json(self.job / ("scene_%02d.json" % index), {})
            visual = checkpoint.get("image", {})
            visual = visual if isinstance(visual, dict) else {}
            supplied = bool(visual.get("metrics", {}).get("user_supplied")) if isinstance(
                visual.get("metrics"), dict) else False
            require_motion = (visual.get("type") == "native_video" and not supplied and
                              requires_subject_motion(self.request.get("prompt", "") + " " +
                                  self.active_plan["scenes"][index]["visual_prompt"]))
            frames_required = max(MIN_MOTION_REVIEW_FRAMES,
                                  math.ceil(self.fps * min(TEMPORAL_REVIEW_SECONDS, length * .75)))
            if length < max(.33, frames_required / self.fps):
                reviews.append({"scene": index, "status": REVIEW_NOT_APPLICABLE,
                                "reason": "镜头短于连续帧可靠审查窗口"})
                cursor += length
                continue
            segments = visual.get("montage", [])
            cuts = []
            if isinstance(segments, list) and len(segments) > 1:
                elapsed = 0.0
                for part in segments[:-1]:
                    elapsed += max(0.0, float(part.get("seconds", 0)))
                    cuts.append(elapsed)
            sampled = False
            for slot, fraction in enumerate((.12, .50, .88)):
                window_seconds = frames_required / self.fps
                local = max(0.0, min(length - window_seconds - 1 / self.fps,
                                     length * fraction - window_seconds * .5))
                if any(local - 1 / self.fps <= cut <= local + window_seconds + 1 / self.fps
                       for cut in cuts):
                    continue
                sampled = True
                start = cursor + local
                base = self.job / ("temporal_%02d_%d" % (index, slot))
                files = [Path(str(base) + "_%03d.png" % number)
                         for number in range(1, frames_required + 1)]
                failure = None
                for attempt in range(MAX_TEMPORAL_RETRIES + 1):
                    self.models.check_stop()
                    for item in files:
                        item.unlink(missing_ok=True)
                    try:
                        run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                                      "-ss", "%.5f" % start, "-i", str(source),
                                      "-vf", "scale=128:72", "-frames:v", str(frames_required),
                                      str(base) + "_%03d.png"], self.root, cancel=self.cancel,
                                     timeout=90, capture=True)
                        if not all(item.is_file() for item in files):
                            raise RuntimeError("无法取得完整连续帧采样序列")
                        differences = [round(image_mean_difference(a, b), 4)
                                       for a, b in zip(files, files[1:])]
                        ordered = sorted(differences)
                        median = ordered[len(ordered) // 2]
                        peak = max(differences)
                        longest = streak = 0
                        for difference in differences:
                            streak = streak + 1 if difference <= TEMPORAL_DUPLICATE_MEAN_DIFF else 0
                            longest = max(longest, streak)
                        frozen_seconds = longest / self.fps
                        flicker = (sum(value >= MAX_NEIGHBOR_FRAME_DIFFERENCE for value in differences) >= 2)
                        jitter = (peak >= TEMPORAL_JITTER_SPIKE_MIN and
                                  peak > max(median * 5.5, TEMPORAL_JITTER_SPIKE_MIN) and
                                  sum(value >= peak * .76 for value in differences) >= 2)
                        freeze = require_motion and frozen_seconds >= MIN_VIDEO_FREEZE_SECONDS
                        code = ("TEMPORAL_FREEZE" if freeze else
                                "TEMPORAL_FLICKER" if flicker else
                                "TEMPORAL_JITTER" if jitter else None)
                        reviews.append({"scene": index, "position": round(start, 3),
                                        "neighbor_differences": differences,
                                        "freeze_seconds": round(frozen_seconds, 3),
                                        "required_motion": require_motion,
                                        "max_jump": round(peak, 3),
                                        "median_jump": round(median, 3),
                                        "failure_code": code,
                                        "status": REVIEW_FAIL if code else REVIEW_PASS,
                                        "attempts": attempt + 1})
                        failure = None
                        break
                    except InterruptedError:
                        raise
                    except (OSError, RuntimeError, ValueError, TimeoutError) as error:
                        failure = error
                        if attempt < MAX_TEMPORAL_RETRIES:
                            self.resources.adaptive_pause("temporal_retry", self.cancel)
                    finally:
                        for item in files:
                            item.unlink(missing_ok=True)
                if failure is not None:
                    reviews.append({"scene": index, "position": round(start, 3),
                                    "status": REVIEW_UNAVAILABLE,
                                    "attempts": MAX_TEMPORAL_RETRIES + 1,
                                    "error_type": type(failure).__name__, "error": str(failure)[:170]})
            if not sampled:
                reviews.append({"scene": index, "status": REVIEW_NOT_APPLICABLE,
                                "reason": "所有连续帧采样窗口与已有素材剪切点重叠"})
            cursor += length
        return reviews

    def review_spoken_narration(self, final_video, durations):
        report = []
        cursor = 0.0
        for index, duration in enumerate(durations):
            self.models.check_stop()
            record = read_json(self.job / ("scene_%02d.json" % index), {})
            original = record.get("voice")
            scene = self.active_plan["scenes"][index]
            if not original or not Path(original).is_file():
                report.append({"scene": index, "status": "missing_voice"})
                cursor += duration
                continue
            extracted = self.job / ("mix_review_%02d.wav" % index)
            try:
                run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                              "-i", str(final_video), "-ss", "%.6f" % cursor,
                              "-t", "%.6f" % duration, "-map", "0:a:0", "-vn",
                              "-ac", "1", "-ar", str(SPEECH_RATE),
                              "-c:a", "pcm_s16le", str(extracted)],
                             self.root, log=self.log, cancel=self.cancel,
                             timeout=max(FFMPEG_INPUT_TIMEOUT, int(duration * 20)), capture=True)
                mixed_rms = wav_rms(extracted)
                original_rms = wav_rms(original)
                correlation = voice_presence_correlation(original, extracted)
                base = {"scene": index, "start": round(cursor, 4),
                        "source_rms": round(original_rms, 6),
                        "mixed_rms": round(mixed_rms, 6),
                        "voice_correlation": round(correlation, 4),
                        "actual_track": str(final_video)}
                if (mixed_rms < MIN_MIXED_VOICE_RMS or
                        correlation < MIN_MIXED_VOICE_CORRELATION):
                    report.append({**base, "status": "mix_voice_missing"})
                    cursor += duration
                    continue
                original_text = self.models.transcribe(original, self.job, self.log,
                                                      max_seconds=min(duration + .5, ASR_WINDOW_SECONDS * 2),
                                                      include_timestamps=False,
                                                      language=self.media.get("voice_language", "zh"))
                mixed_text = self.models.transcribe(extracted, self.job, self.log,
                                                   max_seconds=min(duration + .5, ASR_WINDOW_SECONDS * 2),
                                                   include_timestamps=False,
                                                   language=self.media.get("voice_language", "zh"))
                source_match = speech_match(scene["narration"], original_text)
                mixed_match = speech_match(scene["narration"], mixed_text)
                report.append({**base, "status": "reviewed", "source": source_match,
                               "mixed": mixed_match,
                               "method": "final_mp4_aac_track_and_source_asr_with_waveform_correlation"})
            except InterruptedError:
                raise
            except (RuntimeError, OSError, ValueError, MemoryError, TimeoutError, wave.Error) as error:
                report.append({"scene": index, "status": "recognition_unavailable",
                               "failure": str(error)[:240], "actual_track": str(final_video)})
            cursor += duration
        atomic_json(self.job / "speech_review.json", report)
        return report


    def enforce_video_boundaries(self, path, seconds):
        if not self.request["files"].get("首帧") and not self.request["files"].get("尾帧"):
            return
        path = Path(path)
        if not hasattr(self, "boundary_adjusted"):
            self.boundary_adjusted = set()
        if str(path) in self.boundary_adjusted:
            return
        inputs = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(path)]
        layers = []
        last = "v0"
        duration = max(MIN_NATIVE_BRIDGE_SECONDS, float(seconds))
        blend = min(BOUNDARY_BLEND_SECONDS, duration / 5)
        hold = min(BOUNDARY_FINAL_HOLD_SECONDS, duration / 10)
        parts = ["[0:v]format=rgba[v0]"]
        for name, position in (("首帧", "head"), ("尾帧", "tail")):
            if not self.request["files"].get(name):
                continue
            source = self.request["files"][name][0]
            boundary = self.job / ("final_boundary_" + position + ".png")
            frame_with_caption(source, boundary, self.size, "", "")
            inputs.extend(["-loop", "1", "-framerate", str(self.fps), "-i", str(boundary)])
            number = len(layers) + 1
            fade = ("fade=t=out:st=0:d=%.6f:alpha=1" % blend if position == "head" else
                    "fade=t=in:st=%.6f:d=%.6f:alpha=1" % (
                        max(0.0, duration - blend - hold), blend))
            parts.append("[%d:v]format=rgba,%s[overlay%d]" % (number, fade, number))
            target = "v%d" % number
            parts.append("[%s][overlay%d]overlay=0:0:shortest=1[%s]" % (last, number, target))
            last = target
            layers.append(position)
        if not layers:
            return
        parts.append("[%s]format=yuv420p[video]" % last)
        temporary = path.with_name(path.stem + ".boundary.partial.mp4")
        try:
            run_external(inputs + ["-filter_complex", ";".join(parts), "-map", "[video]",
                                   "-map", "0:a?", "-t", "%.6f" % seconds,
                                   "-c:v", "libx264", "-crf", "22", "-preset", "veryfast",
                                   "-c:a", "copy", "-pix_fmt", "yuv420p", str(temporary)],
                         self.root, log=self.log, cancel=self.cancel,
                         timeout=max(240, int(seconds * 30)), capture=True)
            if not temporary.is_file() or temporary.stat().st_size < 8192:
                raise RuntimeError("指定首尾帧最终合成失败，禁止忽略用户输入")
            os.replace(temporary, path)
            self.boundary_adjusted.add(str(path))
        finally:
            temporary.unlink(missing_ok=True)

    def check_final(self, path, seconds, scene_durations=None):
        result = {"passed": False, "technical_pass": False, "semantic_pass": False,
                  "delivery_allowed": False, "file": str(path),
                  "expected_seconds": round(seconds, 3),
                  "checked": datetime.datetime.now().isoformat(), "media_preferences": self.media}
        if not Path(path).is_file() or Path(path).stat().st_size < 8192:
            result["failure_code"] = "OUTPUT_MISSING"
            result["failure"] = "成片不存在或大小异常"
            return result
        self.log("检查成片全部音视频流、时长及抽样画面")
        try:
            audio_expected = bool(self.media["narration"] or self.media["music"] or
                                  (self.media["source_audio"] and getattr(self, "ambient_audio", None)))
            decode_args = [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-xerror",
                           "-i", str(path), "-map", "0:v:0"]
            decode_args.extend(["-map", "0:a:0"] if audio_expected else ["-an"])
            decode_args.extend(["-progress", "pipe:1", "-f", "null", "-"])
            output = run_external(decode_args, self.root, cancel=self.cancel,
                                  timeout=max(240, int(seconds * 18)), capture=True)
        except (RuntimeError, TimeoutError, OSError) as error:
            result["failure_code"] = "DECODE_FAILURE"
            result["failure"] = "音视频流缺失或解码失败：" + str(error)[:500]
            return result
        progress = re.findall(r"out_time_(?:us|ms)=(\d+)", output)
        if not progress:
            result["failure_code"] = "DURATION_UNREADABLE"
            result["failure"] = "无法读取完整解码后的媒体时长"
            return result
        actual_seconds = int(progress[-1]) / 1000000
        result["actual_seconds"] = round(actual_seconds, 3)
        allowed = max(.18, seconds * MAX_FINAL_DURATION_DRIFT)
        if abs(actual_seconds - seconds) > allowed:
            result["failure_code"] = "DURATION_MISMATCH"
            result["failure"] = "视频长度与分镜时长偏差过大"
            return result
        probes = {}
        probe_masks = {}
        captions = read_json(self.job / "subtitle_timeline.json", [])
        if scene_durations:
            cursor = 0.0
            for scene_index, duration in enumerate(scene_durations):
                if strict_visual_quantities(self.request["prompt"]):
                    for fraction in (.25, .75):
                        point = round(cursor + duration * fraction, 3)
                        probes[point] = scene_index
                caption_record = (captions[scene_index] if isinstance(captions, list) and
                                  scene_index < len(captions) and isinstance(captions[scene_index], dict)
                                  else {})
                if duration > .5 and not caption_record.get("segments"):
                    position = round(cursor + duration * .5, 3)
                    probes[position] = scene_index
                if isinstance(captions, list) and scene_index < len(captions) and isinstance(captions[scene_index], dict):
                    for segment in captions[scene_index].get("segments", []):
                        if isinstance(segment, dict):
                            start = float(segment.get("start", 0))
                            end = float(segment.get("end", 0))
                            if 0 <= start < end <= duration + 1 / self.fps:
                                point = round(cursor + (start + end) / 2, 3)
                                probes[point] = scene_index
                                probe_masks[point] = segment.get("path")
                cursor += duration
        else:
            probes = {round(max(.5, min(seconds - .4, seconds * ratio)), 3): None
                      for ratio in (.2, .5, .8)}
        endpoints = {}
        if self.request["files"].get("首帧"):
            endpoints[0.0] = 0
        if self.request["files"].get("尾帧"):
            tail_position = round(max(0.0, min(actual_seconds, seconds) -
                                      MIN_BOUNDARY_VISIBLE_FRAMES / self.fps), 3)
            if tail_position <= 0.0 and self.request["files"].get("首帧"):
                result.update({"failure_code": "DURATION_MISMATCH",
                               "failure": "视频时长不足以分别展示用户指定的首尾帧"})
                return result
            endpoints[tail_position] = len(scene_durations) - 1 if scene_durations else None
        caption_probe_positions = set(probe_masks)
        montage_segments = {}
        if scene_durations:
            scene_start = 0.0
            for scene_index, duration in enumerate(scene_durations):
                saved = read_json(self.job / ("scene_%02d.json" % scene_index), {}).get("image", {})
                parts = saved.get("montage", []) if isinstance(saved, dict) else []
                if isinstance(parts, list) and parts:
                    montage_segments[scene_index] = parts
                    elapsed = 0.0
                    for part in parts:
                        length = max(0.0, float(part.get("seconds", 0)))
                        if length >= 2 / self.fps:
                            middle = round(scene_start + elapsed + length * 0.5, 3)
                            if scene_start <= middle < scene_start + duration:
                                probes[middle] = scene_index
                        elapsed += length
                scene_start += duration
        probes.update(endpoints)
        positions = sorted(probes)
        semantic_reviews = []
        semantic_unreviewed = []
        checked_frame_paths = []
        for index, position in enumerate(positions):
            frame_path = self.job / ("final_check_%02d.png" % index)
            try:
                run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                              "-ss", str(position), "-i", str(path), "-frames:v", "1", str(frame_path)],
                             self.root, cancel=self.cancel, timeout=80, capture=True)
                frame_scene = probes[position]
                frame_scene_text = (self.request["prompt"] + " " +
                    self.active_plan["scenes"][frame_scene]["visual_prompt"] if
                    frame_scene is not None and hasattr(self, "active_plan") and
                    frame_scene < len(self.active_plan["scenes"]) else self.request["prompt"])
                valid, reason = validate_image(frame_path, allow_flat=position in endpoints,
                                               scene_text=frame_scene_text)
                if valid and position in endpoints and probes[position] is not None:
                    from PIL import Image, ImageChops, ImageStat
                    expected_source = (self.request["files"]["首帧"][0] if position == 0.0 else
                                       self.request["files"]["尾帧"][0])
                    expected_image = self.job / ("boundary_expected_%02d.png" % probes[position])
                    frame_with_caption(expected_source, expected_image, self.size, "", "")
                    if expected_image.is_file():
                        with Image.open(expected_image) as reference, Image.open(frame_path) as rendered:
                            baseline = reference.convert("RGB").resize((128, 128))
                            observed = rendered.convert("RGB").resize((128, 128))
                            delta = sum(ImageStat.Stat(ImageChops.difference(baseline, observed)).mean) / 3
                        if delta > BOUNDARY_FRAME_MEAN_DIFF_MAX:
                            valid, reason = False, "首尾画面与用户指定素材不一致（偏差 %.1f）" % delta
            except (RuntimeError, OSError, TimeoutError, ValueError) as error:
                valid, reason = False, str(error)
            if not valid:
                result["failure_code"] = "SCENE_FRAME_INVALID"
                result["failure"] = "成片在 %.2f 秒处出现异常画面：%s" % (position, reason)
                if probes[position] is not None:
                    result["scene"] = probes[position]
                elif scene_durations:
                    cursor = 0
                    for scene_index, duration in enumerate(scene_durations):
                        cursor += duration
                        if position <= cursor:
                            result["scene"] = scene_index
                            break
                return result
            scene_index = probes[position]
            checked_frame_paths.append((scene_index, position, frame_path))
            if (scene_index is not None and position not in endpoints and
                    position in caption_probe_positions and self.media["subtitles"]):
                saved_visual = read_json(self.job / ("scene_%02d.json" % scene_index), {}).get("image", {})
                local_position = position - sum(scene_durations[:scene_index]) if scene_durations else 0
                segments = saved_visual.get("overlays", [])
                active_segment = next((entry for entry in segments if
                                       entry.get("start", -1) <= local_position <
                                       entry.get("end", -1) - CAPTION_SEGMENT_GAP_FRAMES / self.fps), None)
                mask = probe_masks.get(position) or (active_segment or {}).get("path")
                if mask and Path(mask).is_file():
                    try:
                        readable, detail = caption_visible(mask, frame_path)
                    except (OSError, ValueError) as error:
                        readable, detail = False, {"error": str(error)[:180]}
                    if not readable:
                        result.update({"failure_code": "CAPTION_VISIBILITY", "scene": scene_index,
                                       "caption_visibility": detail,
                                       "failure": "第 %d 幕成片字幕可能被遮挡或未正确叠加" % (scene_index + 1)})
                        return result
                else:
                    result.update({"failure_code": "CAPTION_VISIBILITY", "scene": scene_index,
                                   "failure": "字幕参考遮罩丢失或时段配置有缺漏，无法确认文字是否可见"})
                    return result
            if (scene_index is not None and position not in endpoints
                    and hasattr(self, "active_plan") and scene_index < len(self.active_plan["scenes"])):
                saved = read_json(self.job / ("scene_%02d.json" % scene_index), {})
                base_visual = saved.get("image", {})
                baseline = base_visual.get("metrics") if isinstance(base_visual, dict) else None
                selected_segment = None
                cursor = sum(scene_durations[:scene_index]) if scene_durations else 0.0
                local_time = max(0.0, position - cursor)
                for part in montage_segments.get(scene_index, []):
                    if float(part.get("start", -1)) - 1 / self.fps <= local_time < float(part.get("end", -1)) + 1 / (self.fps * 4):
                        selected_segment = part
                        if isinstance(part.get("review"), dict):
                            baseline = part["review"]
                        break
                if not isinstance(baseline, dict) or baseline.get("semantic_passed") is None:
                    semantic_unreviewed.append({"scene": scene_index,
                                                "status": "not_checked",
                                                "reason": "扩展离线审校未准备好或未记录"})
                elif baseline.get("semantic_passed") is False:
                    semantic_unreviewed.append({"scene": scene_index,
                                                "status": "user_supplied_conflict",
                                                "reason": "保留用户指定素材，未声称语义通过"})
                elif baseline.get("passed"):
                    try:
                        semantics = self.models.image_similarity(
                            frame_path, self.active_plan["scenes"][scene_index]["visual_prompt"])
                    except InterruptedError:
                        raise
                    except (RuntimeError, OSError, ValueError, MemoryError) as error:
                        result.update({"failure_code": "SEMANTIC_REVIEW_UNAVAILABLE", "scene": scene_index,
                                       "failure": "成片 AI 语义复检无法完成：" + str(error)[:280]})
                        return result
                    original = float(baseline.get("cosine", MIN_CLIP_COSINE))
                    retention = max(MIN_CLIP_ABSOLUTE_COSINE, original * MIN_FINAL_SEMANTIC_RETENTION)
                    minimum_margin = max(MIN_CLIP_ABSOLUTE_MARGIN,
                                         float(baseline.get("margin", MIN_CLIP_MARGIN)) * .30)
                    accepted = (semantics["cosine"] >= retention and
                                semantics["margin"] >= minimum_margin and
                                semantics["subject_margin"] >= MIN_CLIP_ABSOLUTE_MARGIN)
                    semantic_reviews.append({"scene": scene_index, "position": position,
                                             "source_slot": selected_segment.get("slot") if selected_segment else 0,
                                             "source_kind": selected_segment.get("kind") if selected_segment else
                                             base_visual.get("type", "unknown"),
                                             "original_cosine": original,
                                             "final": semantics, "required_cosine": round(retention, 4),
                                             "required_margin": round(minimum_margin, 4), "passed": accepted})
                    if not accepted:
                        result.update({"failure_code": "FINAL_SEMANTIC_MISMATCH", "scene": scene_index,
                                       "semantic_reviews": semantic_reviews,
                                       "failure": "第 %d 幕成片画面偏离已审校的生成内容" % (scene_index + 1)})
                        return result
        temporal_reviews = self.inspect_temporal_bursts(path, scene_durations or [seconds])
        result["temporal_reviews"] = temporal_reviews
        temporal_unreviewed = []
        for review in temporal_reviews:
            index = review["scene"]
            checkpoint = read_json(self.job / ("scene_%02d.json" % index), {})
            visual = checkpoint.get("image", {})
            user_supplied = bool(visual.get("metrics", {}).get("user_supplied"))
            if review.get("status") == REVIEW_UNAVAILABLE:
                if not user_supplied:
                    result.update({"failure_code": "TEMPORAL_REVIEW_UNAVAILABLE", "scene": index,
                                   "failure": "第 %d 幕连续帧审校重试后仍不可用，不能宣称已通过" % (index + 1),
                                   "temporal_unreviewed": [review]})
                    return result
                temporal_unreviewed.append(review)
                self.warn("第 %d 幕用户素材的连续帧审核未完成，保留素材并标记未审校" % (index + 1))
            elif review.get("status") == REVIEW_NOT_APPLICABLE:
                temporal_unreviewed.append(review)
            elif review.get("status") == REVIEW_FAIL:
                if visual.get("type") in {"image", "native_video"} and not user_supplied:
                    code = review.get("failure_code") or "TEMPORAL_FLICKER"
                    reasons = {"TEMPORAL_FREEZE": "真实动作镜头出现长时间卡帧",
                               "TEMPORAL_JITTER": "连续帧出现异常跳变",
                               "TEMPORAL_FLICKER": "相邻帧发生严重闪烁"}
                    result.update({"failure_code": code, "scene": index,
                                   "failure": "第 %d 幕%s，需定向修复" % (
                                       index + 1, reasons.get(code, "动作连续性审校不通过"))})
                    return result
                temporal_unreviewed.append(review)
                self.warn("第 %d 幕用户原始视频包含强烈快速变化，已保留用户素材" % (index + 1))
        result["temporal_unreviewed"] = temporal_unreviewed
        preview = self.job / "final_preview.png"
        shutil.copy2(self.job / ("final_check_%02d.png" % (len(positions) // 2)), preview)
        if audio_expected:
            try:
                audio_scan = run_external([self.ffmpeg, "-hide_banner", "-nostdin", "-i", str(path),
                                           "-vn", "-af", "volumedetect", "-f", "null", "-"],
                                          self.root, cancel=self.cancel,
                                          timeout=max(120, int(seconds * 5)), capture=True)
                found = re.search(r"mean_volume:\s*(-?inf|-?[\d.]+)\s*dB", audio_scan)
                if not found or found.group(1) == "-inf" or float(found.group(1)) < -65:
                    result["failure_code"] = "AUDIO_LOW"
                    result["failure"] = "按用户要求保留的声轨静音或音量过低，拒绝交付"
                    return result
                result["mean_volume_db"] = float(found.group(1))
            except (RuntimeError, TimeoutError, OSError, ValueError) as error:
                result["failure_code"] = "AUDIO_SCAN_FAILED"
                result["failure"] = "成片声音检查失败：" + str(error)[:350]
                return result
        else:
            try:
                run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
                              "-i", str(path), "-map", "0:a:0", "-t", "0.1", "-f", "null", "-"],
                             self.root, cancel=self.cancel, timeout=40, capture=True)
                result.update({"failure_code": "UNWANTED_AUDIO", "failure": "用户要求静音，但成片仍包含音轨"})
                return result
            except RuntimeError:
                result["audio_policy_verified"] = "no_audio_stream"
            except (TimeoutError, OSError) as error:
                result.update({"failure_code": "AUDIO_SCAN_FAILED", "failure": str(error)[:350]})
                return result
        if scene_durations:
            if not isinstance(captions, list) or len(captions) != len(scene_durations):
                result.update({"failure_code": "CAPTION_TIMELINE_MISSING",
                               "failure": "字幕与旁白时间线记录缺失或镜头数量不匹配"})
                return result
            cursor = 0.0
            caption_checks = []
            for index, (caption, duration) in enumerate(zip(captions, scene_durations)):
                scene = self.active_plan["scenes"][index]
                valid = isinstance(caption, dict) and isinstance(caption.get("segments"), list)
                parts = caption.get("segments", []) if valid else []
                if valid:
                    valid = bool(parts) == self.media["subtitles"] and all(isinstance(part, dict) for part in parts)
                if valid:
                    try:
                        requested_caption = scene.get("narration", "") if self.media["subtitles"] else ""
                        reconstructed = normalized_caption("".join(str(part.get("text", "")) for part in parts))
                        voice = caption.get("voice_file")
                        voice_seconds = float(caption.get("voice_seconds", -1))
                        if self.media["narration"]:
                            voice_valid = (isinstance(voice, str) and Path(voice).is_file() and
                                           0 < voice_seconds <= duration + .05 and math.isfinite(voice_seconds) and
                                           file_integrity_hash(voice) == caption.get("voice_sha256"))
                        else:
                            voice_valid = (voice is None and caption.get("voice_sha256") is None and
                                           voice_seconds == 0.0)
                        valid = (caption.get("caption") == requested_caption and
                                 abs(float(caption.get("from", -1)) - cursor) <= 2 / self.fps and
                                 abs(float(caption.get("to", -1)) - cursor - duration) <= 2 / self.fps and
                                 voice_valid and reconstructed == normalized_caption(requested_caption))
                        prior_end = 0.0
                        for part in parts:
                            filename = part.get("path")
                            start = float(part.get("start", -1))
                            finish = float(part.get("end", -1))
                            if (not isinstance(filename, str) or not Path(filename).is_file() or
                                    not all(math.isfinite(value) for value in (start, finish)) or
                                    not 0 <= start < finish <= duration + 1 / self.fps or
                                    start + 1 / self.fps < prior_end or
                                    full_file_sha256(filename) != part.get("sha256")):
                                valid = False
                                break
                            prior_end = finish
                    except (OSError, TypeError, ValueError, OverflowError):
                        valid = False
                if not valid:
                    result.update({"failure_code": "CAPTION_TIMELINE_MISMATCH", "scene": index,
                                   "failure": "第 %d 幕字幕/旁白清单违反文本、时间轴或静音要求" % (index + 1)})
                    return result
                caption_checks.append({"scene": index, "pages": len(parts),
                                       "voice_verified": self.media["narration"],
                                       "full_text_covered": self.media["subtitles"]})
                cursor += duration
            result["caption_manifest_verified"] = True
            result["caption_checks"] = caption_checks
        result["frames_checked"] = positions
        result["semantic_reviews"] = semantic_reviews
        result["semantic_unreviewed"] = semantic_unreviewed
        if scene_durations and self.media["narration"] and self.capabilities["speech_review"]:
            speech_reviews = self.review_spoken_narration(path, scene_durations)
            result["speech_reviews"] = speech_reviews
            for review in speech_reviews:
                issue = speech_review_failure(review)
                if issue:
                    result.update({"failure_code": issue, "scene": review["scene"],
                                   "failure": "第 %d 幕成片真实音轨与原旁白不符或声音不可辨认：%s" %
                                   (review["scene"] + 1, issue)})
                    return result
        elif not self.media["narration"]:
            result["speech_reviews"] = [{"status": "not_applicable", "reason": "用户明确要求无旁白"}]
        else:
            result["speech_reviews"] = [{"status": "not_checked", "reason": "语音识别模型未验收"}]
        quantity_obligations = strict_visual_quantities(self.request["prompt"])
        result["strict_visual_quantities"] = quantity_obligations
        result["quantity_reviews"] = []
        for obligation in quantity_obligations:
            relevant = [index for index, scene in enumerate(self.active_plan["scenes"])
                        if visual_constraints_retained(scene["visual_prompt"], [obligation["anchor"]])]
            if not relevant:
                result.update({"failure_code": "HARD_QUANTITY_MISSING_IN_PLAN",
                               "failure": "精确数量要求未被任何分镜保留：" + obligation["anchor"]})
                return result
            for scene_index in relevant:
                samples = [frame for index, position, frame in checked_frame_paths
                           if index == scene_index and position not in endpoints]
                if len(samples) < MIN_QUANTITY_FRAME_REVIEWS:
                    result.update({"failure_code": "HARD_QUANTITY_UNVERIFIED", "scene": scene_index,
                                   "failure": "指定数量的分镜没有实际成片采样，不能通过审校"})
                    return result
                evidence = []
                for frame in samples[:MIN_QUANTITY_FRAME_REVIEWS]:
                    try:
                        evidence.append(self.models.image_quantity_evidence(frame, obligation["anchor"]))
                    except InterruptedError:
                        raise
                    except (RuntimeError, OSError, ValueError, MemoryError) as error:
                        result.update({"failure_code": "HARD_QUANTITY_REVIEW_UNAVAILABLE",
                                       "scene": scene_index, "failure": "精确数量约束复查失败：" + str(error)[:220]})
                        return result
                audit = {"scene": scene_index, "anchor": obligation["anchor"],
                         "evidence": evidence, "passed": all(entry.get("passed") is True for entry in evidence),
                         "method": "独立目标检测器分场景多帧逐实例计数",
                         "assurance": "model_checked_not_infallible"}
                result["quantity_reviews"].append(audit)
                if not audit["passed"]:
                    result.update({"failure_code": "HARD_QUANTITY_MISMATCH", "scene": scene_index,
                                   "failure": "第%d幕的%s未通过多帧实例数量验证，需定向重生成" % (
                                       scene_index + 1, obligation["anchor"])})
                    return result
        words = exact_screen_text_requirements(self.request["prompt"])
        result["screen_text_requirements"] = words
        result["screen_text_reviews"] = []
        if words:
            if not optional_ocr_ready(self.root):
                result.update({"failure_code": "EXACT_TEXT_REVIEW_UNAVAILABLE",
                               "failure": "用户指定精确画面文字，但离线OCR尚未通过安装验收，不能声称已核实"})
                return result
            import numpy as np
            from PIL import Image
            from rapidocr import RapidOCR
            reader = RapidOCR()
            saved_overlays = {index: read_json(self.job / ("scene_%02d.json" % index), {}).get(
                "image", {}).get("overlays", []) for index in range(len(scene_durations or []))}
            for word_index, phrase in enumerate(words):
                schedule = exact_text_probe_schedule(
                    phrase, self.active_plan["scenes"], scene_durations or [], saved_overlays,
                    captions, self.fps)
                candidates = list(schedule["probes"])
                if not candidates and checked_frame_paths:
                    candidates = [{"scene": index, "position": pos, "basis": "general_review",
                                   "window": [pos, pos]}
                                  for index, pos, _ in checked_frame_paths[:MAX_VISUAL_TEXT_PROBES]]
                snapshots = []
                saw = False
                failed_extracts = 0
                for candidate_index, entry in enumerate(candidates):
                    self.models.check_stop()
                    scene_index = entry["scene"]
                    position = entry["position"]
                    stored = next((frame for index, at, frame in checked_frame_paths
                                   if index == scene_index and abs(at - position) < .35 / self.fps), None)
                    frame = stored or self.job / ("screen_text_check_%02d_%03d.png" % (
                        word_index, candidate_index))
                    if stored is None:
                        try:
                            run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
                                          "-ss", str(position), "-i", str(path), "-frames:v", "1", str(frame)],
                                         self.root, cancel=self.cancel, timeout=80, capture=True)
                            valid, reason = validate_image(frame, allow_flat=True)
                            if not valid:
                                raise RuntimeError(reason)
                        except InterruptedError:
                            raise
                        except (RuntimeError, OSError, TimeoutError, ValueError) as error:
                            failed_extracts += 1
                            snapshots.append({"scene": scene_index, "position": position,
                                              "status": "frame_unavailable", "error": str(error)[:140]})
                            continue
                    try:
                        with Image.open(frame) as bitmap:
                            recognized = reader(np.asarray(bitmap.convert("RGB")))
                        lines = [str(item).strip() for item in (getattr(recognized, "txts", None) or [])
                                 if str(item).strip()]
                        verified = bool(normalized_caption(phrase) and normalized_caption(phrase) in
                                        normalized_caption("".join(lines)))
                    except InterruptedError:
                        raise
                    except (RuntimeError, OSError, ValueError, TypeError) as error:
                        failed_extracts += 1
                        snapshots.append({"scene": scene_index, "position": position,
                                          "status": "ocr_unavailable", "error": str(error)[:140]})
                        continue
                    snapshots.append({"scene": scene_index, "position": position,
                                      "basis": entry["basis"], "recognized": lines[:24],
                                      "status": "checked", "passed": verified})
                    if verified:
                        saw = True
                        break
                review = {"required": phrase, "samples": snapshots, "passed": saw,
                          "expected_probes": schedule["expected_probes"],
                          "planned_windows": schedule["timelines"],
                          "explicit_overlay": schedule["overlay_grounded"],
                          "sampling_complete": not schedule["incomplete"] and not failed_extracts,
                          "method": "依照精确文字显示时段多帧OCR核对成片"}
                result["screen_text_reviews"].append(review)
                if not saw:
                    incomplete = schedule["incomplete"] or failed_extracts or not candidates
                    result.update({"failure_code": ("EXACT_TEXT_REVIEW_INCOMPLETE" if incomplete else
                                                    "EXACT_TEXT_UNVERIFIED"),
                                   "scene": snapshots[0].get("scene") if snapshots else None,
                                   "failure": ("成片指定文字的对应时间窗未被完整采样，无法证明不存在：" if incomplete else
                                               "在指定时间窗实测帧内无法识别精确屏幕文字：") + phrase[:64]})
                    return result
        requirements = self.data.get("source_requirements", [])
        plan_checks = self.data.get("source_requirement_plan_checks", [])
        result["source_requirement_reviews"] = [{"id": entry.get("id"),
            "source": entry.get("source"), "scene": entry.get("scene"),
            "plan_quote_still_present": source_plan_quote_present(self.active_plan, entry),
            "semantic_review_passed": entry.get("scene") in {
                review.get("scene") for review in semantic_reviews if review.get("passed") is True},
            "assurance": "planned-and-heuristically-reviewed-not-factual-proof"}
            for entry in plan_checks]
        if len(plan_checks) != len(requirements) or any(
                not item["plan_quote_still_present"] or not item["semantic_review_passed"]
                for item in result["source_requirement_reviews"]):
            result.update({"failure_code": "SOURCE_REQUIREMENT_UNVERIFIED",
                           "failure": "来源材料至少一条硬性条件缺少持续的分镜或成片语义复核证据，禁止交付"})
            return result
        report = evaluate_delivery_review_coverage(
            len(scene_durations or []), semantic_reviews, semantic_unreviewed,
            temporal_unreviewed, result.get("speech_reviews", []), self.capabilities,
            self.media["narration"])
        result["review_coverage"] = report
        result["technical_pass"] = True
        result["semantic_pass"] = report["semantic_pass"]
        result["delivery_allowed"] = report["delivery_allowed"]
        result["review_level"] = ("multimodal_heuristic_reviewed" if report["delivery_allowed"] else
                                  "partially_reviewed" if scene_durations else "technical_only")
        result["checks"] = {"decode": True, "duration": True, "sampled_frames": True,
                            "temporal_neighbors": sum(review.get("status") == REVIEW_PASS
                                                      for review in temporal_reviews),
                            "temporal_unreviewed": len(temporal_unreviewed),
                            "audio_presence": audio_expected,
                            "subtitle_timeline": bool(scene_durations and self.media["subtitles"]),
                            "caption_visibility": self.media["subtitles"],
                            "content_semantics": "CLIP 启发式复检及显式文字约束审查；身份、数量、真实动作和事实无法被此模型可靠证明",
                            "subtitle_text": "字幕原文、时间轴及遮罩文件已检查；未声称 OCR 逐字验证",
                            "speech_synchronization": ("成片实际 AAC 音轨逐幕提取，配合源音轨 ASR 与波形相关性复检"
                                                       if self.media["narration"] else "无旁白，语音核验不适用")}
        result["limitations"] = ["CLIP 不能严格验证精确数量、人物身份、历史事实和动作完成度",
                                 "精确数量要求必须有独立目标计数证据，否则标为未验证并禁止交付",
                                 "已执行生成提示词约束保留检查及每段素材中点的成片复检"]
        result["passed"] = bool(result["technical_pass"] and result["delivery_allowed"])
        if not result["passed"]:
            result.update({key: report[key] for key in ("failure_code", "failure", "scene") if key in report})
        return result

    def start(self):
        set_low_priority()
        try:
            self.models = LocalModels(self.root, lambda s: self.step(s), self.cancel,
                                      quality=self.request.get("quality", "智能"), resources=self.resources)
            self.data["selected_models"] = dict(self.models.model_choices)
            self.resources.start_monitor(self.cancel, self.log)
            self.data["render_mode_requested"] = self.request.get("visual_mode", "智能轻量运镜")
            seconds = int(self.request["duration"])
            pixels = self.size[0] * self.size[1]
            estimated_media = int(seconds * self.fps * pixels * .16) + 240 * 1024 * 1024
            self.resources.ensure("job_preflight", disk_required=MIN_JOB_FREE + estimated_media)
            self.data["disk_budget"] = {"estimated_intermediate_bytes": estimated_media,
                                         "reserve_bytes": MIN_JOB_FREE}
            self.publish_event("phase", phase="preparing")
            self.step("将素材安全保存至工作目录，避免移动设备断开后丢失", 2)
            localized = localize_request_assets(self.root, self.request, self.job, self.cancel,
                                                self.log, self.data)
            self.data["localized_sources"] = localized
            self.data["request"] = self.request
            atomic_json(self.job / "job.json", self.data)
            self.step("检查并恢复链接与缓存素材", 3)
            cpu_mode = self.models.device == "cpu"
            optimal_length = 5.0 if self.capabilities.get("native_video") else (9 if cpu_mode else 6)
            maximum_by_time = max(1, int(round(seconds * self.fps) //
                                         math.ceil(MIN_MULTI_SCENE_SECONDS * self.fps)))
            maximum_by_engine = (MAX_NATIVE_SEGMENTS if self.request.get("visual_mode", "").startswith("原生AI视频")
                                 else max(6, min(72, math.ceil(seconds / max(4.5, optimal_length)))))
            limit_scenes = max(1, min(maximum_by_time, maximum_by_engine))
            recommended = max(1, min(limit_scenes, math.ceil(seconds / optimal_length)))
            if any(self.request["files"].get(kind) for kind in ("首帧", "尾帧", "图片", "视频")):
                recommended = min(limit_scenes, max(2, recommended))
            previous_plan = read_json(self.job / "storyboard.json", {})
            saved_scenes = previous_plan.get("scenes") if isinstance(previous_plan, dict) else None
            scenes = (len(saved_scenes) if isinstance(saved_scenes, list) and
                      previous_plan.get("plan_source") == "local_model_verified_batches" and
                      1 <= len(saved_scenes) <= limit_scenes and validate_plan(previous_plan, len(saved_scenes))
                      else recommended)
            timeline = semantic_timeline(seconds, previous_plan["scenes"] if validate_plan(previous_plan, scenes)
                                         else [{"narration": ""} for _ in range(scenes)], self.fps)
            self.publish_event("phase", phase="planning")
            if (previous_plan.get("plan_source") == "local_model_verified_batches" and
                    validate_plan(previous_plan, scenes) and
                    self.data.get("source_requirement_audit_version") == PIPELINE_VERSION and
                    len(self.data.get("source_requirement_plan_checks", [])) == len(
                        self.data.get("source_requirements", [])) and
                    all(source_plan_quote_present(previous_plan, check)
                        for check in self.data.get("source_requirement_plan_checks", []))):
                self.step("恢复已有分镜，继续未完成的镜头", 14)
                plan = previous_plan
                self.media = self.data.get("media_preferences", self.media)
                self.cache_signature = hashlib.sha256((model_signature(self.root, include_optional=True) +
                    self.voice_backend + PIPELINE_VERSION + json.dumps(self.media, sort_keys=True)).encode("utf-8")).hexdigest()
            else:
                self.step("理解提示词及全部素材", 4)
                reference = self.gather_inputs()
                self.models.listener = None
                self.models.listener_processor = None
                gc.collect()
                self.step("AI 自主规划声画与分镜", 12)
                self.media = self.models.decide_media(self.request["prompt"], reference, self.media)
                if self.request.get("audio_role") == "作为背景音乐" and self.request["files"].get("音频"):
                    if self.media.get("music_policy") != "forbidden":
                        self.media["music"] = True
                self.data["media_preferences"] = self.media
                self.cache_signature = hashlib.sha256((model_signature(self.root, include_optional=True) +
                    self.voice_backend + PIPELINE_VERSION + json.dumps(self.media, sort_keys=True)).encode("utf-8")).hexdigest()
                atomic_json(self.job / "job.json", self.data)
                for planning_attempt in range(MAX_PLAN_REPAIR_PASSES + 1):
                    try:
                        plan = self.models.plan(self.request["prompt"], reference, scenes, seconds,
                                                self.media, self.data.get("source_requirements", []))
                        checks = verify_source_requirements_in_plan(
                            self.models, plan, self.data.get("source_requirements", []))
                        self.data["source_requirement_plan_checks"] = checks
                        atomic_json(self.job / "job.json", self.data)
                        break
                    except RuntimeError as error:
                        if (planning_attempt == MAX_PLAN_REPAIR_PASSES or
                                not any(piece in str(error) for piece in (
                                    "分镜规划未保留用户明确指定的视觉属性",
                                    "分镜规划没有逐项保留来源文档的硬性约束"))):
                            raise
                        self.log("AI 分镜遗漏硬性视觉条件，重新规划完整分镜：%d/%d" % (
                            planning_attempt + 1, MAX_PLAN_REPAIR_PASSES))
                atomic_json(self.job / "storyboard.json", plan)
            for planning_attempt in range(MAX_PLAN_REPAIR_PASSES):
                missing = missing_plan_quantities(plan, self.request["prompt"])
                if not missing:
                    break
                self.log("分镜缺少明确数量约束，要求 AI 修正后再进入画面生成：" + missing[0])
                self.repair_plan(plan, missing[0])
            if missing_plan_quantities(plan, self.request["prompt"]):
                raise RuntimeError("AI 未能保留全部精确数量约束，已停止以免生成偏离要求的视频")
            timeline = semantic_timeline(seconds, plan["scenes"], self.fps)
            for index, scene in enumerate(plan["scenes"]):
                scene["seconds"] = timeline[index]
                if (self.media["narration"] or self.media["subtitles"]) and narration_units(scene["narration"]) > timeline[index] * 3.2:
                    scene["narration"] = self.rewrite_narration(scene["narration"], timeline[index])
            if self.data.get("source_requirements") and not all(
                    source_plan_quote_present(plan, check)
                    for check in self.data.get("source_requirement_plan_checks", [])):
                raise RuntimeError("修改旁白后来源文档硬性约束丢失，禁止继续生成")
            atomic_json(self.job / "storyboard.json", plan)
            self.models.unload_director()
            self.publish_event("storyboard", title=plan["title"], scenes=[
                {"narration": scene["narration"], "seconds": scene["seconds"]}
                for scene in plan["scenes"]])
            self.publish_event("phase", phase="rendering")
            self.step("分镜结构已检查，开始生成素材", 20)
            clips, voice, real_seconds, assets = self.compose_clips(plan)
            lengths = [read_json(self.job / ("scene_%02d.json" % i), {}).get("duration", seconds / scenes)
                       for i in range(len(plan["scenes"]))]
            self.ambient_audio = self.build_original_audio(lengths)
            self.publish_event("phase", phase="finishing")
            self.step("剪辑：统一帧率、镜头尺寸与过渡", 83)
            joined = self.job / "edited_no_audio.mp4"
            self.concat_clips(clips, joined)
            self.step("混音并完整检查成片", 90)
            output = self.result_dir / "final.mp4"
            temp_output = self.job / "final_first_pass.mp4"
            seed = int(hashlib.sha256(self.request["prompt"].encode("utf-8")).hexdigest()[:8], 16)
            mix_profile = {"voice_gain": 1.1, "background_gain": .17, "ambient_gain": None}
            def render_mix(video, destination):
                self.combine_audio(video, voice, real_seconds, plan.get("mood", "inspiring"),
                                   seed, destination, **mix_profile)
            render_mix(joined, temp_output)
            self.enforce_video_boundaries(temp_output, real_seconds)
            verdict = self.check_final(temp_output, real_seconds, lengths)
            reviews = [verdict]
            current_candidate = temp_output
            repair_budget = min(MAX_AUTO_REPAIR_PASSES, max(
                MAX_REPAIR_PASSES, (len(plan["scenes"]) + 2) // 3 + 2))
            repeated_failure = 0
            for attempt in range(repair_budget):
                if verdict["passed"]:
                    break
                self.step("成片检查未通过，按失败原因修复并复检", 94 + attempt * 2)
                self.log("成片检查失败：" + verdict.get("failure", "未知原因"))
                modified = self.job / ("final_repair_%d.mp4" % attempt)
                failure_code = verdict.get("failure_code", "UNKNOWN")
                action = repair_action_for(failure_code)
                repair_record = {"at": now_stamp(), "failure_code": failure_code,
                                 "cause": verdict.get("failure", ""), "action": action,
                                 "round": attempt + 1,
                                 "before_metrics": {key: value for key, value in verdict.items()
                                                    if key not in {"semantic_reviews", "temporal_reviews"}}}
                self.data.setdefault("repairs", []).append(repair_record)
                if action in {"stop_unknown_failure", "stop_unverifiable_constraint"}:
                    self.log("该失败原因缺少可信的自动验证或修复路径，已保存证据并停止，避免假装审校通过")
                    repair_record["no_progress"] = True
                    break
                if action == "replan_scene_and_rerender":
                    missing = missing_plan_quantities(plan, self.request["prompt"])
                    if not missing:
                        raise RuntimeError("数量分镜复检状态不一致，停止避免无根据地修改已验收分镜")
                    targets = self.repair_plan(plan, missing[0], verdict.get("scene"))
                    self.models.unload_director()
                    clips, voice, real_seconds, assets = self.compose_clips(
                        plan, force_scenes=targets, repair_round=attempt + 1)
                    lengths = [read_json(self.job / ("scene_%02d.json" % i), {}).get("duration", seconds / scenes)
                               for i in range(len(plan["scenes"]))]
                    self.ambient_audio = self.build_original_audio(lengths)
                    self.concat_clips(clips, joined)
                    render_mix(joined, modified)
                elif action == "restart_reviewer_and_recheck":
                    self.log("审核组件暂不可用：只恢复审核器并复检，保留已生成的画面和声音")
                    if failure_code == "SEMANTIC_REVIEW_UNAVAILABLE":
                        self.models.unload_inspector()
                        self.models.inspector_failed = False
                    elif failure_code == "SPEECH_REVIEW_UNAVAILABLE":
                        self.models.listener = None
                        self.models.listener_processor = None
                    else:
                        self.log("重新提取连续视频帧并复核，不重新生成已合格的画面")
                    gc.collect()
                    self.resources.adaptive_pause("review_recovery", notify=self.log)
                    modified = current_candidate
                elif failure_code == "CAPTION_TIMELINE_MISSING":
                    self.log("仅重建全部字幕与语音的校验记录，不重新生成画面")
                    voices = [read_json(self.job / ("scene_%02d.json" % i), {})["voice"]
                              for i in range(len(plan["scenes"]))]
                    self.write_subtitle_timeline(plan["scenes"], lengths, voices)
                    modified = current_candidate
                elif failure_code in {"MIXED_VOICE_MISSING", "MIXED_SPEECH_MISMATCH",
                                      "MIXED_AUDIO_EXTRACTION_FAILED", "SPEECH_REVIEW_INCONCLUSIVE"}:
                    self.log("成片实际音轨未通过复检，增强旁白并降低背景与素材原声后重新混音")
                    mix_profile.update({"voice_gain": min(1.8, 1.4 + attempt * .12),
                                        "background_gain": .06 if attempt == 0 else .015,
                                        "ambient_gain": .05 if attempt == 0 else 0})
                    render_mix(joined, modified)
                elif "scene" in verdict:
                    if (failure_code in {"HARD_QUANTITY_MISMATCH", "EXACT_TEXT_UNVERIFIED"} and
                            verdict.get("scene") is not None and
                            not (verdict["scene"] == 0 and self.request["files"].get("首帧")) and
                            not (verdict["scene"] == len(plan["scenes"]) - 1 and
                                 self.request["files"].get("尾帧")) and
                            not re.search(r"必须使用|必须保留|只能使用|严格使用|use only the supplied|must use the supplied",
                                          self.request["prompt"], re.I)):
                        self.force_generated_scenes.add(verdict["scene"])
                    if action == "replace_optional_supplied_visual":
                        if ((verdict["scene"] == 0 and self.request["files"].get("首帧")) or
                                (verdict["scene"] == len(plan["scenes"]) - 1 and
                                 self.request["files"].get("尾帧")) or
                                re.search(r"必须使用|必须保留|只能使用|严格使用|use only the supplied|must use the supplied",
                                          self.request["prompt"], re.I)):
                            atomic_json(self.job / "final_reviews.json", reviews)
                            self.data["final_review"] = verdict
                            atomic_json(self.job / "job.json", self.data)
                            raise RuntimeError("用户明确指定的素材与分镜语义冲突，无法擅自替换；请检查原始要求与素材")
                        self.force_generated_scenes.add(verdict["scene"])
                        self.warn("第 %d 幕参考素材与需求冲突，尝试重新生成而不修改原文件" %
                                  (verdict["scene"] + 1))
                    preserve = ({verdict["scene"]} if action == "reencode_caption_keep_visual" or (
                        action == "repair_motion" and not self.request.get("visual_mode", "").startswith("原生AI视频"))
                        else set())
                    if action == "repair_motion":
                        if self.request.get("visual_mode", "").startswith("原生AI视频"):
                            self.log("原生画面存在运动问题，重新执行时序扩散生成和动作复检")
                        else:
                            self.motion_safe_scenes.add(verdict["scene"])
                    action = "重新排版/编码字幕，复用合格画面" if preserve else "重新生成或编码有缺陷的画面"
                    self.log("定向修复第 %d 幕：%s" % (verdict["scene"] + 1, action))
                    clips, voice, real_seconds, assets = self.compose_clips(
                        plan, force_scenes={verdict["scene"]}, repair_round=attempt + 1,
                        preserve_visual=preserve)
                    lengths = [read_json(self.job / ("scene_%02d.json" % i), {}).get("duration", seconds / scenes)
                               for i in range(len(plan["scenes"]))]
                    self.ambient_audio = self.build_original_audio(lengths)
                    self.concat_clips(clips, joined)
                    render_mix(joined, modified)
                elif failure_code in {"AUDIO_LOW", "AUDIO_SCAN_FAILED", "OUTPUT_MISSING"}:
                    self.log("音频或封装异常，优先重新混音，不重复生成镜头")
                    mix_profile.update({"voice_gain": min(1.8, 1.35 + attempt * .15),
                                        "background_gain": min(mix_profile["background_gain"], .10)})
                    render_mix(joined, modified)
                elif action == "rebuild_edit_and_container":
                    self.log("重新剪辑全部片段并重建视频容器，不改变已通过的生成画面")
                    self.concat_clips(clips, joined)
                    render_mix(joined, modified)
                else:
                    normalized = self.job / ("edited_repair_%d.mp4" % attempt)
                    filters = "fps=%d,setpts=N/(%d*TB)" % (self.fps, self.fps)
                    run_external([self.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(joined),
                                  "-vf", filters, "-frames:v", str(round(real_seconds * self.fps)),
                                  "-c:v", "libx264", "-preset", "veryfast", "-crf", "25",
                                  "-pix_fmt", "yuv420p", "-an", str(normalized)],
                                 self.root, log=self.log, cancel=self.cancel, timeout=480, capture=True)
                    render_mix(normalized, modified)
                self.enforce_video_boundaries(modified, real_seconds)
                verdict = self.check_final(modified, real_seconds, lengths)
                if (action == "restart_reviewer_and_recheck" and not verdict.get("passed") and
                        verdict.get("failure_code") == failure_code and
                        verdict.get("speech_reviews") == reviews[-1].get("speech_reviews") and
                        verdict.get("review_coverage") == reviews[-1].get("review_coverage")):
                    self.log("同一审核输入及结果未发生改变，停止无效重复复检")
                    repair_record["no_progress"] = True
                repair_record["after_metrics"] = {key: value for key, value in verdict.items()
                                                   if key not in {"semantic_reviews", "temporal_reviews"}}
                repair_record["verified"] = bool(verdict.get("passed"))
                atomic_json(self.job / "job.json", self.data)
                reviews.append(verdict)
                current_candidate = modified
                repeated_failure = (repeated_failure + 1 if
                                    (verdict.get("failure_code"), verdict.get("scene")) ==
                                    (failure_code, reviews[-2].get("scene")) else 0)
                if verdict["passed"]:
                    temp_output = modified
                elif repair_record.get("no_progress") or repeated_failure >= MAX_REPAIR_PASSES:
                    repair_record["no_progress"] = True
                    self.log("连续修复后仍是同类失败，停止消耗资源并保留全部证据")
                    break
            atomic_json(self.job / "final_reviews.json", reviews)
            self.data["final_review"] = verdict
            atomic_json(self.job / "job.json", self.data)
            if not verdict["passed"]:
                raise RuntimeError("成片复检仍未通过：%s。可点击黑匣子导出诊断" % verdict.get("failure", "未知原因"))
            tmp_output = output.with_name(output.name + "." + secrets.token_hex(5) + ".partial.mp4")
            try:
                shutil.copy2(temp_output, tmp_output)
                os.replace(tmp_output, output)
            finally:
                tmp_output.unlink(missing_ok=True)
            shutil.copy2(self.job / "storyboard.json", self.result_dir / "storyboard.json")
            subtitles = self.job / "subtitle_timeline.json"
            if subtitles.is_file():
                shutil.copy2(subtitles, self.result_dir / "subtitle_timeline.json")
            screenshot = self.job / "final_preview.png"
            if screenshot.exists():
                shutil.copy2(screenshot, self.result_dir / "cover.png")
            strategy_counts = {method: sum(item.get("render_method") == method for item in assets)
                               for method in ("native_temporal_diffusion", "supplied_video_edit",
                                              "generated_still_camera_motion", "supplied_still_camera_motion")}
            self.data.update({"status": "完成", "finished": datetime.datetime.now().isoformat(),
                              "render_strategy_counts": strategy_counts,
                              "render_modes": [item.get("type", "unknown") for item in assets],
                              "render_methods": [item.get("render_method", "unknown") for item in assets],
                              "render_method_note": "原生时序扩散模型生成的是连续动态帧；静态运镜是另一种独立的非原生模式",
                              "resource_report": self.resources.report(),
                              "output": str(output), "duration": round(real_seconds, 2),
                              "resolution": list(self.size), "scene_count": len(plan["scenes"]),
                              "assets": assets, "final_review": verdict,
                              "semantic_review_coverage": {"reviewed_samples": len(verdict.get("semantic_reviews", [])),
                                                           "unreviewed_samples": len(verdict.get("semantic_unreviewed", []))}})
            atomic_json(self.job / "job.json", self.data)
            atomic_json(self.result_dir / "manifest.json", self.data)
            self.publish_event("phase", phase="complete")
            completion = "成片已保存，多模态启发式复检通过；请查看交付报告"
            self.step(completion, 100)
            return output
        except Exception as error:
            self.data["status"] = "已停止" if isinstance(error, InterruptedError) else "失败"
            self.data["error"] = traceback.format_exc()
            self.data["error_code"] = ("RESOURCE_EXHAUSTED" if self.resources.resource_stop_reason else
                                       "USER_STOP" if isinstance(error, InterruptedError) else
                                       "RESOURCE_EXHAUSTED" if is_memory_error(error) else
                                       "INPUT_UNAVAILABLE" if isinstance(error, (OSError, FileNotFoundError)) else
                                       "PIPELINE_ERROR")
            self.data["resource_report"] = self.resources.report()
            atomic_json(self.job / "job.json", self.data)
            raise
        finally:
            self.resources.stop_monitor()
            if self.piper_worker is not None:
                self.piper_worker.close()
                self.piper_worker = None
            if self.models:
                self.models.close()


def preview_thumbnail_path(root, source, width, height):
    source = Path(source)
    stat = source.stat()
    identity = "%s|%d|%d|%d|%d" % (
        str(source.resolve()), stat.st_mtime_ns, stat.st_size, int(width), int(height))
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
    return Path(root) / ".studio" / "tmp" / "previews" / ("preview_" + digest + ".png")


def prepare_preview_thumbnail(root, source, destination, width, height):
    from PIL import Image, ImageOps
    source = Path(source)
    destination = Path(destination)
    workspace = Path(root).resolve()
    if workspace not in destination.resolve().parents:
        raise RuntimeError("预览缓存必须保存在选定的工作目录内")
    width = max(1, min(2048, int(width)))
    height = max(1, min(2048, int(height)))
    if not source.is_file() or source.is_symlink():
        raise RuntimeError("预览图像来源无效")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + "." + secrets.token_hex(4) + ".partial")
    try:
        with Image.open(source) as bitmap:
            if bitmap.width * bitmap.height > MAX_DOCX_EMBEDDED_IMAGE_PIXELS:
                bitmap.draft("RGB", (width * 2, height * 2))
            if bitmap.width * bitmap.height > MAX_DOCX_EMBEDDED_IMAGE_PIXELS:
                raise RuntimeError("预览源图超出安全解码像素限制")
            preview = ImageOps.exif_transpose(bitmap).convert("RGB")
            preview.thumbnail((width, height), Image.Resampling.LANCZOS)
            if min(preview.size) < 1:
                raise RuntimeError("预览图像尺寸异常")
            preview.save(temporary, format="PNG")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


def prune_preview_cache(root):
    folder = Path(root) / ".studio" / "tmp" / "previews"
    if not folder.is_dir():
        return {"files": 0, "bytes": 0}
    now = time.time()
    candidates = []
    for item in folder.glob("preview_*.png"):
        try:
            if item.is_file() and not item.is_symlink():
                candidates.append((item.stat().st_mtime, item))
        except OSError:
            continue
    candidates = [item for _, item in sorted(candidates, key=lambda pair: pair[0], reverse=True)]
    removed = bytes_freed = 0
    for index, file in enumerate(candidates):
        try:
            if index >= UI_PREVIEW_CACHE_LIMIT or now - file.stat().st_mtime > UI_PREVIEW_CACHE_AGE_SECONDS:
                size = file.stat().st_size
                file.unlink()
                removed += 1
                bytes_freed += size
        except OSError:
            continue
    return {"files": removed, "bytes": bytes_freed}


def offline_readiness_label(flags):
    flags = flags if isinstance(flags, dict) else {}
    if flags.get("full_offline"):
        if flags.get("native_video"):
            return "● 离线创作就绪 · 原生视频可用"
        if flags.get("native_inference_verified"):
            return "● 离线创作就绪 · 原生视频显存繁忙"
        if flags.get("native_model_detected"):
            return "● 离线创作就绪 · 原生视频待实测"
        if flags.get("native_model_present"):
            return "● 离线创作就绪 · 原生模型待校验"
        return "● 离线创作就绪 · 原生模型待准备"
    if flags.get("basic"):
        return "● 基础依赖就绪 · 离线创作仍需验收"
    return "● 正在准备离线创作环境"


def preferred_desktop():
    if os.name == "nt":
        try:
            buffer = ctypes.create_unicode_buffer(4096)
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buffer) == 0:
                location = Path(buffer.value)
                if location.exists():
                    return location
        except (OSError, AttributeError):
            pass
    candidates = [Path.home() / "Desktop", Path.home() / "OneDrive" / "Desktop"]
    candidates.extend(Path.home().glob("OneDrive*/Desktop"))
    valid = next((item for item in candidates if item.is_dir()), None)
    if valid is None:
        raise RuntimeError("无法确定系统桌面的实际位置，黑匣子未保存到其他目录；请检查桌面文件夹")
    return valid


def cleanup_completed_cache(root, cancel=None):
    root = Path(root)
    cancel = cancel or threading.Event()
    patterns = ("candidate_*.png", "native_review_*.png", "native_seam_*.png",
                "native_*_part_*.mp4", "native_*_parts.txt",
                "asset_match_*.png", "temporal_*.png", "final_check_*.png",
                "source_audio_*.wav", "mix_review_*.wav", "audio_*.wav")
    totals = {"jobs": 0, "files": 0, "bytes": 0}
    jobs = root / ".studio" / "jobs"
    if jobs.is_dir():
        for folder in jobs.iterdir():
            if cancel.is_set():
                raise InterruptedError("清理已取消")
            if not folder.is_dir() or folder.is_symlink():
                continue
            metadata = read_json(folder / "job.json", {})
            output = metadata.get("output") if isinstance(metadata, dict) else None
            if metadata.get("status") != "完成" or not output or not Path(output).is_file():
                continue
            totals["jobs"] += 1
            for pattern in patterns:
                for file in folder.glob(pattern):
                    if cancel.is_set():
                        raise InterruptedError("清理已取消")
                    if file.is_file() and not file.is_symlink():
                        try:
                            size = file.stat().st_size
                            file.unlink()
                            totals["files"] += 1
                            totals["bytes"] += size
                        except OSError:
                            continue
    temporary = root / ".studio" / "tmp"
    if temporary.is_dir():
        older_than = time.time() - 72 * 3600
        for file in temporary.iterdir():
            if cancel.is_set():
                raise InterruptedError("清理已取消")
            if (file.is_file() and not file.is_symlink() and
                    file.suffix.lower() in {".partial", ".json", ".txt", ".signal"}
                    and file.stat().st_mtime < older_than):
                try:
                    size = file.stat().st_size
                    file.unlink()
                    totals["files"] += 1
                    totals["bytes"] += size
                except OSError:
                    continue
    preview = prune_preview_cache(root)
    totals["files"] += preview["files"]
    totals["bytes"] += preview["bytes"]
    return totals


def system_report(root, request=None):
    root = Path(root)
    drive = shutil.disk_usage(root)
    report = {
        "app": APP_NAME, "version": APP_VERSION, "time": datetime.datetime.now().isoformat(),
        "os": platform.platform(), "architecture": platform.machine(), "python": sys.version,
        "python_executable": sys.executable, "locale": locale.getlocale(), "cwd": str(Path.cwd()),
        "workspace": str(root), "disk": {"total": drive.total, "used": drive.used, "free": drive.free},
        "memory": memory_info(), "gpu": gpu_info(), "cpu_count": os.cpu_count(),
        "network_cost": windows_network_cost() if os.name == "nt" else {},
        "basic_ready": basic_ready(root), "full_ready": is_ready(root),
        "capabilities": capability_report(root, request),
        "model_provenance": model_provenance(root),
        "installed_packages": {tier: packages_healthy(root, tier)
                               for tier in ("basic", "full")},
        "native_video": {"local_model_detected": bool(native_video_model(root)),
                         "load_verified": native_load_ready(root),
                         "verification": read_json(root / ".studio" / "native_ready.json", {}),
                         "model_class": native_video_model(root)[1] if native_video_model(root) else None},
        "optional_models": {role: {"verified": optional_model_verified(model_path(root, folder), role),
                                   "download": read_json(model_path(root, folder) / "download.json", {})}
                            for role, folder in OPTIONAL_MODEL_FOLDERS.items()},
        "environment": {key: os.environ.get(key) for key in (
            "HF_HOME", "HF_ENDPOINT", "TORCH_HOME", "PIP_INDEX_URL", "PYTHONUTF8", "HF_HUB_OFFLINE")},
        "ready_marker": read_json(root / ".studio" / "ready.json", {}),
        "request": request or {},
        "packages": [], "models": [],
        "voice_model": {"repo": VOICE_REPO, "file": str(voice_model_path(root)),
                        "complete": voice_download_complete(root),
                        "download": read_json(model_path(root, "voice") / "download.json", {})},
    }
    site = runtime_site(root)
    try:
        for dist in importlib.metadata.distributions(path=[str(site)]):
            report["packages"].append({"name": dist.metadata.get("Name"), "version": dist.version})
    except Exception as error:
        report["package_error"] = str(error)
    for name, repo, folder, patterns in MODEL_SPECS:
        path = model_path(root, folder)
        weights = []
        for file in path.rglob("*"):
            try:
                if file.is_file() and file.suffix in {".bin", ".safetensors"}:
                    weights.append((str(file.relative_to(path)), file.stat().st_size))
            except OSError:
                continue
        report["models"].append({"name": name, "repo": repo, "folder": str(path), "weights": weights,
                                  "complete": model_download_complete(root, (name, repo, folder, patterns)),
                                 "download": read_json(path / "download.json", {})})
    return report


def diagnostic_exception_summary(value):
    raw = str(value)
    exceptions = re.findall(r"\b([A-Za-z][A-Za-z0-9_]*(?:Error|Exception))\s*:", raw)
    calls = re.findall(r'^\s*File "[^"]+", line (\d+), in ([A-Za-z_][A-Za-z0-9_]*)', raw, re.M)
    wins = re.findall(r"\bWinError\s+(\d+)\b", raw)
    missing = re.findall(r"No module named ['\"]([A-Za-z_][A-Za-z0-9_.]*)['\"]", raw)
    codes = re.findall(r"\b(?:OUTPUT_MISSING|DECODE_FAILURE|DURATION_MISMATCH|DURATION_UNREADABLE|"
                       r"SCENE_FRAME_INVALID|AUDIO_LOW|AUDIO_SCAN_FAILED|FINAL_SEMANTIC_MISMATCH|"
                       r"SEMANTIC_REVIEW_UNAVAILABLE|CAPTION_TIMELINE_MISSING|CAPTION_TIMELINE_MISMATCH|"
                       r"SPEECH_MISMATCH|SPEECH_SOURCE_MISMATCH|SPEECH_SOURCE_MISSING|"
                       r"MIXED_VOICE_MISSING|MIXED_SPEECH_MISMATCH|SPEECH_REVIEW_UNAVAILABLE|SPEECH_REVIEW_INCONCLUSIVE|"
                       r"MIXED_AUDIO_EXTRACTION_FAILED|TEMPORAL_FLICKER|TEMPORAL_REVIEW_UNAVAILABLE|RESOURCE_EXHAUSTED|"
                       r"INPUT_UNAVAILABLE|PIPELINE_ERROR|USER_STOP)\b", raw)
    return {"exception_type": exceptions[-1] if exceptions else "UnclassifiedError",
            "call_sites": [{"line": int(line), "function": function} for line, function in calls[-8:]],
            "windows_error": int(wins[-1]) if wins else None,
            "failure_code": codes[-1] if codes else None,
            "missing_module": missing[-1] if missing else None,
            "length": len(raw)}


def redact_diagnostic(value, name=""):
    key = name.lower()
    if key in {"source", "mixed"} and isinstance(value, dict) and (
            "score" in value or "status" in value or "expected_length" in value):
        allowed = ("status", "score", "expected_length", "observed_length",
                   "voice_correlation", "source_rms", "mixed_rms", "method")
        return {entry: redact_diagnostic(value[entry], entry) for entry in allowed if entry in value}
    secret_keys = {"prompt", "narration", "visual_prompt", "url", "text", "path", "file",
                   "source", "workspace", "cwd", "python_executable", "output", "result_dir",
                   "last_job", "clip", "voice", "rendered", "overlay", "tokenizer_path",
                   "error", "failure", "warning", "warnings", "exception", "message", "step"}
    if key in secret_keys:
        if key in {"error", "failure", "exception"} and isinstance(value, str):
            return diagnostic_exception_summary(value)
        if key == "warnings" and isinstance(value, list):
            return {"count": len(value)}
        if key == "step" and isinstance(value, str):
            return {"stage_hash": hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]}
        return "[已隐藏]"
    if isinstance(value, dict):
        if name == "gpu":
            card = str(value.get("name", ""))
            driver = str(value.get("driver", ""))
            return {"name": card if len(card) <= 120 and re.fullmatch(r"[A-Za-z0-9_.+() -]*", card) else "[已隐藏]",
                    "driver": driver if re.fullmatch(r"[0-9.]{0,20}", driver) else "[已隐藏]",
                    "free_mb": value.get("free_mb", 0), "total_mb": value.get("total_mb", 0)}
        if name == "request":
            files = value.get("files", {})
            return {"duration": value.get("duration"), "quality": value.get("quality"),
                    "aspect": value.get("aspect"), "audio_role": value.get("audio_role"),
                    "source_audio_role": value.get("source_audio_role"),
                    "prompt_length": len(str(value.get("prompt", ""))),
                    "files_count": {kind: len(paths) for kind, paths in files.items()
                                    if kind in {"首帧", "尾帧", "图片", "音频", "视频", "文档"}}
                    if isinstance(files, dict) else {},
                    "asset_categories": sorted(k for k, v in files.items() if v and k in {"图片", "首帧", "尾帧", "音频", "视频", "文档"})}
        cleaned = {}
        for index, (field, item) in enumerate(value.items()):
            field = str(field)
            safe_key = field if re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", field) or field in {
                "首帧", "尾帧", "图片", "音频", "视频", "文档"} else "field_%04d" % index
            cleaned[safe_key] = redact_diagnostic(item, field)
        return cleaned
    if isinstance(value, (list, tuple)):
        return [redact_diagnostic(item, name) for item in value]
    if isinstance(value, str):
        if key in {"exception_type", "failure_code", "missing_module", "smoke_error_type", "smoke_error_code"}:
            return value if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,80}", value) else "[已隐藏]"
        if key in {"name", "repo", "folder_name"}:
            if value == APP_NAME or value in {item[0] for item in MODEL_SPECS}:
                return value
            if re.fullmatch(r"[a-zA-Z0-9_.+/-]{1,100}", value):
                return value
        if key in {"status", "voice_backend", "quality", "aspect", "audio_role", "source_audio_role", "type", "category"}:
            permitted = {"运行中", "已停止", "完成", "失败", "sapi", "piper", "快速", "智能", "精细",
                         "横屏 16:9", "竖屏 9:16", "方形 1:1", "仅作参考", "作为背景音乐",
                         "自动混合原声", "原声优先", "静音原声",
                         "status", "image", "video", "passed", "ERROR", "INSTALL", "DOWNLOAD", "REVIEW", "RENDER", "STATUS",
                         "network", "resources", "verification", "runtime", "external_process", "repair",
                         "matched", "empty_expected", "needs_manual_check", "not_confident",
                         "suspected_mismatch", "reviewed", "missing_voice", "mix_voice_missing",
                         "recognition_unavailable", "mix_extract_failed", "downloaded", "inference_failed",
                         "motion_insufficient", "model_verified", "no_change", "remix_audio"}
            return value if value in permitted else "[已隐藏]"
        if key in {"version", "runtime_version", "revision", "sha256", "source_sha256", "model_signature",
                   "request_digest", "python", "torch", "diffusers", "transformers", "pillow",
                   "completed", "started", "finished", "checked", "at", "time", "mtime"}:
            return value if len(value) <= 120 and re.fullmatch(r"[A-Za-z0-9_.:+\s-]+", value) else "[已隐藏]"
        if key in {"os", "architecture"}:
            return value if len(value) <= 120 and re.fullmatch(r"[A-Za-z0-9_.+() -]+", value) else "[已隐藏]"
        if key == "app" and value == APP_NAME:
            return value
        return "[已隐藏]"
    return value


def diagnostic_log_events(lines):
    events = []
    for item in lines[-1200:]:
        stamp = re.match(r"^\[(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?)\]", item)
        if not stamp:
            continue
        has_error = any(term in item for term in ("失败", "异常", "Error", "Exception", "超时", "不足"))
        category = ("ERROR" if has_error else "INSTALL" if "安装" in item else
                    "DOWNLOAD" if "下载" in item else "REVIEW" if "审校" in item or "检查" in item else
                    "RENDER" if "镜头" in item or "编码" in item else "STATUS")
        if category == "STATUS":
            continue
        record = {"at": stamp.group(1), "category": category}
        match = re.search(r"\b([A-Za-z][A-Za-z0-9_]*(?:Error|Exception))\s*:", item)
        if match:
            record["exception_type"] = match.group(1)[:80]
        match = re.search(r"退出码\s*(\d+)", item)
        if match:
            record["exit_code"] = int(match.group(1))
        events.append(record)
    return events[-250:]


def diagnostic_failure_history(lines, job, process_events):
    history = []
    for item in lines[-5000:]:
        if not any(term in item for term in ("失败", "异常", "Error", "Exception", "超时", "不足", "无法")):
            continue
        stamp = re.match(r"^\[(\d{4}-\d\d-\d\dT[^]]+)\]", item)
        raw = item[stamp.end():] if stamp else item
        details = diagnostic_exception_summary(raw)
        category = "network" if any(term in raw for term in ("HTTP", "网络", "连接", "下载", "镜像")) else (
                   "resources" if any(term in raw for term in ("内存", "显存", "磁盘", "不足")) else (
                   "verification" if any(term in raw for term in ("校验", "验收", "审校", "SHA")) else "runtime"))
        history.append({"at": stamp.group(1) if stamp else None,
                        "category": category,
                        "exception_type": details["exception_type"],
                        "failure_code": details["failure_code"],
                        "windows_error": details["windows_error"],
                        "call_sites": details["call_sites"],
                        "message_fingerprint": hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]})
    for event in process_events[-200:]:
        if event.get("returncode") not in (None, 0):
            history.append({"at": event.get("at"), "category": "external_process",
                            "exit_code": event.get("returncode")})
    for attempt in job.get("repairs", [])[-100:]:
        if isinstance(attempt, dict):
            history.append({"at": attempt.get("at"), "category": "repair",
                            "failure_code": attempt.get("failure_code"),
                            "round": attempt.get("round")})
    return history[-500:]


def export_black_box(root, request, last_job, notifier, include_private=False):
    root = Path(root)
    desktop = preferred_desktop()
    name = "AI工坊黑匣子_" + now_stamp() + ".zip"
    destination = desktop / name
    temporary = root / ".studio" / "tmp" / (name + ".partial")
    temporary.parent.mkdir(parents=True, exist_ok=True)
    desktop_partial = destination.with_suffix(".partial")
    inventory = []
    omitted = []
    selected = set()
    parts = []
    started = time.monotonic()
    def add_file(path, target=None):
        path = Path(path)
        if not path.is_file() or path.is_symlink():
            return
        target = target or "evidence/" + path.name
        if target in selected:
            return
        if path.stat().st_size > 32 * 1024 * 1024:
            omitted.append({"target": target if include_private else path.suffix.lower(),
                            "reason": "per_file_limit", "bytes": path.stat().st_size})
            return
        selected.add(target)
        parts.append((path, target))
    app_log = root / ".studio" / "logs" / "studio.log"
    if include_private:
        add_file(app_log, "logs/studio.log")
    script = Path(__file__).resolve()
    if include_private:
        add_file(script, "source/" + script.name)
    jobpath = Path(last_job) if last_job else None
    if jobpath is None or not jobpath.is_dir():
        jobs = root / ".studio" / "jobs"
        if jobs.is_dir():
            candidates = sorted(jobs.glob("*/job.json"), key=lambda item: item.stat().st_mtime, reverse=True)
            jobpath = candidates[0].parent if candidates else None
    if jobpath and jobpath.exists():
        for file in jobpath.rglob("*"):
            if time.monotonic() - started > 12:
                break
            allowed = ({".json", ".txt", ".log", ".ps1", ".png", ".jpg", ".wav", ".mp4"}
                       if include_private else {".json"})
            recognized_json = (file.parent == jobpath and file.suffix.lower() == ".json" and
                               file.stat().st_size <= 32 * 1024 * 1024)
            if (file.is_file() and file.suffix.lower() in allowed
                    and (include_private or recognized_json)):
                add_file(file, "last_job/" + file.relative_to(jobpath).as_posix())
    result_folder = root / "成品"
    if result_folder.exists():
        recent = sorted((item for item in result_folder.iterdir() if item.is_dir()), reverse=True)[:2]
        for folder_number, folder in enumerate(recent, 1):
            for file in folder.iterdir():
                if (file.suffix.lower() in ({".json", ".png", ".mp4"} if include_private else {".json"})
                        and (include_private or file.name in {"manifest.json", "storyboard.json"})):
                    safe_name = folder.name if include_private else "result_%d" % folder_number
                    add_file(file, "results/" + safe_name + "/" + file.name)
    hashed = 0
    count = 0
    for path in (root / ".studio").rglob("*"):
        if time.monotonic() - started > 20:
            inventory.append({"warning": "清单扫描已到时间上限，文件列表为快照"})
            break
        if not path.is_file() or path.is_symlink():
            continue
        count += 1
        if count > 75000:
            inventory.append({"warning": "仅列出前 75000 个文件"})
            break
        try:
            stat = path.stat()
            detail = {"path": path.relative_to(root).as_posix() if include_private else
                      "file_%d%s" % (count, path.suffix.lower()), "bytes": stat.st_size,
                      "mtime": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat()}
            if stat.st_size < 256 * 1024 and hashed < 24 * 1024 * 1024:
                detail["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
                hashed += stat.st_size
            inventory.append(detail)
        except OSError as error:
            inventory.append({"file_index": count, "error": str(error) if include_private else type(error).__name__})
    diagnostic = system_report(root, request)
    diagnostic["last_job"] = str(last_job) if last_job else None
    diagnostic["inventory_count"] = len(inventory)
    diagnostic["snapshot_running"] = bool(jobpath and read_json(jobpath / "job.json", {}).get("status") == "运行中")
    if jobpath and jobpath.is_dir():
        checkpoints = sorted(jobpath.glob("scene_*.json"))
        completed = sum(read_json(item, {}).get("passed") is True for item in checkpoints)
        diagnostic["last_job_checkpoints"] = {"count": len(checkpoints), "passed": completed,
                                               "final_reviews": len(read_json(jobpath / "final_reviews.json", []))}
    diagnostic["source_sha256"] = hashlib.sha256(script.read_bytes()).hexdigest()
    with RUNNING_CHILDREN_LOCK:
        active = [proc for proc in RUNNING_CHILDREN if proc.poll() is None]
    diagnostic["child_processes"] = {"count": len(active),
                                      "pids": [proc.pid for proc in active] if include_private else []}
    log_events = []
    recent_lines = []
    if app_log.is_file():
        try:
            with app_log.open("r", encoding="utf-8", errors="replace") as stream:
                recent = deque(stream, maxlen=5000)
            recent_lines = list(recent)
            log_events = diagnostic_log_events(recent_lines)
            diagnostic["log_statistics"] = {"recent_lines": len(recent),
                                            "error_mentions": sum("失败" in line or "Error" in line for line in recent),
                                             "stop_mentions": sum("已停止" in line for line in recent),
                                             "structured_events": len(log_events)}
        except OSError:
            diagnostic["log_statistics"] = {"readable": False}
    stages = []
    latest = read_json(jobpath / "job.json", {}) if jobpath else {}
    for record in latest.get("events", []):
        if not isinstance(record, dict):
            continue
        stages.append({"percent": record.get("percent"),
                       "elapsed_seconds": record.get("elapsed_seconds"),
                       "ram_available": record.get("ram_available"),
                       "gpu_free": record.get("gpu_free"),
                       "disk_free": record.get("disk_free")})
    diagnostic["error_code"] = latest.get("error_code")
    diagnostic["latest_exception"] = diagnostic_exception_summary(latest["error"]) if isinstance(
        latest.get("error"), str) else None
    diagnostic["failed_stage"] = next(({"percent": item.get("percent"),
                                        "stage": redact_diagnostic(item.get("step"), "step"),
                                        "elapsed_seconds": item.get("elapsed_seconds")}
                                       for item in reversed(latest.get("events", [])) if isinstance(item, dict)), None)
    diagnostic["final_review_failure"] = {key: value for key, value in latest.get("final_review", {}).items()
                                          if key in {"failure_code", "scene", "passed", "review_level",
                                                     "technical_pass", "semantic_pass", "delivery_allowed"}} if isinstance(
                                              latest.get("final_review"), dict) else {}
    diagnostic["native_verification"] = {key: value for key, value in read_json(
        root / ".studio" / "native_ready.json", {}).items()
        if key in {"offline_load", "inference_tested", "decode_tested", "frame_count", "smoke_status",
                   "smoke_error_type", "smoke_error_code", "gpu_index", "gpu_total_mb"}}
    diagnostic["resource_peak"] = latest.get("resource_report", {})
    diagnostic["repair_attempts"] = len(latest.get("repairs", []))
    diagnostic["repair_outcomes"] = latest.get("repairs", [])
    diagnostic["localized_sources"] = latest.get("localized_sources", {})
    diagnostic["source_integrity"] = [{"category": entry.get("category"), "index": entry.get("index"),
        "bytes": entry.get("bytes"), "sample_hash": entry.get("sample_hash"),
        "sha256": entry.get("sha256"), "verified_workspace_copy": verified_local_source(entry, root)}
        for entry in latest.get("source_manifest", []) if isinstance(entry, dict)]
    diagnostic["offline_combined_acceptance"] = read_json(
        root / ".studio" / "ready.json", {}).get("diagnostic", {}).get("offline_pipeline", {})
    diagnostic["storyboard_revisions"] = len(read_json(
        jobpath / "storyboard.json", {}).get("repair_history", [])) if jobpath else 0
    diagnostic["native_review_failures"] = sum(
        len(read_json(item, [])) for item in jobpath.glob("native_attempts_*.json")) if jobpath else 0
    diagnostic["final_audio_review"] = read_json(jobpath / "speech_review.json", []) if jobpath else []
    diagnostic["source_analysis"] = latest.get("source_analysis", [])
    diagnostic["source_chunk_index"] = latest.get("source_chunk_index", [])
    diagnostic["source_coverage"] = latest.get("reference_coverage", {})
    diagnostic["skipped_or_failed_sources"] = [entry for entry in latest.get("source_analysis", [])
        if isinstance(entry, dict) and entry.get("status") in
        {"failed", "partial", "no_text", "limit_reached", "unreadable"}]
    diagnostic["review_summary"] = latest.get("review_summary", {})
    diagnostic["selected_models"] = latest.get("selected_models", {})
    audit_file = root / ".studio" / "logs" / "process_events.jsonl"
    processes = []
    if audit_file.is_file():
        with audit_file.open("r", encoding="utf-8", errors="replace") as handler:
            for line in deque(handler, maxlen=EXTERNAL_COMMAND_HISTORY):
                try:
                    entry = json.loads(line)
                    if isinstance(entry, dict):
                        processes.append(entry if include_private else redact_diagnostic(entry))
                except ValueError:
                    continue
    checkpoint_summary = []
    if jobpath and jobpath.is_dir():
        for file in sorted(jobpath.glob("scene_*.json")):
            item = read_json(file, {})
            visual = item.get("image", {})
            checkpoint_summary.append({"scene": len(checkpoint_summary) + 1,
                                       "passed": item.get("passed"),
                                       "clip_exists": bool(item.get("clip") and Path(item["clip"]).is_file()),
                                       "voice_exists": bool(item.get("voice") and Path(item["voice"]).is_file()),
                                       "image_type": visual.get("type"),
                                       "caption_pages": len(visual.get("overlays", [])),
                                       "semantic_passed": visual.get("metrics", {}).get("semantic_passed")
                                       if isinstance(visual.get("metrics"), dict) else None,
                                       "visual_signature_exists": bool(item.get("visual_signature")),
                                       "voice_signature_exists": bool(item.get("voice_signature"))})
    repair_summary = [{"round": item.get("round"), "failure_code": item.get("failure_code"),
                       "at": item.get("at")} for item in latest.get("repairs", []) if isinstance(item, dict)]
    final_audits = read_json(jobpath / "final_reviews.json", []) if jobpath else []
    constraints = []
    for pass_number, record in enumerate(final_audits if isinstance(final_audits, list) else []):
        if isinstance(record, dict):
            constraints.append({"pass": pass_number, "failure_code": record.get("failure_code"),
                "scene": record.get("scene"), "delivery_allowed": record.get("delivery_allowed"),
                "quantity_reviews": record.get("quantity_reviews", []),
                "screen_text_reviews": record.get("screen_text_reviews", []),
                "temporal_reviews": record.get("temporal_reviews", []),
                "semantic_reviews": record.get("semantic_reviews", []),
                "review_coverage": record.get("review_coverage", {})})
    image_attempts = []
    continuity_reviews = []
    if jobpath and jobpath.is_dir():
        for attempt_file in sorted(jobpath.glob("attempts_*.json")):
            records = read_json(attempt_file, [])
            if isinstance(records, list):
                image_attempts.append({"scene": len(image_attempts), "attempt_count": len(records),
                                       "failure_types": [record.get("failure_type") for record in records
                                                         if isinstance(record, dict)]})
        for checkpoint_file in sorted(jobpath.glob("scene_*.json")):
            visual = read_json(checkpoint_file, {}).get("image", {})
            metrics = visual.get("metrics", {}) if isinstance(visual, dict) else {}
            if isinstance(metrics, dict) and isinstance(metrics.get("continuity"), dict):
                continuity_reviews.append({"scene": len(continuity_reviews),
                                            "review": metrics["continuity"]})
    model_progress = []
    for spec in MODEL_SPECS:
        folder = model_path(root, spec[2])
        staging = folder.with_name(folder.name + ".downloading")
        candidate = staging if staging.is_dir() else folder
        if candidate.is_dir():
            count = total = 0
            for file in candidate.rglob("*"):
                try:
                    if file.is_file():
                        count += 1
                        total += file.stat().st_size
                except OSError:
                    continue
            model_progress.append({"model": spec[2], "download_complete": model_download_complete(root, spec),
                                   "saved_file_count": count, "saved_bytes": total})
    if not include_private:
        diagnostic = redact_diagnostic(diagnostic)
    max_total = 140 * 1024 * 1024
    added = 0
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=4, allowZip64=True) as archive:
            archive.writestr("diagnostics/system.json", json.dumps(diagnostic, ensure_ascii=False, indent=2, default=str))
            archive.writestr("diagnostics/file_inventory.json", json.dumps(inventory, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/log_events.json", json.dumps(log_events, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/failure_history.json", json.dumps(
                diagnostic_failure_history(recent_lines, latest, processes), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/native_verification.json", json.dumps(
                diagnostic.get("native_verification", {}), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/latest_exception.json", json.dumps(
                diagnostic.get("latest_exception", {}), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/model_extension.json", json.dumps(
                redact_diagnostic(read_json(root / ".studio" / "native_auto.json", {})),
                ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/process_history.json", json.dumps(processes, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/model_provenance.json", json.dumps(
                model_provenance(root) if include_private else redact_diagnostic(model_provenance(root)),
                ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/stage_metrics.json", json.dumps(stages, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/constraint_audit.json", json.dumps(
                constraints if include_private else redact_diagnostic(constraints),
                ensure_ascii=False, indent=2, default=str))
            archive.writestr("diagnostics/source_processing.json", json.dumps(
                diagnostic.get("skipped_or_failed_sources", []), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/processing_coverage.json", json.dumps(
                {"coverage": diagnostic.get("source_coverage", {}),
                 "chunk_index": diagnostic.get("source_chunk_index", []),
                 "source_analysis": diagnostic.get("source_analysis", [])},
                ensure_ascii=False, indent=2, default=str))
            archive.writestr("diagnostics/verified_model_inventory.json", json.dumps(
                model_progress, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/checkpoint_summary.json", json.dumps(checkpoint_summary, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/repair_summary.json", json.dumps(repair_summary, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/repair_outcomes.json", json.dumps(
                latest.get("repairs", []) if include_private else redact_diagnostic(latest.get("repairs", [])),
                ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/offline_combined_acceptance.json", json.dumps(
                diagnostic.get("offline_combined_acceptance", {}), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/source_integrity.json", json.dumps(
                diagnostic.get("source_integrity", []), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/storyboard_revisions.json", json.dumps(
                read_json(jobpath / "storyboard.json", {}).get("repair_history", []) if include_private
                else redact_diagnostic(read_json(jobpath / "storyboard.json", {}).get("repair_history", []))
                if jobpath else [], ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/runtime_health.json", json.dumps(
                {"interpreter_matches": runtime_matches_host(root),
                 "basic": packages_healthy(root, "basic"), "full": packages_healthy(root, "full"),
                 "power": system_power_state(), "disk_budget": latest.get("disk_budget", {})},
                ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/model_download_progress.json", json.dumps(model_progress, ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/install_transaction.json", json.dumps(redact_diagnostic(
                read_json(root / ".studio" / "install_transaction.json", {})), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/document_coverage.json", json.dumps(redact_diagnostic(
                latest.get("source_analysis", [])), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/image_attempts.json", json.dumps(redact_diagnostic(
                image_attempts), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/continuity_reviews.json", json.dumps(redact_diagnostic(
                continuity_reviews), ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/final_delivery_gate.json", json.dumps(redact_diagnostic(
                (read_json(jobpath / "final_reviews.json", [])[-1].get("review_coverage", {})
                 if jobpath and read_json(jobpath / "final_reviews.json", []) else {})),
                ensure_ascii=False, indent=2))
            archive.writestr("diagnostics/readme.txt", "诊断包模式：%s。分享前请检查压缩包内容。\n" %
                             ("完整模式：可能包含私人提示词、素材及路径" if include_private else
                              "自动脱敏模式：包含修复、音轨、模型校验等摘要，但不包含原始媒体和输入文本"))
            parts.sort(key=lambda item: (item[0].suffix.lower() not in {".json", ".txt"},
                                         item[0].stat().st_size if item[0].exists() else 0))
            for path, entry in parts:
                try:
                    size = path.stat().st_size
                    if added + size > max_total:
                        omitted.append({"target": entry if include_private else Path(entry).suffix.lower(),
                                        "reason": "archive_size_limit", "bytes": size})
                        continue
                    if not include_private and path.suffix.lower() == ".json":
                        value = read_json(path, None)
                        if value is None:
                            omitted.append({"target": Path(entry).suffix.lower(), "reason": "json_unreadable"})
                            continue
                        archive.writestr(entry, json.dumps(redact_diagnostic(value), ensure_ascii=False,
                                                           indent=2, default=str))
                    else:
                        archive.write(path, arcname=entry)
                    added += size
                except OSError as error:
                    omitted.append({"target": entry if include_private else Path(entry).suffix.lower(),
                                    "reason": type(error).__name__})
            archive.writestr("diagnostics/omissions.json", json.dumps(omitted, ensure_ascii=False, indent=2))
        with zipfile.ZipFile(temporary) as validation:
            damaged = validation.testzip()
            if damaged:
                raise RuntimeError("黑匣子压缩包校验失败，损坏条目：" + damaged)
        if shutil.disk_usage(desktop).free < temporary.stat().st_size + 16 * 1024 * 1024:
            raise RuntimeError("桌面磁盘空间不足，无法安全交付黑匣子")
        shutil.copy2(temporary, desktop_partial)
        with zipfile.ZipFile(desktop_partial) as validation:
            if validation.testzip():
                raise RuntimeError("复制到桌面后的黑匣子校验失败")
        os.replace(desktop_partial, destination)
    finally:
        temporary.unlink(missing_ok=True)
        desktop_partial.unlink(missing_ok=True)
    notifier("黑匣子已保存并校验：" + str(destination))
    return destination


def chinese_duration_number(value):
    text = str(value).strip()
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        return float(text)
    digits = {"零": 0, "〇": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    if not text or not re.fullmatch(r"[零〇一二两三四五六七八九十百]+", text):
        return None
    if all(character in digits for character in text):
        return float(int("".join(str(digits[character]) for character in text)))
    total = current = 0
    for char in text:
        if char in digits:
            current = digits[char]
        elif char == "十":
            total += (current or 1) * 10
            current = 0
        elif char == "百":
            total += (current or 1) * 100
            current = 0
    return float(total + current)


def parse_requested_duration(content):
    content = str(content).lower()
    cn = "零〇一二两三四五六七八九十百"
    number = r"(?:\d{1,4}(?:\.\d+)?|[" + cn + r"]{1,5})"
    patterns = (
        (re.compile(r"(?<![a-z0-9])(?P<hours>" + number +
                    r")\s*(?:小时|小時|钟头|鐘頭)\s*(?:(?P<minutes>" + number +
                    r")\s*(?:分钟|分鐘|分)|(?P<half>半))?"), 3600),
        (re.compile(r"(?<![a-z0-9])(?P<hours>\d+(?:\.\d+)?)\s*(?:hours?|hrs?|hr)\b"
                    r"(?:\s*(?:and\s+)?(?P<minutes>\d+(?:\.\d+)?)\s*(?:minutes?|mins?|min)\b)?", re.I), 3600),
        (re.compile(r"(?<![a-z0-9])(?P<minutes>\d+(?:\.\d+)?)\s*(?:minutes?|mins?|min)\b", re.I), 60),
        (re.compile(r"(?<![a-z0-9])(?P<seconds>\d+(?:\.\d+)?)\s*(?:seconds?|secs?|sec)\b", re.I), 1),
        (re.compile(r"(?<![a-z0-9])(?P<minutes>" + number +
                    r")\s*(?:分钟|分)\s*(?:(?P<seconds>" + number + r")\s*秒(?:钟)?|(?P<half>半)(?:钟)?)?"), 60),
        (re.compile(r"(?<![a-z0-9])半\s*(?:分钟|分)(?:钟)?"), 30),
        (re.compile(r"(?<![a-z0-9])(?P<seconds>" + number + r")\s*(?:秒(?:钟)?|s\b)"), 1),
    )
    candidates = []
    occupied = []
    for pattern, scale in patterns:
        for match in pattern.finditer(content):
            if any(start < match.end() and match.start() < end for start, end in occupied):
                continue
            if scale == 30:
                seconds = 30.0
            elif scale == 3600:
                hours = chinese_duration_number(match.group("hours"))
                if hours is None:
                    continue
                minutes = chinese_duration_number(match.groupdict().get("minutes")) if match.groupdict().get("minutes") else 0
                seconds = hours * 3600 + minutes * 60 + (1800 if match.groupdict().get("half") else 0)
            elif scale == 60:
                minute_value = chinese_duration_number(match.group("minutes"))
                seconds_value = (chinese_duration_number(match.groupdict().get("seconds"))
                                 if match.groupdict().get("seconds") else 0)
                if minute_value is None or seconds_value is None:
                    continue
                seconds = minute_value * 60 + seconds_value + (30 if match.groupdict().get("half") else 0)
            else:
                seconds = chinese_duration_number(match.group("seconds"))
            if seconds is not None and seconds > 0:
                candidates.append((match.start(), match.end(), float(seconds)))
                occupied.append((match.start(), match.end()))
    for match in re.finditer(r"(?<!\d)(\d{1,2}):(\d{2})(?![:\d])", content):
        minutes, seconds = map(int, match.groups())
        if seconds >= 60:
            continue
        before = content[max(0, match.start() - DURATION_TIME_CONTEXT_CHARS):match.start()]
        if re.search(r"(?:发布|开始|拍摄|今晚|凌晨|上午|下午|早上|晚上|几点|日期|时间|\d{4}[-/.年]\d{1,2})\s*$", before):
            continue
        if any(start < match.end() and match.start() < end for start, end in occupied):
            continue
        candidates.append((match.start(), match.end(), minutes * 60.0 + seconds))
    if not candidates:
        return None
    duration_markers = (r"(?:总时长|总长度|全片时长|整段时长|成片(?:总)?时长|"
                        r"视频(?:总)?时长|视频(?:总)?长度|片长|整片时长|时长|duration|"
                        r"(?:视频|短片|成片)(?:控制在|为|约|长))")
    local_markers = (r"(?:每(?:个|段|幕|镜头|场景)|各(?:个|段|镜头)|第[一二三四五六七八九十\d]+"
                     r"(?:个|段|幕|镜头)|前\s*\d*|后\s*\d*|开头|结尾|片头|片尾|"
                     r"镜头|场景|分镜|转场|展示|走路|解释|讲解|停留|切换)")
    classified = []
    for start, end, seconds in candidates:
        before = content[max(0, start - DURATION_TIME_CONTEXT_CHARS):start]
        after = content[end:end + DURATION_TIME_CONTEXT_CHARS]
        short_before = re.split(r"[,，。;；!！?？\n]", before)[-1]
        short_after = re.split(r"[,，。;；!！?？\n]", after)[0]
        explicit = bool(re.search(duration_markers + r"\s*[:：=为约在到]?\s*$", short_before) or
                        re.search(r"^\s*(?:的|为)?\s*(?:总时长|片长|视频时长|成片时长|"
                                  r"(?:的)?(?:视频|成片|短片|全片))", short_after))
        local = bool(re.search(local_markers + r"[^,，。;；!！?？\n]{0,9}$", short_before))
        classified.append((start, seconds, explicit, local))
    explicit = [item for item in classified if item[2]]
    if explicit:
        return min(explicit, key=lambda item: item[0])[1]
    per_shot = re.search(r"每(?:个|段|幕|镜头|场景)\s*(?:镜头|场景|分镜)?\s*"
                         r"(?:持续|长|为|约)?\s*(" + number + r")\s*(?:秒(?:钟)?|s\b)", content)
    shot_count = re.search(r"(?:共|一共|总共|合计)?\s*(" + number + r")\s*"
                           r"(?:个|段|幕|场|组)?\s*(?:镜头|场景|分镜|片段)", content)
    if per_shot and shot_count and abs(per_shot.start() - shot_count.start()) < 100:
        per = chinese_duration_number(per_shot.group(1))
        count = chinese_duration_number(shot_count.group(1))
        if per and count and count.is_integer() and count <= 100:
            return per * count
    nonlocal_values = [item for item in classified if not item[3]]
    if len(nonlocal_values) == 1:
        start, value, _, _ = nonlocal_values[0]
        before = content[max(0, start - MIN_EXPLICIT_DURATION_CONTEXT):start]
        after = content[start:start + MIN_EXPLICIT_DURATION_CONTEXT + 24]
        before_has_video = bool(re.search(r"(?:视频|短片|成片|影片|片子|动画|广告片|video|clip|film)", before, re.I))
        after_has_video = bool(re.search(r"(?:视频|短片|成片|影片|片子|动画|广告片|video|clip|film)", after, re.I))
        creative = bool(re.search(r"(?:制作|生成|创作|剪辑|拍摄|做成|做|来个|make|create|generate)", before, re.I))
        if (creative and after_has_video) or (before_has_video and
            (creative or re.search(r"(?:长|约|为|控制在|时长|片长|duration|length)", before, re.I))):
            return value
    return None


def media_preferences(prompt):
    source = str(prompt).lower().replace("’", "'").replace("‘", "'")
    content = re.sub(r"\s+", "", source)
    mute_all = bool(re.search(
        r"完全静音|全程静音|纯静音|无声(?:视频|短片|作品)|没有任何声音|不要任何声音|"
        r"不需要任何声音|不要声音|无需声音|不含声音|不要音频|无音频|"
        r"(?:纯画面|只有画面)(?:、|，|,)?(?:不要声音|无声音|静音)", content) or
        re.search(r"\b(?:completely\s+silent|no\s+(?:audio|sound)|without\s+(?:any\s+)?(?:audio|sound)|mute\s+(?:all|the\s+video))\b", source))
    voice_terms = r"旁白|配音|解说(?:词)?|口播|语音|朗读|讲述|人声"
    caption_terms = r"字幕|文字叠加|屏幕文字|画面文字|文字水印|文本叠加|文字|字卡"
    music_terms = r"背景音乐|背景配乐|配乐|音乐|bgm|伴奏|音轨"
    negative_head = (r"(?:不要|不需要|无需|不必|不加|不添加|不放|不配|不含|不带|"
                     r"别(?:再)?(?:加|放|配|用|出现)?|请勿(?:加|放|用|出现)?|"
                     r"禁止|去掉|移除|禁用|关闭|取消|没有|无)")
    negative_targets = set()
    clauses = re.split(r"[，,。.!！;；?？\n]|但是|不过|然而|(?<!不)但(?=要|需|想|保留|加|放)|而是", content)
    for clause in clauses:
        suffix = re.search(r"(?P<targets>(?:" + voice_terms + "|" + caption_terms + "|" + music_terms +
                           r")(?:[和及与跟、]+(?:" + voice_terms + "|" + caption_terms + "|" + music_terms +
                           r"))+)\s*(?:都|统统|一律)?\s*(?:不要|不需要|无需|不必|别加|不加)", clause)
        if suffix:
            named = suffix.group("targets")
            if re.search(voice_terms, named):
                negative_targets.add("narration")
            if re.search(caption_terms, named):
                negative_targets.add("subtitles")
            if re.search(music_terms, named):
                negative_targets.add("music")
        for match in re.finditer(negative_head, clause):
            tail = clause[match.end():]
            positive = re.search(r"(?<!不)(?<!无)(?:仍然?需要|仍然?要|需要|保留|请加|请用|要加|要用|必须加|必须有)", tail)
            following_negative = re.search(negative_head, tail)
            boundary = min([item.start() for item in (positive, following_negative) if item is not None],
                           default=len(tail))
            targeted = tail[:boundary]
            if re.search(voice_terms, targeted):
                negative_targets.add("narration")
            if re.search(caption_terms, targeted):
                negative_targets.add("subtitles")
            if re.search(music_terms, targeted):
                negative_targets.add("music")
    no_voice = bool("narration" in negative_targets or re.search(
        r"\b(?:no|without|disable|remove)\s+(?:(?:any|the)\s+)?"
        r"(?:narration|narrator|voice\s*-?over|voiceover|spoken\s+words|speech|dub(?:bing)?)\b", source) or
        re.search(r"\b(?:don't|dont|do\s+not|never)\s+(?:(?:add|include|use|generate|create)\s+)?"
                  r"(?:(?:any|the)\s+)?(?:narration|voice\s*-?over|voiceover|speech|dubbing)\b", source))
    no_captions = bool("subtitles" in negative_targets or "纯画面" in content or "只有画面" in content or
        re.search(r"\b(?:no|without|disable|remove)\s+(?:(?:any|the)\s+)?"
                  r"(?:subtitles?|captions?|on\s*-?screen\s+text|text\s+overlays?)\b", source) or
        re.search(r"\b(?:don't|dont|do\s+not|never)\s+(?:(?:add|include|use|show|display|generate|create)\s+)?"
                  r"(?:(?:any|the)\s+)?(?:subtitles?|captions?|on\s*-?screen\s+text|text\s+overlays?)\b", source))
    no_music = bool("music" in negative_targets or re.search(
        r"\b(?:no|without|disable|remove)\s+(?:(?:any|the)\s+)?"
        r"(?:background\s+music|music|soundtrack|score)\b", source))
    wants_english = bool(re.search(r"(?:英语|英文|英式|美式)(?:旁白|配音|解说|语音)|"
                                  r"(?:narration|voiceover|voice-over|dub(?:bing)?)\s+in\s+english|"
                                  r"english\s+(?:narration|voiceover|voice-over|dubbing)", source, re.I))
    required_voice = bool(re.search(r"(?:必须|务必|请|需要|要|添加|配上|加入).{0,8}(?:" + voice_terms + r")|"
                                     r"(?:" + voice_terms + r").{0,5}(?:必须|需要|请加|要有)|"
                                     r"\b(?:with|include|add|must have)\s+(?:narration|voiceover|dubbing)\b", source, re.I))
    required_caption = bool(re.search(r"(?:必须|务必|请|需要|要|添加|配上|加入).{0,8}(?:字幕|字卡)|"
                                       r"(?:字幕|字卡).{0,5}(?:必须|需要|请加|要有)|"
                                       r"\b(?:with|include|add|must have)\s+(?:subtitles|captions)\b", source, re.I))
    required_music = bool(re.search(r"(?:必须|务必|请|需要|要|添加|配上|加入).{0,8}(?:" + music_terms + r")|"
                                     r"(?:" + music_terms + r").{0,5}(?:必须|需要|请加|要有)|"
                                     r"\b(?:with|include|add|must have)\s+(?:music|soundtrack|score)\b", source, re.I))
    def policy(no, must):
        return "forbidden" if mute_all or no else "required" if must else "auto"
    policies = {"narration_policy": policy(no_voice, required_voice or wants_english),
                "subtitles_policy": policy(no_captions, required_caption),
                "music_policy": policy(no_music, required_music)}
    return {"narration": policies["narration_policy"] == "required",
            "subtitles": policies["subtitles_policy"] == "required",
            "music": policies["music_policy"] == "required", "source_audio": not mute_all,
            "mute_all": mute_all, "voice_language": "en" if wants_english else "zh", **policies}


def recommend_project_settings(prompt, assets, available_memory=0):
    content = re.sub(r"\s+", " ", str(prompt)).strip().lower()
    pictures = sum(len(assets.get(kind, [])) for kind in ("图片", "首帧", "尾帧", "视频"))
    image_count = len(assets.get("图片", [])) + len(assets.get("视频", []))
    if any(word in content for word in ("竖屏", "9:16", "9：16")):
        aspect = "竖屏 9:16"
        aspect_reason = "识别到竖屏需求"
    elif any(word in content for word in ("横屏", "16:9", "16：9", "宽屏")):
        aspect = "横屏 16:9"
        aspect_reason = "识别到宽屏需求"
    elif any(word in content for word in ("方形", "正方形", "1:1", "1：1")):
        aspect = "方形 1:1"
        aspect_reason = "识别到方形构图"
    elif any(word in content for word in ("抖音", "快手", "tiktok", "reels", "shorts", "小红书", "手机短视频")):
        aspect = "竖屏 9:16"
        aspect_reason = "移动端内容推荐竖屏"
    else:
        aspect = "横屏 16:9"
        aspect_reason = "默认电影宽屏构图"
    requested_seconds = parse_requested_duration(content)
    if requested_seconds is not None:
        rounded = math.ceil(requested_seconds)
        duration = str(rounded)
        duration_reason = ("已采用提示词指定的时长" if MIN_REQUEST_DURATION <= rounded <= MAX_REQUEST_DURATION else
                           "指定时长%d秒超出当前离线可靠范围%d至%d秒；将明确提示而不擅自截短" % (
                               rounded, MIN_REQUEST_DURATION, MAX_REQUEST_DURATION))
    elif any(word in content for word in ("一分钟", "1分钟", "60秒", "完整教程", "长故事", "知识科普")):
        duration = "60"
        duration_reason = "讲解内容需要更完整的叙事"
    elif any(word in content for word in ("预告片", "片头", "闪剪", "15秒", "简短广告")):
        duration = "15"
        duration_reason = "短节奏内容建议15秒"
    elif image_count >= 5:
        duration = "60"
        duration_reason = "素材较多，推荐更充分的镜头时长"
    else:
        duration = "30"
        duration_reason = "推荐30秒创作长度"
    if 0 < available_memory < 4 * GB:
        quality = "快速"
        quality_reason = "可用内存较少，优先降低负载"
    elif (available_memory >= 12 * GB and any(word in content for word in
                                               ("精细", "精致", "高画质", "高品质", "细节丰富"))):
        quality = "精细"
        quality_reason = "画质要求较高，内存条件适合精细模式"
    else:
        quality = "智能"
        quality_reason = "自动平衡画质和设备负载"
    role = "仅作参考"
    if assets.get("音频") and any(word in content for word in
                                    ("背景音乐", "作为配乐", "使用上传的音乐", "用我的音乐", "用上传的音乐")):
        role = "作为背景音乐"
    reasons = [aspect_reason, duration_reason, quality_reason]
    if pictures and not content:
        reasons = ["已识别 %d 份画面素材" % pictures, duration_reason, quality_reason]
    if role == "作为背景音乐":
        reasons.append("已建议采用上传的背景音乐")
    return {"aspect": aspect, "duration": duration, "quality": quality,
            "audio_role": role, "reasons": reasons}

class StudioUI:
    def __init__(self):
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
        self.tk = tk
        self.ttk = ttk
        self.filedialog = filedialog
        self.messagebox = messagebox
        if os.name == "nt":
            try:
                try:
                    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
                except (AttributeError, OSError, ValueError):
                    ctypes.windll.shcore.SetProcessDpiAwareness(2)
            except (OSError, AttributeError):
                pass
        self.root = tk.Tk()
        if os.name == "nt":
            try:
                dpi = int(ctypes.windll.user32.GetDpiForWindow(self.root.winfo_id()))
                if dpi > 0:
                    self.root.tk.call("tk", "scaling", dpi / 72.0)
            except (OSError, AttributeError, ValueError, tk.TclError):
                pass
        self.root.title(APP_NAME)
        self.last_dpi = None
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        usable_width = max(480, screen_width - 56)
        usable_height = max(420, screen_height - 86)
        min_width = min(720, usable_width)
        min_height = min(550, usable_height)
        self.root.minsize(min_width, min_height)
        width = max(min_width, min(1280, int(screen_width * .89), usable_width))
        height = max(min_height, min(920, int(screen_height * .88), usable_height))
        self.root.geometry("%dx%d+%d+%d" % (width, height, max(0, (screen_width - width) // 2),
                                             max(0, (screen_height - height) // 2)))
        self.palette = {
            "bg": "#090F1B", "panel": "#111B2B", "surface": "#172336", "input": "#0D1727",
            "stroke": "#27374D", "fg": "#F0F5FE", "muted": "#91A5BE", "accent": "#58B3FF",
            "accent_bg": "#1466BB", "accent_hover": "#237DCE", "green": "#66DFBA",
            "amber": "#F3C674", "danger": "#FF9295", "soft": "#B7C8DD"
        }
        self.font_family = "Microsoft YaHei UI" if os.name == "nt" else "DejaVu Sans"
        self.root.configure(bg=self.palette["bg"])
        self.root_path = None
        self.workspace_lock = None
        self.task = None
        self.ready = False
        self.blackbox_active = False
        self.stop_event = threading.Event()
        self.install_stop = threading.Event()
        self.setup_active = False
        self.basic_ready = False
        self.capabilities = {}
        self.setup_thread = None
        self.job_thread = None
        self.blackbox_thread = None
        self.cleanup_thread = None
        self.native_auto_thread = None
        self.native_stop = threading.Event()
        self.deployment_retry = 0
        self.force_integrity_scan = False
        self.pending_start_request = None
        self.job_stop_file = None
        self.events = queue.Queue()
        self.log_lock = threading.Lock()
        self.assets = {name: [] for name in ("图片", "首帧", "尾帧", "音频", "视频", "文档")}
        self.last_job = None
        self.last_output = None
        self.recommendation_after = None
        self.current_phase = "idle"
        self.scene_entries = []
        self.scene_rows = []
        self.scene_row_start = 0
        self.closing = False
        self.close_deadline = None
        self.preview_file = None
        self.preview_photo = None
        self.preview_request = None
        self.preview_worker = None
        self.preview_after = None
        self.preview_failed_keys = set()
        self.wide_layout = None
        self.setup_ui()
        self.tune_native_window()
        self.root.after(120, self.process_events)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(250, self.select_workspace)

    def tune_native_window(self):
        if os.name != "nt":
            return
        try:
            parent_function = ctypes.windll.user32.GetParent
            parent_function.argtypes = [ctypes.c_void_p]
            parent_function.restype = ctypes.c_void_p
            handle = parent_function(self.root.winfo_id()) or self.root.winfo_id()
            theme_function = ctypes.windll.dwmapi.DwmSetWindowAttribute
            theme_function.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
            theme_function.restype = ctypes.c_long
            dark = ctypes.c_int(1)
            rounded = ctypes.c_int(2)
            theme_function(handle, 20, ctypes.byref(dark), ctypes.sizeof(dark))
            theme_function(handle, 33, ctypes.byref(rounded), ctypes.sizeof(rounded))
        except (OSError, AttributeError, ValueError):
            pass

    def label(self, parent, text, size=10, color=None, strong=False, bg=None, **kwargs):
        return self.tk.Label(parent, text=text, bg=bg or self.palette["panel"],
                             fg=color or self.palette["fg"], anchor="w", justify="left",
                             font=(self.font_family, size, "bold" if strong else "normal"), **kwargs)

    def card(self, parent, padx=18, pady=17):
        return self.tk.Frame(parent, bg=self.palette["panel"], padx=padx, pady=pady,
                             bd=0, highlightthickness=1, highlightbackground=self.palette["stroke"])

    def setup_ui(self):
        tk = self.tk
        ttk = self.ttk
        p = self.palette
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TButton", background=p["surface"], foreground=p["fg"],
                        borderwidth=0, relief="flat", padding=(12, 9),
                        font=(self.font_family, 10))
        style.map("TButton", background=[("active", "#243A55"), ("disabled", "#1A2739")],
                  foreground=[("disabled", "#6F849D")])
        style.configure("Primary.TButton", background=p["accent_bg"], foreground="#FFFFFF",
                        borderwidth=0, relief="flat", padding=(23, 12),
                        font=(self.font_family, 11, "bold"))
        style.map("Primary.TButton", background=[("active", p["accent_hover"]),
                                                  ("disabled", "#273A50")],
                  foreground=[("disabled", "#8497AC")])
        style.configure("Small.TButton", background=p["surface"], foreground=p["soft"],
                        borderwidth=0, padding=(10, 6), font=(self.font_family, 9))
        style.map("Small.TButton", background=[("active", "#263A55"), ("disabled", "#1A2739")],
                  foreground=[("disabled", "#70859E")])
        style.configure("Modern.TCombobox", fieldbackground=p["input"], background=p["input"],
                        foreground=p["fg"], arrowcolor=p["soft"], borderwidth=0, relief="flat",
                        selectbackground=p["accent_bg"], selectforeground="white", padding=8,
                        font=(self.font_family, 10))
        style.map("Modern.TCombobox", fieldbackground=[("readonly", p["input"])],
                  foreground=[("readonly", p["fg"])],
                  selectbackground=[("readonly", p["input"])],
                  selectforeground=[("readonly", p["fg"])])
        style.configure("Slim.Horizontal.TProgressbar", troughcolor=p["stroke"],
                        background=p["accent"], bordercolor=p["stroke"],
                        lightcolor=p["accent"], darkcolor=p["accent"], thickness=6)
        style.configure("Vertical.TScrollbar", background=p["surface"], troughcolor=p["bg"],
                        bordercolor=p["bg"], arrowcolor=p["muted"])
        self.header = tk.Frame(self.root, bg=p["bg"], padx=25, pady=16)
        self.header.pack(fill="x")
        brand = tk.Frame(self.header, bg=p["bg"])
        brand.pack(side="left")
        mark = tk.Canvas(brand, width=41, height=41, bg=p["bg"], highlightthickness=0)
        mark.pack(side="left", padx=(0, 12))
        mark.create_rectangle(2, 2, 39, 39, fill=p["accent_bg"], outline=p["accent_bg"], width=0)
        mark.create_text(20, 20, text="AI", fill="#FFFFFF", font=("Segoe UI", 13, "bold"))
        brand_text = tk.Frame(brand, bg=p["bg"])
        brand_text.pack(side="left")
        self.label(brand_text, "AI 视频工坊", 16, strong=True, bg=p["bg"]).pack(anchor="w")
        tools = tk.Frame(self.header, bg=p["bg"])
        tools.pack(side="right")
        self.ready_badge = self.label(tools, "● 尚未就绪", 10, p["muted"], bg=p["bg"])
        self.ready_badge.pack(side="left", padx=(0, 16))
        ttk.Button(tools, text="工作目录", style="Small.TButton",
                   command=self.select_workspace).pack(side="left")
        status_bar = tk.Frame(self.root, bg=p["panel"], padx=25, pady=10,
                              highlightbackground=p["stroke"], highlightthickness=1)
        status_bar.pack(fill="x", padx=20, pady=(0, 5))
        state_row = tk.Frame(status_bar, bg=p["panel"])
        state_row.pack(fill="x")
        self.stage_label = self.label(state_row, "准备离线环境", 9,
                                      p["soft"], bg=p["panel"], wraplength=850)
        self.stage_label.pack(side="left", fill="x", expand=True)
        self.folder_label = self.label(status_bar, "尚未选择工作目录", 8, p["muted"],
                                       bg=p["panel"], wraplength=850)
        self.folder_label.pack(fill="x", pady=(3, 4))
        self.capability_label = self.label(status_bar, "离线能力检测中", 9,
                                           p["soft"], bg=p["panel"], wraplength=850)
        self.capability_label.pack(fill="x", pady=(0, 5))
        self.setup_progress = ttk.Progressbar(status_bar, style="Slim.Horizontal.TProgressbar",
                                               mode="determinate", maximum=100)
        self.setup_progress.pack(fill="x")
        outer = tk.Frame(self.root, bg=p["bg"])
        outer.pack(fill="both", expand=True)
        self.main_canvas = tk.Canvas(outer, bg=p["bg"], highlightthickness=0, bd=0)
        scrolling = ttk.Scrollbar(outer, orient="vertical", command=self.main_canvas.yview)
        self.main_canvas.configure(yscrollcommand=scrolling.set)
        scrolling.pack(side="right", fill="y")
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.body = tk.Frame(self.main_canvas, bg=p["bg"], padx=20, pady=16)
        self.body_window = self.main_canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.main_canvas.bind("<Configure>", self.main_canvas_resized)
        self.body.bind("<Configure>", lambda event: self.root.after_idle(self.refresh_scrollregion))
        self.root.bind_all("<MouseWheel>", self.scroll_workspace)
        self.root.bind_all("<Button-4>", self.scroll_workspace)
        self.root.bind_all("<Button-5>", self.scroll_workspace)
        self.columns = tk.Frame(self.body, bg=p["bg"])
        self.columns.pack(fill="x")
        self.creation_column = self.build_creation_panel(self.columns)
        self.preview_column = self.build_preview_panel(self.columns)
        self.apply_responsive_layout(self.root.winfo_width())
        self.footer = tk.Frame(self.root, bg=p["bg"], padx=23, pady=13)
        self.footer.pack(fill="x")
        self.start_btn = ttk.Button(self.footer, text="启动", style="Primary.TButton",
                                    command=self.start_job)
        self.start_btn.pack(side="left", padx=(0, 9))
        self.black_btn = ttk.Button(self.footer, text="黑匣子", style="Small.TButton", command=self.blackbox)
        self.black_btn.pack(side="right", padx=(8, 0))
        self.refresh_asset_label()
        self.refresh_smart_suggestions()
        self.render_task_state("idle")
        self.refresh_buttons()

    def build_creation_panel(self, parent):
        tk = self.tk
        ttk = self.ttk
        p = self.palette
        column = tk.Frame(parent, bg=p["bg"])
        hero = tk.Frame(column, bg=p["bg"])
        hero.pack(fill="x", pady=(2, 15))
        self.label(hero, "从一个想法，开始创作", 20, strong=True, bg=p["bg"]).pack(anchor="w")
        self.label(hero, "输入你希望最终视频呈现的内容", 10,
                   p["muted"], bg=p["bg"]).pack(anchor="w", pady=(4, 0))
        prompt_card = self.card(column)
        prompt_card.pack(fill="x", pady=(0, 12))
        header = tk.Frame(prompt_card, bg=p["panel"])
        header.pack(fill="x", pady=(0, 10))
        self.label(header, "01  创作灵感", 11, strong=True).pack(side="left")

        self.prompt_box = tk.Text(prompt_card, height=6, wrap="word", undo=True, relief="flat", bd=0,
                                  background=p["input"], foreground=p["fg"], insertbackground=p["fg"],
                                  selectbackground=p["accent_bg"], selectforeground="white",
                                  font=(self.font_family, 11), padx=14, pady=13,
                                  highlightthickness=1, highlightbackground=p["stroke"],
                                  highlightcolor=p["accent"])
        self.prompt_box.pack(fill="x")
        self.prompt_box.insert("1.0", "例：制作一段温暖的城市夜景短片，镜头有电影感，配中文旁白。")
        self.prompt_box.bind("<FocusIn>", self.clear_example)
        self.prompt_box.bind("<KeyRelease>", self.schedule_recommendations)
        asset_card = self.card(column)
        asset_card.pack(fill="x", pady=(0, 12))
        file_head = tk.Frame(asset_card, bg=p["panel"])
        file_head.pack(fill="x")
        self.label(file_head, "02  参考素材", 11, strong=True).pack(side="left")
        ttk.Button(file_head, text="＋ 添加素材", style="Small.TButton",
                   command=self.add_assets).pack(side="right")
        self.assets_label = self.label(asset_card, "尚未添加素材", 9, p["muted"])
        self.assets_label.pack(anchor="w", pady=(9, 7))
        self.asset_rows_frame = tk.Frame(asset_card, bg=p["panel"])
        self.asset_rows_frame.pack(fill="x")
        file_action = tk.Frame(asset_card, bg=p["panel"])
        file_action.pack(fill="x", pady=(8, 0))
        ttk.Button(file_action, text="指定首尾帧 / 管理", style="Small.TButton",
                   command=self.manage_assets).pack(side="left")
        config_card = self.card(column)
        config_card.pack(fill="x")
        self.label(config_card, "自动视频方案", 10, p["soft"], strong=True).pack(anchor="w")
        self.duration = tk.StringVar(value="30")
        self.quality = tk.StringVar(value="智能")
        self.aspect = tk.StringVar(value="横屏 16:9")
        self.audio_role = tk.StringVar(value="仅作参考")
        self.source_audio_role = tk.StringVar(value="自动混合原声")
        self.visual_mode = tk.StringVar(value="原生AI视频（自动）")
        self.recommendation_label = self.label(config_card, "分析中", 10,
                                               p["green"], wraplength=520)
        self.recommendation_label.pack(anchor="w", fill="x", pady=(8, 0))
        return column

    def build_preview_panel(self, parent):
        tk = self.tk
        ttk = self.ttk
        p = self.palette
        column = tk.Frame(parent, bg=p["bg"])
        self.label(column, "创作监视器", 13, strong=True, bg=p["bg"]).pack(anchor="w", pady=(5, 12))
        preview_card = self.card(column, 14, 14)
        preview_card.pack(fill="x", pady=(0, 12))
        preview_header = tk.Frame(preview_card, bg=p["panel"])
        preview_header.pack(fill="x", pady=(0, 10))
        self.label(preview_header, "画面预览", 10, strong=True).pack(side="left")
        self.preview_state = self.label(preview_header, "等待创作", 9, p["muted"])
        self.preview_state.pack(side="right")
        self.preview_canvas = tk.Canvas(preview_card, height=240, bg=p["input"],
                                        highlightthickness=1, highlightbackground=p["stroke"], bd=0)
        self.preview_canvas.pack(fill="x")
        self.preview_canvas.bind("<Configure>", self.draw_preview)
        self.preview_caption = self.label(preview_card, "分镜完成后，画面会逐幕出现在这里", 9,
                                           p["muted"], wraplength=390)
        self.preview_caption.pack(fill="x", pady=(10, 0))
        flow_card = self.card(column, 14, 14)
        flow_card.pack(fill="x", pady=(0, 12))
        progress_head = tk.Frame(flow_card, bg=p["panel"])
        progress_head.pack(fill="x")
        self.label(progress_head, "任务进度", 10, strong=True).pack(side="left")
        self.progress_text = self.label(progress_head, "0%", 10, p["accent"], strong=True)
        self.progress_text.pack(side="right")
        self.creation_progress = ttk.Progressbar(flow_card, style="Slim.Horizontal.TProgressbar",
                                                 mode="determinate", maximum=100)
        self.creation_progress.pack(fill="x", pady=(12, 13))
        self.phase_widgets = {}
        for phase, title in (("preparing", "准备素材"), ("planning", "理解需求与分镜规划"),
                             ("rendering", "生成、审校与修复镜头"), ("finishing", "剪辑、混音与成片校验")):
            line = tk.Frame(flow_card, bg=p["panel"])
            line.pack(fill="x", pady=(0, 8))
            marker = self.label(line, "○", 12, p["muted"])
            marker.pack(side="left", padx=(0, 9))
            name_label = self.label(line, title, 9, p["muted"])
            name_label.pack(side="left", fill="x", expand=True)
            self.phase_widgets[phase] = (marker, name_label)
        scene_card = self.card(column, 14, 14)
        scene_card.pack(fill="x", pady=(0, 12))
        scene_header = tk.Frame(scene_card, bg=p["panel"])
        scene_header.pack(fill="x")
        self.label(scene_header, "镜头时间线", 10, strong=True).pack(side="left")
        self.scene_count = self.label(scene_header, "待规划", 9, p["muted"])
        self.scene_count.pack(side="right")
        self.scene_rows_frame = tk.Frame(scene_card, bg=p["panel"])
        self.scene_rows_frame.pack(fill="x", pady=(10, 0))
        self.scene_empty_label = self.label(self.scene_rows_frame, "AI 完成分镜规划后，将显示各幕进度", 9,
                                            p["muted"], wraplength=340)
        self.scene_empty_label.pack(anchor="w")
        self.result_card = self.card(column, 14, 14)
        self.label(self.result_card, "作品已完成", 12, p["green"], strong=True).pack(anchor="w")
        self.result_info = self.label(self.result_card, "", 9, p["soft"], wraplength=360)
        self.result_info.pack(fill="x", pady=(9, 10))
        return column

    def main_canvas_resized(self, event):
        self.main_canvas.itemconfigure(self.body_window, width=event.width)
        if os.name == "nt":
            try:
                dpi = int(ctypes.windll.user32.GetDpiForWindow(self.root.winfo_id()))
                if dpi > 0 and dpi != self.last_dpi:
                    self.last_dpi = dpi
                    self.root.tk.call("tk", "scaling", dpi / 72.0)
            except (OSError, AttributeError, ValueError, self.tk.TclError):
                pass
        self.apply_responsive_layout(event.width)
        wrap_width = max(140, event.width - max(35, int(self.root.winfo_fpixels("0.65i"))))
        self.folder_label.configure(wraplength=wrap_width)
        self.stage_label.configure(wraplength=wrap_width)
        self.capability_label.configure(wraplength=wrap_width)
        self.result_info.configure(wraplength=max(150, int(event.width * (.27 if self.wide_layout else .80))))
        self.scene_empty_label.configure(wraplength=wrap_width) if getattr(
            self, "scene_empty_label", None) and self.scene_empty_label.winfo_exists() else None
        if event.width < max(490, int(self.root.winfo_fpixels("6.4i"))):
            self.ready_badge.pack_forget()
        elif not self.ready_badge.winfo_manager():
            self.ready_badge.pack(side="left", padx=(0, 12))
        self.recommendation_label.configure(wraplength=max(170, int(event.width * (.40 if self.wide_layout else .82))))
        if hasattr(self, "scene_rows"):
            available = max(130, int(event.width * (.25 if self.wide_layout else .65)))
            for marker, content, state in self.scene_rows:
                content.configure(wraplength=available)
        self.root.after_idle(self.refresh_scrollregion)

    def apply_responsive_layout(self, width):
        min_panel_width = max(320, int(self.root.winfo_fpixels("4.2i")))
        min_preview_width = max(280, int(self.root.winfo_fpixels("3.6i")))
        wide = width >= min_panel_width + min_preview_width + max(25, int(self.root.winfo_fpixels("0.5i")))
        if wide == self.wide_layout:
            return
        self.wide_layout = wide
        self.creation_column.grid_forget()
        self.preview_column.grid_forget()
        if wide:
            self.columns.grid_columnconfigure(0, weight=3)
            self.columns.grid_columnconfigure(1, weight=2)
            self.creation_column.grid(row=0, column=0, sticky="new", padx=(0, 13))
            self.preview_column.grid(row=0, column=1, sticky="new")
        else:
            self.columns.grid_columnconfigure(0, weight=1)
            self.columns.grid_columnconfigure(1, weight=0)
            self.creation_column.grid(row=0, column=0, sticky="new")
            self.preview_column.grid(row=1, column=0, sticky="new", pady=(14, 0))
        self.root.after_idle(self.refresh_scrollregion)

    def refresh_scrollregion(self):
        try:
            region = self.main_canvas.bbox("all")
            if region is not None:
                self.main_canvas.configure(scrollregion=region)
        except self.tk.TclError:
            pass

    def scroll_workspace(self, event):
        try:
            if event.widget.winfo_toplevel() != self.root:
                return
            if isinstance(event.widget, (self.tk.Text, self.tk.Listbox, self.ttk.Combobox)) or \
                    event.widget.winfo_class() in {"Text", "Listbox", "TCombobox", "Treeview"}:
                return
            step = -1 if getattr(event, "delta", 0) > 0 or getattr(event, "num", None) == 4 else 1
            self.main_canvas.yview_scroll(step * 2, "units")
        except self.tk.TclError:
            pass

    def schedule_recommendations(self, event=None):
        if self.recommendation_after is not None:
            self.root.after_cancel(self.recommendation_after)
        self.recommendation_after = self.root.after(UI_RECOMMEND_DELAY_MS, self.refresh_smart_suggestions)

    def refresh_smart_suggestions(self):
        self.recommendation_after = None
        if not hasattr(self, "recommendation_label"):
            return
        prompt = self.prompt_box.get("1.0", "end-1c").strip()
        if prompt.startswith("例："):
            prompt = ""
        proposal = recommend_project_settings(prompt, self.assets, memory_info()["available"])
        for key, variable in (("duration", self.duration), ("aspect", self.aspect),
                              ("quality", self.quality), ("audio_role", self.audio_role)):
            variable.set(str(proposal[key]))
        request = {"prompt": prompt, "files": self.assets}
        mode = native_mode_for_request(self.capabilities, request,
                                       self.capabilities.get("native_model_class"))
        self.visual_mode.set(mode["visual_mode"])
        plan = "%s 秒 · %s · %s画质" % (self.duration.get(), self.aspect.get(), self.quality.get())
        if self.assets["音频"] and self.audio_role.get() == "作为背景音乐":
            plan += " · 使用提供的配乐"
        if self.assets["视频"]:
            self.source_audio_role.set("自动混合原声")
            plan += " · 优先理解并剪辑原视频"
        if mode["native_usable"]:
            plan += " · 原生时序视频（实际推理已验收）"
        elif mode["native_required"]:
            plan += " · 指定原生时序视频，需等待适配模型通过验收"
        elif self.capabilities.get("full_offline"):
            plan += " · 本地AI生图与动态运镜"
            if self.capabilities.get("native_video") and not mode["compatible"]:
                plan += " · 当前原生模型不兼容上传图片"
        else:
            plan += " · 离线创作组件准备中"
        adjusted = next((reason for reason in proposal["reasons"] if "超出当前离线可靠范围" in reason), "")
        if adjusted:
            plan += " · " + adjusted
        self.recommendation_label.configure(text=plan)

    def queue_preview_thumbnail(self, key, source, destination, width, height):
        self.preview_request = (key, str(source), str(destination), int(width), int(height))
        if self.preview_after is not None:
            try:
                self.root.after_cancel(self.preview_after)
            except self.tk.TclError:
                pass
        self.preview_after = self.root.after(UI_PREVIEW_RENDER_DELAY_MS,
                                            self.start_preview_thumbnail)

    def start_preview_thumbnail(self):
        self.preview_after = None
        request = self.preview_request
        if not request or self.closing or request[0] in self.preview_failed_keys:
            return
        if self.preview_worker is not None and self.preview_worker.is_alive():
            return
        key, source, destination, width, height = request
        if Path(destination).is_file():
            return
        if not self.root_path or not runtime_python(self.root_path).is_file():
            return
        workspace = self.root_path
        def work():
            success = False
            try:
                run_external([str(runtime_python(workspace)), str(Path(__file__).resolve()),
                              "--prepare-preview", str(workspace), source, destination,
                              str(width), str(height)], workspace, timeout=90,
                             env=shell_env(workspace, offline=True))
                success = Path(destination).is_file() and Path(destination).stat().st_size > 100
                if success:
                    prune_preview_cache(workspace)
            except (OSError, RuntimeError, ValueError, TimeoutError, InterruptedError):
                pass
            self.events.put(("preview_ready", key, success))
        self.preview_worker = threading.Thread(target=work, daemon=True)
        self.preview_worker.start()

    def draw_preview(self, event=None):
        canvas = self.preview_canvas
        canvas.delete("all")
        width = max(1, canvas.winfo_width())
        height = max(1, canvas.winfo_height())
        if self.preview_file and Path(self.preview_file).is_file():
            try:
                source = Path(self.preview_file)
                preview = None
                if self.root_path is not None:
                    destination = preview_thumbnail_path(self.root_path, source, width, height)
                    if destination.is_file():
                        preview = destination
                    elif str(destination) not in self.preview_failed_keys:
                        self.queue_preview_thumbnail(str(destination), source, destination, width, height)
                photo = self.tk.PhotoImage(file=str(preview or source))
                if preview is None:
                    stride = max(1, math.ceil(max(photo.width() / width, photo.height() / height)))
                    if stride > 1:
                        photo = photo.subsample(stride, stride)
                self.preview_photo = photo
                canvas.create_image(width // 2, height // 2, image=photo)
                return
            except (self.tk.TclError, OSError, ValueError):
                self.preview_photo = None
        canvas.create_oval(width // 2 - 28, height // 2 - 44, width // 2 + 28,
                           height // 2 + 12, outline=self.palette["stroke"], width=2)
        canvas.create_polygon(width // 2 - 5, height // 2 - 31, width // 2 + 15, height // 2 - 16,
                              width // 2 - 5, height // 2 - 1, fill=self.palette["muted"])
        canvas.create_text(width // 2, height // 2 + 42, text="等待第一幕画面", fill=self.palette["muted"],
                           font=(self.font_family, 10))

    def show_preview(self, filepath, caption=""):
        file = Path(filepath) if filepath else None
        if file and file.is_file() and file.suffix.lower() in {".png", ".gif", ".ppm", ".pgm"}:
            self.preview_file = str(file)
        else:
            self.preview_file = None
        if caption:
            self.preview_caption.configure(text=caption)
        self.draw_preview()

    def render_storyboard(self, title, scenes):
        self.scene_entries = [dict(scene, state="pending") for scene in scenes]
        self.scene_count.configure(text="共 %d 幕" % len(self.scene_entries))
        self.scene_row_start = 0
        self.render_scene_window(0)
        self.preview_caption.configure(text=title or "开始制作分镜")

    def render_scene_window(self, active):
        tk, p = self.tk, self.palette
        total = len(self.scene_entries)
        visible = min(total, UI_MAX_SCENE_ROWS)
        begin = max(0, min(max(0, total - visible), active - visible // 2))
        self.scene_row_start = begin
        for child in self.scene_rows_frame.winfo_children():
            child.destroy()
        self.scene_rows = []
        if not total:
            self.scene_empty_label = self.label(self.scene_rows_frame, "AI 完成分镜后显示镜头进度", 9,
                                                p["muted"], wraplength=340)
            self.scene_empty_label.pack(anchor="w")
            return
        for index in range(begin, begin + visible):
            scene = self.scene_entries[index]
            item = tk.Frame(self.scene_rows_frame, bg=p["surface"], padx=10, pady=9)
            item.pack(fill="x", pady=(0, 6))
            marker = self.label(item, "%02d" % (index + 1), 10, p["muted"], strong=True,
                                bg=p["surface"])
            marker.pack(side="left", padx=(0, 11))
            label = self.label(item, str(scene.get("narration", "待生成"))[:48], 9,
                               p["soft"], bg=p["surface"], wraplength=230)
            label.pack(side="left", fill="x", expand=True)
            state = self.label(item, "待生成", 8, p["muted"], bg=p["surface"])
            state.pack(side="right", padx=(5, 0))
            self.scene_rows.append((marker, label, state))
            self.paint_scene_row(index)
        self.scene_count.configure(text=("共%d幕 · 显示第%d–%d幕" % (total, begin + 1, begin + visible)
                                         if total > UI_MAX_SCENE_ROWS else "共%d幕" % total))
        self.root.after_idle(self.refresh_scrollregion)

    def paint_scene_row(self, index):
        local = index - self.scene_row_start
        if not 0 <= local < len(self.scene_rows):
            return
        marker, label, indicator = self.scene_rows[local]
        state = self.scene_entries[index].get("state", "pending")
        if state in {"active", "reviewing"}:
            marker.configure(fg=self.palette["accent"])
            label.configure(fg=self.palette["fg"])
            indicator.configure(text="AI 审校中" if state == "reviewing" else "生成中",
                                fg=self.palette["accent"])
        elif state == "done":
            uncertain = self.scene_entries[index].get("uncertain", False)
            color = self.palette["amber"] if uncertain else self.palette["green"]
            marker.configure(fg=color)
            indicator.configure(text="! 未通过" if uncertain else "✓ 已通过", fg=color)
        else:
            marker.configure(fg=self.palette["muted"])
            indicator.configure(text="待生成", fg=self.palette["muted"])

    def render_scene_state(self, index, state, preview=None, review=""):
        if not 0 <= index < len(self.scene_entries):
            return
        self.scene_entries[index]["state"] = state
        self.scene_entries[index]["uncertain"] = any(flag in review for flag in (
            "unreviewed", "supplied_conflict", "not_checked"))
        if not self.scene_row_start <= index < self.scene_row_start + len(self.scene_rows):
            self.render_scene_window(index)
        else:
            self.paint_scene_row(index)
        if state == "active":
            self.preview_state.configure(text="第 %d/%d 幕生成中" % (index + 1, len(self.scene_entries)),
                                         fg=self.palette["accent"])
        elif state == "reviewing":
            self.preview_state.configure(text="第 %d 幕 AI 审校中" % (index + 1), fg=self.palette["accent"])
        elif state == "done":
            uncertain = self.scene_entries[index]["uncertain"]
            color = self.palette["amber"] if uncertain else self.palette["green"]
            self.preview_state.configure(text="第 %d 幕 · %s" % (
                index + 1, "未通过全部审校" if uncertain else "审校通过"), fg=color)
            if preview:
                self.show_preview(preview, "第 %d 幕 · %s" % (index + 1, review or "检查完成"))

    def render_task_state(self, phase):
        order = ("preparing", "planning", "rendering", "finishing")
        self.current_phase = phase
        current = order.index(phase) if phase in order else (-1 if phase == "idle" else len(order))
        for index, key in enumerate(order):
            marker, label = self.phase_widgets[key]
            if index < current:
                marker.configure(text="✓", fg=self.palette["green"])
                label.configure(fg=self.palette["soft"])
            elif index == current:
                marker.configure(text="●", fg=self.palette["accent"])
                label.configure(fg=self.palette["fg"])
            else:
                marker.configure(text="○", fg=self.palette["muted"])
                label.configure(fg=self.palette["muted"])
        if phase == "complete":
            self.preview_state.configure(text="创作完成", fg=self.palette["green"])
        elif phase == "idle":
            self.preview_state.configure(text="等待创作", fg=self.palette["muted"])

    def show_result_panel(self, output):
        self.result_card.pack(fill="x", pady=(0, 12))
        self.result_card.winfo_children()[0].configure(text="作品已完成", fg=self.palette["green"])
        data = read_json(output.parent / "manifest.json", {})
        width, height = (data.get("resolution") or [0, 0])[:2]
        seconds = data.get("duration", 0)
        scenes = data.get("scene_count", len(self.scene_entries))
        methods = data.get("render_strategy_counts", {})
        if not isinstance(methods, dict):
            methods = {}
        styles = []
        for key, label in (("native_temporal_diffusion", "原生 AI 动态镜头"),
                           ("supplied_video_edit", "用户视频剪辑"),
                           ("generated_still_camera_motion", "AI 图片运镜"),
                           ("supplied_still_camera_motion", "用户图片运镜")):
            if methods.get(key, 0):
                styles.append("%s %d 幕" % (label, methods[key]))
        text = "%s × %s  ·  %.1f 秒  ·  %s 幕\n%s\n画面方式：%s" % (
            width or "?", height or "?", float(seconds), scenes, str(output),
            "；".join(styles) if styles else "见交付清单")
        warnings = data.get("warnings") or []
        if warnings:
            text += "\n提醒：" + str(warnings[0])[:120]
        self.result_info.configure(text=text)
        cover = output.parent / "cover.png"
        if cover.is_file():
            self.show_preview(cover, "成片封面 · 已完成技术校验")

    def show_job_error(self, message):
        self.result_card.pack(fill="x", pady=(0, 12))
        self.result_card.winfo_children()[0].configure(text="任务未完成", fg=self.palette["danger"])
        self.result_info.configure(text=str(message)[:280] + "\n可使用黑匣子保存脱敏故障报告。")
        self.preview_state.configure(text="需要处理", fg=self.palette["danger"])

    def clear_example(self, event):
        current = self.prompt_box.get("1.0", "end-1c").strip()
        if current.startswith("例："):
            self.prompt_box.delete("1.0", "end")

    def add_assets(self):
        if self.task not in (None, "部署") or self.blackbox_active:
            return
        patterns = ("*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff "
                    "*.wav *.mp3 *.flac *.m4a *.aac *.ogg *.wma "
                    "*.mp4 *.mov *.mkv *.avi *.webm *.m4v "
                    "*.txt *.md *.csv *.json *.pdf *.docx *.html *.htm *.srt")
        selected = self.filedialog.askopenfilenames(title="选择图片、视频、音频或文档",
                                                    filetypes=[("支持的素材", patterns), ("所有文件", "*.*")])
        if not selected:
            return
        ignored = []
        for filename in selected:
            extension = Path(filename).suffix.lower()
            if extension in IMAGE_TYPES:
                kind = "图片"
            elif extension in VIDEO_TYPES:
                kind = "视频"
            elif extension in AUDIO_TYPES:
                kind = "音频"
            elif extension in DOC_TYPES:
                kind = "文档"
            else:
                ignored.append(Path(filename).name)
                continue
            if filename not in self.assets[kind] and filename not in self.assets["首帧"] + self.assets["尾帧"]:
                self.assets[kind].append(filename)
        self.refresh_asset_label()
        if ignored:
            self.messagebox.showwarning(APP_NAME, "部分文件格式未被支持：\n" + "、".join(ignored[:5]))

    def refresh_asset_label(self):
        if not hasattr(self, "asset_rows_frame"):
            return
        for widget in self.asset_rows_frame.winfo_children():
            widget.destroy()
        entries = [(kind, file) for kind, paths in self.assets.items() for file in paths]
        total = len(entries)
        self.assets_label.configure(text="已添加 %d 份素材 · 可继续补充" % total if total else
                                    "可选：图片、视频、音频、文档，也可以指定首尾帧")
        if not total:
            empty = self.label(self.asset_rows_frame, "尚未添加参考素材", 9,
                               self.palette["muted"])
            empty.pack(anchor="w", pady=(2, 1))
        icons = {"首帧": "▣", "尾帧": "▣", "图片": "▧", "视频": "▶", "音频": "♫", "文档": "▤"}
        for kind, filename in entries[:UI_MAX_ASSET_ROWS]:
            row = self.tk.Frame(self.asset_rows_frame, bg=self.palette["surface"], padx=9, pady=7)
            row.pack(fill="x", pady=(0, 5))
            self.label(row, icons.get(kind, "●"), 11, self.palette["accent"],
                       bg=self.palette["surface"]).pack(side="left", padx=(0, 9))
            title = Path(filename).name
            self.label(row, title if len(title) <= 34 else title[:16] + "…" + title[-14:], 9,
                       self.palette["soft"], bg=self.palette["surface"]).pack(side="left", fill="x", expand=True)
            self.label(row, kind, 8, self.palette["muted"],
                       bg=self.palette["surface"]).pack(side="right", padx=(8, 0))
        if total > UI_MAX_ASSET_ROWS:
            self.label(self.asset_rows_frame, "还有 %d 份素材 · 点击上方管理按钮查看" %
                       (total - UI_MAX_ASSET_ROWS), 9, self.palette["muted"]).pack(anchor="w", pady=(3, 0))
        if hasattr(self, "recommendation_label"):
            self.schedule_recommendations()

    def manage_assets(self):
        if self.task not in (None, "部署") or self.blackbox_active:
            return
        entries = [(kind, file) for kind, paths in self.assets.items() for file in paths]
        if not entries:
            self.add_assets()
            return
        dialog = self.tk.Toplevel(self.root)
        dialog.title("管理参考素材")
        dialog.transient(self.root)
        dialog.configure(bg=self.palette["panel"])
        dialog.geometry("%dx%d" % (min(720, max(430, self.root.winfo_width() - 160)),
                                     min(460, max(320, self.root.winfo_height() - 170))))
        self.label(dialog, "素材清单", 13, strong=True).pack(anchor="w", padx=16, pady=(14, 8))
        picker = self.tk.Listbox(dialog, selectmode="extended", exportselection=False, borderwidth=0,
                                 highlightthickness=1, highlightbackground=self.palette["stroke"],
                                 bg=self.palette["input"], fg=self.palette["fg"],
                                 selectbackground=self.palette["accent_bg"],
                                 font=(self.font_family, 10), activestyle="none")
        picker.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        def populate():
            entries[:] = [(kind, file) for kind, paths in self.assets.items() for file in paths]
            picker.delete(0, "end")
            for kind, filename in entries:
                picker.insert("end", "[%s]  %s" % (kind, Path(filename).name))
        def remove_selected():
            for index in sorted(picker.curselection(), reverse=True):
                kind, file = entries[index]
                self.assets[kind].remove(file)
            populate()
            self.refresh_asset_label()
        def set_boundary(which):
            selected = picker.curselection()
            if len(selected) != 1:
                self.messagebox.showinfo(APP_NAME, "请先选中一张图片")
                return
            kind, file = entries[selected[0]]
            if Path(file).suffix.lower() not in IMAGE_TYPES:
                self.messagebox.showinfo(APP_NAME, "首帧和尾帧只能指定图片")
                return
            previous = list(self.assets[which])
            if file in self.assets["图片"]:
                self.assets["图片"].remove(file)
            self.assets[which] = [file]
            if previous and previous[0] != file:
                old = previous[0]
                if old not in self.assets["图片"] and old not in self.assets["首帧"] + self.assets["尾帧"]:
                    self.assets["图片"].append(old)
            populate()
            self.refresh_asset_label()
        actions = self.tk.Frame(dialog, bg=self.palette["panel"])
        actions.pack(fill="x", padx=16, pady=(0, 15))
        self.ttk.Button(actions, text="设为首帧", style="Small.TButton",
                        command=lambda: set_boundary("首帧")).pack(side="left", padx=(0, 7))
        self.ttk.Button(actions, text="设为尾帧", style="Small.TButton",
                        command=lambda: set_boundary("尾帧")).pack(side="left", padx=(0, 7))
        self.ttk.Button(actions, text="移除选中", style="Small.TButton",
                        command=remove_selected).pack(side="left")
        self.ttk.Button(actions, text="完成", style="Small.TButton",
                        command=dialog.destroy).pack(side="right")
        populate()
        dialog.grab_set()

    def select_workspace(self):
        if (self.task or self.blackbox_active or self.setup_active or
                (self.native_auto_thread is not None and self.native_auto_thread.is_alive())):
            self.messagebox.showinfo(APP_NAME, "后台正在处理模型或任务，暂不能切换工作目录")
            return
        selected = self.filedialog.askdirectory(title="请选择保存模型、素材和成品的文件夹", mustexist=True)
        if not selected:
            if not self.root_path:
                self.set_status("请选择工作目录才能开始")
            return
        root = Path(selected).resolve()
        if root == self.root_path:
            self.update_setup()
            return
        if os.name == "nt" and len(str(root)) + MIN_WORKSPACE_PATH_MARGIN >= 240:
            self.messagebox.showerror(APP_NAME, "路径层级过深，模型内部文件可能超过 Windows 默认长度限制。\n"
                                      "请选择更浅的工作目录，如 D:\\AI工坊")
            return
        cloud_roots = [Path(os.environ[key]) for key in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer")
                       if os.environ.get(key)]
        if any(root == cloud or cloud in root.parents for cloud in cloud_roots):
            self.messagebox.showwarning(APP_NAME, "当前目录属于 OneDrive 同步区。模型可能被云端占位或同步锁定，"
                                        "建议改用普通本地目录。若继续，请确保始终保留离线副本。")
        new_lock = None
        try:
            test = root / (".studio_write_check_" + secrets.token_hex(8))
            test.write_bytes(b"OK")
            test.unlink()
            new_lock = WorkspaceLock(root)
        except Exception as error:
            if new_lock:
                new_lock.close()
            self.messagebox.showerror(APP_NAME, "此目录不可写，请换一个目录：\n" + str(error))
            return
        if self.workspace_lock is not None:
            self.workspace_lock.close()
        self.workspace_lock = new_lock
        self.root_path = root
        self.pending_start_request = None
        self.last_output = None
        self.deployment_retry = 0
        self.ready = False
        self.basic_ready = False
        self.capabilities = {}
        self.result_card.pack_forget()
        self.preview_file = None
        self.preview_photo = None
        self.preview_caption.configure(text="分镜完成后，画面会逐幕出现在这里")
        self.draw_preview()
        self.folder_label.configure(text="工作目录  ·  " + str(root))
        self.update_setup()

    def log(self, message):
        message = str(message).strip()
        if not message:
            return
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        self.events.put(("log", timestamp + "  " + message[:1100]))
        if self.root_path:
            try:
                with self.log_lock:
                    file = self.root_path / ".studio" / "logs" / "studio.log"
                    if file.exists() and file.stat().st_size > 7 * 1024 * 1024:
                        rotated = file.with_suffix(".previous.log")
                        if rotated.exists():
                            rotated.unlink()
                        file.rename(rotated)
                    with file.open("a", encoding="utf-8") as handle:
                        handle.write("[%s] %s\n" % (datetime.datetime.now().isoformat(), message))
            except OSError:
                pass

    def set_status(self, message, progress=None):
        self.events.put(("status", message, progress))
        self.log(message)

    def refresh_buttons(self):
        busy = self.task not in (None, "部署") or self.blackbox_active
        self.start_btn.configure(state="normal" if self.root_path and not busy and
                                 self.pending_start_request is None else "disabled")
        self.black_btn.configure(state="normal" if self.root_path and not self.blackbox_active else "disabled")
        self.prompt_box.configure(state="normal" if not busy else "disabled")

    def update_capability_label(self):
        if not hasattr(self, "capability_label"):
            return
        flags = self.capabilities if isinstance(self.capabilities, dict) else {}
        pieces = [("基础依赖已验收", flags.get("basic")),
                  ("离线联合验收", flags.get("offline_pipeline_verified")),
                  ("AI生图与运镜", flags.get("image_generation")),
                  ("语义与语音审核", flags.get("semantic_review") and flags.get("speech_review"))]
        label = "  ·  ".join(("✓ " if ok else "○ ") + text for text, ok in pieces)
        native_status = ("可用" if flags.get("native_video") else
                         "已实测·显存不足" if flags.get("native_inference_verified") else
                         "模型待实测" if flags.get("native_model_detected") else
                         "模型待校验" if flags.get("native_model_present") else "未部署")
        label += "  ·  " + ("✓ " if flags.get("native_video") else "○ ") + "原生时序视频：" + native_status
        label += "  ·  " + ("✓ 可离线开始" if flags.get("create_allowed") else "○ 仍在部署或验收")
        self.capability_label.configure(text=label, fg=self.palette["soft"])


    def request_capabilities_cached(self, request):
        flags = dict(self.capabilities) if isinstance(self.capabilities, dict) else {}
        files = request.get("files", {}) if isinstance(request, dict) else {}
        flags["visual_assets"] = bool(any(files.get(kind) for kind in ("图片", "首帧", "尾帧", "视频")))
        flags["native_requested"] = str(request.get("visual_mode", "")).startswith("原生AI视频")
        compatible, reason = native_input_compatibility(flags.get("native_model_class"), request)
        flags["native_input_compatible"] = compatible
        flags["native_input_reason"] = reason
        flags["create_allowed"] = bool(flags.get("full_offline"))
        return flags

    def emit_setup_done(self, completed, message):
        try:
            flags = capability_report(self.root_path)
        except Exception as error:
            self.log("部署结束时能力检查未完成：" + str(error)[:180])
            flags = {}
        self.events.put(("setup_done", completed, message, flags))

    def update_setup(self):
        if not self.root_path or self.task or self.blackbox_active or self.setup_active:
            return
        self.install_stop.clear()
        self.task = "部署"
        self.setup_active = True
        self.force_integrity_scan = False
        self.setup_progress["value"] = 0
        self.ready_badge.configure(text="● 正在检查离线创作环境", fg=self.palette["amber"])
        self.set_status("正在后台检查本地创作环境", 1)
        self.refresh_buttons()
        self.setup_thread = threading.Thread(target=self.setup_worker, daemon=True)
        self.setup_thread.start()

    def verify_packages(self, tier, needs_piper=False):
        result = run_external([str(runtime_python(self.root_path)), str(Path(__file__).resolve()),
                               "--verify-packages", str(self.root_path), tier,
                               "piper" if needs_piper else "system"], self.root_path,
                              timeout=240, cancel=self.install_stop,
                              env=shell_env(self.root_path, offline=True), capture=True)
        for line in reversed(result.splitlines()):
            try:
                value = json.loads(line)
                if value.get("ok") and value.get("tier") == tier and all(
                        name in value.get("imports", {}) for name in required_imports(tier, needs_piper)):
                    return value
            except (ValueError, TypeError, AttributeError):
                continue
        raise RuntimeError("实际导入的组件不完整，不能跳过安装")

    def install_dependencies(self, needs_piper=False, tier="basic"):
        root = self.root_path
        folder = root / ".studio"
        active = folder / "venv"
        backup = folder / RUNTIME_BACKUP_FOLDER
        staging = folder / (RUNTIME_BACKUP_FOLDER + ".creating")
        marker = folder / "packages_ready.json"
        marker_backup = folder / RUNTIME_MARKER_BACKUP
        transaction = folder / "install_transaction.json"
        if backup.is_dir():
            recover_runtime_transaction(root)
            self.log("检测到部署中断，已恢复上一次验证过的 Python 环境")
        if staging.is_dir():
            shutil.rmtree(staging)
        if packages_healthy(root, tier, needs_piper):
            try:
                self.verify_packages(tier, needs_piper)
                if not cuda_install_expectation(root):
                    return
                self.log("已安装PyTorch仅能使用CPU且检测到可升级的NVIDIA环境，准备尝试CUDA计算引擎")
            except InterruptedError:
                raise
            except Exception as error:
                self.log("独立运行库需要修复：" + str(error)[:230])
        previous_tier = None
        if active.is_dir():
            for candidate in ("full", "basic"):
                if not packages_healthy(root, candidate, False):
                    continue
                try:
                    self.verify_packages(candidate, False)
                    previous_tier = candidate
                    break
                except InterruptedError:
                    raise
                except Exception as error:
                    self.log("旧组件未通过导入验收，需要重建：" + str(error)[:230])
        budget = installation_disk_budget(root, tier, needs_piper, replacement=not bool(previous_tier))
        if budget["free"] < budget["required"]:
            raise RuntimeError("安装空间不足：本阶段预计需要 %.1f GB，可用 %.1f GB。请更换工作目录或使用离线依赖包" % (
                budget["required"] / GB, budget["free"] / GB))
        preserved = active.is_dir()
        transaction_state = "incremental" if previous_tier else "fresh_or_repair"
        if preserved:
            marker_backup.unlink(missing_ok=True)
            if marker.is_file():
                shutil.copy2(marker, marker_backup)
            try:
                if previous_tier:
                    self.set_status("复用已验收组件，准备安全增量升级", 8)
                    shutil.copytree(active, staging, copy_function=runtime_snapshot_copy)
                    os.replace(staging, backup)
                    self.log("已保存可回滚快照，增量补齐组件而不重新下载 PyTorch")
                else:
                    os.replace(active, backup)
                    self.log("旧环境未通过验收，已隔离保存，准备重新部署")
            except BaseException:
                if staging.is_dir():
                    shutil.rmtree(staging)
                if backup.is_dir():
                    recover_runtime_transaction(root)
                marker_backup.unlink(missing_ok=True)
                raise
        atomic_json(transaction, {"started": now_stamp(), "tier": tier,
                                  "mode": transaction_state, "stage": "installing",
                                  "baseline": previous_tier, "rollback_available": preserved})
        try:
            self._install_dependencies_in_place(needs_piper, tier)
            if not runtime_matches_host(root) or not packages_healthy(root, tier, needs_piper):
                raise RuntimeError("升级环境的 Python 版本或依赖完整性不合格")
            self.verify_packages(tier, needs_piper)
            if previous_tier and (not packages_healthy(root, previous_tier, False)):
                raise RuntimeError("升级损坏了原有的 %s 离线能力，自动恢复旧环境" % previous_tier)
            if previous_tier:
                self.verify_packages(previous_tier, False)
        except BaseException as error:
            atomic_json(transaction, {"checked": now_stamp(), "tier": tier, "mode": transaction_state,
                                      "stage": "rollback", "baseline": previous_tier,
                                      "error_type": type(error).__name__})
            if preserved and backup.is_dir():
                recover_runtime_transaction(root)
                self.log("已恢复原运行环境与依赖清单，原有离线能力不受失败升级影响")
            else:
                if active.exists():
                    shutil.rmtree(active)
                marker.unlink(missing_ok=True)
                marker_backup.unlink(missing_ok=True)
            raise
        else:
            if backup.exists():
                shutil.rmtree(backup)
            marker_backup.unlink(missing_ok=True)
            atomic_json(transaction, {"checked": now_stamp(), "tier": tier, "mode": transaction_state,
                                      "stage": "verified", "baseline": previous_tier,
                                      "rollback_available": False})

    def _install_dependencies_in_place(self, needs_piper=False, tier="basic"):
        root = self.root_path
        python = runtime_python(root)
        site = runtime_site(root)
        marker = root / ".studio" / "packages_ready.json"
        prior = read_json(marker, {})
        unhealthy = False
        if packages_healthy(root, tier, needs_piper):
            try:
                self.verify_packages(tier, needs_piper)
                detected = gpu_info(root)
                gpu_preferred = (detected.get("total_mb", 0) >= CUDA_MIN_TOTAL_MB or
                                 any(item.get("detected_without_smi") for item in detected.get("devices", [])))
                compute = torch_runtime_probe(root)
                if gpu_preferred and not compute.get("cuda_compute"):
                    self.log("已安装计算引擎无法在 NVIDIA 显卡上完成 CUDA 张量计算，自动尝试修复GPU环境")
                elif compute:
                    self.log("%s组件已通过真实导入检查，复用已有离线环境" %
                             ("基础" if tier == "basic" else "扩展"))
                    return
                else:
                    unhealthy = True
                    self.log("原有 PyTorch 张量计算未验收，将自动修复计算引擎")
            except InterruptedError:
                raise
            except Exception as error:
                unhealthy = True
                self.log("发现运行库损坏或依赖冲突，将自动修复：" + str(error)[:260])
        if not python.is_file():
            self.set_status("创建工作目录内的独立 Python 环境", 4)
            run_external([sys.executable, "-m", "venv", str(root / ".studio" / "venv")], root,
                         log=self.log, cancel=self.install_stop, timeout=180, capture=True)
        if not python.is_file():
            raise RuntimeError("无法创建独立 Python 环境，请检查 Python 是否包含 venv 组件")
        try:
            run_external([str(python), "-m", "pip", "--version"], root, timeout=35,
                         cancel=self.install_stop, capture=True)
        except InterruptedError:
            raise
        except Exception:
            run_external([str(python), "-m", "ensurepip", "--upgrade"], root, timeout=120,
                         cancel=self.install_stop, capture=True)
        offline_wheels = root / ".studio" / "offline_wheels"
        local_wheels = offline_wheels.is_dir() and any(offline_wheels.glob("*.whl"))
        source_options = ("https://pypi.tuna.tsinghua.edu.cn/simple", "https://pypi.org/simple")
        timings = {}
        workers = []
        if not local_wheels:
            self.set_status("检测可用的依赖安装线路", 5)
            def probe(item):
                timings[item] = probe_url(item + "/pillow/", 4)
            for item in source_options:
                thread = threading.Thread(target=probe, args=(item,), daemon=True)
                thread.start()
                workers.append(thread)
            for thread in workers:
                thread.join(5)
        indexes = sorted(source_options, key=lambda address: timings.get(address, float("inf")))
        base = [str(python), "-m", "pip", "install", "--disable-pip-version-check", "--no-input",
                "--prefer-binary", "--only-binary=:all:"]
        env = shell_env(root)
        env["PIP_DEFAULT_TIMEOUT"] = "35"
        env["PIP_RETRIES"] = "2"
        detected_gpu = gpu_info(root)
        gpu_preferred = cuda_install_expectation(root)
        torch_ok = (site / "torch").is_dir() and bool(list(site.glob("torch-*.dist-info")))
        if torch_ok:
            inspected = torch_runtime_probe(root)
            torch_ok = bool(inspected and (not gpu_preferred or inspected.get("cuda_compute")))
            if not inspected:
                self.log("现有 PyTorch 未通过真实张量计算验证，准备修复")
            elif gpu_preferred and not inspected.get("cuda_compute"):
                self.log("检测到NVIDIA显卡但现有 PyTorch 仅能在CPU上工作，尝试安装兼容CUDA版本")
        if not torch_ok:
            torch_error = None
            torch_sources = ([ ("本地安装包", str(offline_wheels), False) ] if local_wheels else [])
            torch_sources += torch_install_sources(detected_gpu, indexes)
            for label, source, wants_cuda in torch_sources:
                try:
                    self.set_status("安装 AI 计算引擎 · " + label, 10)
                    extra = ["--force-reinstall"] if (site / "torch").exists() else []
                    source_args = (["--no-index", "--find-links", source] if label == "本地安装包"
                                   else ["--index-url", source])
                    run_external(base + extra + source_args + ["torch==" + TORCH_VERSION], root,
                                 log=self.log, cancel=self.install_stop, timeout=2600, env=env, capture=True)
                    script = ("import torch; assert torch.__version__.split('+')[0]=='" + TORCH_VERSION + "'; "
                              "device='cuda' if " + str(wants_cuda) + " else 'cpu'; "
                              "x=torch.ones(2,device=device); print(device, float(x.sum().item()))")
                    run_external([str(python), "-c", script], root, timeout=150,
                                 cancel=self.install_stop, env=shell_env(root, offline=True), capture=True)
                    tested = torch_runtime_probe(root)
                    if not tested or wants_cuda and not tested.get("cuda_compute"):
                        raise RuntimeError("PyTorch安装后 CUDA 实际张量计算未通过")
                    if gpu_preferred and not wants_cuda:
                        self.log("已尝试可支持的CUDA安装线路，但本机未通过GPU实际运算；保留明确标注的CPU计算路径")
                    record_cuda_fallback(root, detected_gpu, bool(gpu_preferred and not tested.get("cuda_compute")))
                    RUNTIME_CUDA_CACHE.pop(str(Path(root).resolve()), None)
                    torch_error = None
                    break
                except InterruptedError:
                    raise
                except Exception as error:
                    torch_error = error
                    kind, hint = installation_failure_hint(error)
                    self.log("计算引擎安装失败（%s），尝试其它线路：%s；%s" % (kind, str(error)[:240], hint))
            if torch_error:
                raise RuntimeError("计算引擎无法安装：" + str(torch_error))
        packages = list(CORE_PACKAGE_SPECS)
        if tier == "full":
            packages += list(EXTENDED_PACKAGE_SPECS)
        if needs_piper:
            packages += list(VOICE_PACKAGES)
        sources = ([ ("本地依赖包", ["--no-index", "--find-links", str(offline_wheels)]) ]
                   if local_wheels else [])
        sources += [(index, ["--index-url", index]) for index in indexes]
        last_error = None
        used_source = None
        for label, source_args in sources:
            try:
                self.set_status("安装%s离线组件 · %s" % ("基础" if tier == "basic" else "扩展", label), 12)
                self.log("依赖源：" + label)
                if unhealthy:
                    run_external(base + ["--force-reinstall", "--no-deps"] + source_args + packages,
                                 root, log=self.log, cancel=self.install_stop,
                                 timeout=3600, env=env, capture=True)
                run_external(base + source_args + packages, root, log=self.log,
                             cancel=self.install_stop, timeout=3600, env=env, capture=True)
                self.verify_packages(tier, needs_piper)
                run_external([str(python), "-m", "pip", "check"], root, timeout=120,
                             cancel=self.install_stop, env=shell_env(root, offline=True), capture=True)
                last_error = None
                used_source = label
                break
            except InterruptedError:
                raise
            except Exception as error:
                last_error = error
                kind, hint = installation_failure_hint(error)
                self.log("依赖线路安装或导入失败（%s），尝试其它线路：%s；%s" % (kind, str(error)[:300], hint))
        if last_error:
            raise RuntimeError("离线组件安装或依赖检查失败：" + str(last_error))
        if tier == "full" and not optional_ocr_ready(root):
            ocr_installed = False
            for label, source_args in sources:
                try:
                    self.set_status("尝试安装可选扫描件 OCR · " + label, 14)
                    run_external(base + source_args + list(OPTIONAL_OCR_PACKAGE_SPECS) +
                                 ["numpy>=1.26,<2.3"], root, log=self.log, cancel=self.install_stop,
                                 timeout=1300, env=env, capture=True)
                    output = run_external([str(python), str(Path(__file__).resolve()),
                                           "--verify-packages", str(root), "ocr", "system"],
                                          root, cancel=self.install_stop, timeout=180,
                                          env=shell_env(root, offline=True), capture=True)
                    if not any('"tier": "ocr"' in line and '"ok": true' in line.lower()
                               for line in output.splitlines()):
                        raise RuntimeError("OCR 功能实际导入检查没有通过")
                    run_external([str(python), "-m", "pip", "check"], root, cancel=self.install_stop,
                                 timeout=120, env=shell_env(root, offline=True), capture=True)
                    versions = installed_package_versions(root)
                    atomic_json(root / ".studio" / "ocr_ready.json",
                                {"runtime_version": RUNTIME_VERSION,
                                 "python": list(sys.version_info[:2]),
                                 "versions": {name: versions.get(name) for name in OPTIONAL_OCR_PACKAGE_IMPORTS},
                                 "completed": now_stamp(), "source": label})
                    ocr_installed = True
                    break
                except InterruptedError:
                    raise
                except Exception as error:
                    self.log("扫描件 OCR 属于可选能力，此安装线路未成功：" + str(error)[:260])
            if not ocr_installed:
                (root / ".studio" / "ocr_ready.json").unlink(missing_ok=True)
                raise RuntimeError("离线文字OCR无法完成验收，精准画面文字及扫描文档不能可靠审校")
            self.verify_packages(tier, needs_piper)
        previously_valid = prior.get("runtime_version") == RUNTIME_VERSION
        tiers = dict(prior.get("tiers", {})) if previously_valid else {}
        tiers[tier] = True
        if tier == "full":
            tiers["basic"] = True
        signatures = package_sentinels(root, tier, needs_piper)
        if not signatures:
            raise RuntimeError("组件安装后缺少关键模块，无法记录完整性标记")
        locked = installed_package_versions(root)
        pinned = {name: locked.get(name) for name in required_imports(tier, needs_piper)}
        if any(not value for value in pinned.values()):
            raise RuntimeError("组件安装后版本信息缺失")
        atomic_json(marker, {"runtime_version": RUNTIME_VERSION, "python": list(sys.version_info[:2]),
                             "time": now_stamp(), "source": used_source, "piper": needs_piper,
                             "tiers": tiers, "versions": locked, "sentinels": signatures})

    def prepare_native_automatically(self):
        root = self.root_path
        if self.native_stop.is_set() or self.task == "创作":
            return
        pending = self.pending_start_request or {"files": self.assets, "prompt": ""}
        existing = native_video_model(root)
        compatible = native_input_compatibility(existing[1], pending)[0] if existing else False
        if existing and (compatible or not (explicit_native_requested(pending.get("prompt", "")) or
                                            requires_subject_motion(pending.get("prompt", "")))):
            return
        gpu = gpu_info(root)
        power = system_power_state()
        network_cost = windows_network_cost()
        if network_cost["known"] and network_cost["metered"]:
            self.log("当前网络已确认按流量计费，暂停原生模型自动下载以保护流量")
            return
        available_memory = memory_info().get("available", 0)
        if (gpu.get("total_mb", 0) < NATIVE_AUTO_MIN_TOTAL_MB or
                gpu.get("free_mb", 0) < NATIVE_VIDEO_MIN_FREE_MB or
                available_memory < NATIVE_AUTO_MIN_RAM or power.get("on_battery")):
            self.log("优先保障轻量离线创作，当前不下载大型原生视频模型")
            return
        record_file = root / ".studio" / "native_auto.json"
        previous = read_json(record_file, {})
        try:
            last = datetime.datetime.fromisoformat(previous.get("checked", ""))
            recently_attempted = (datetime.datetime.now() - last).total_seconds() < NATIVE_AUTO_RETRY_SECONDS
        except (ValueError, TypeError):
            recently_attempted = False
        if (recently_attempted and self.pending_start_request is None and previous.get("status") in {
                "download_failed", "insufficient_disk", "network_unavailable", "resource_paused"}):
            self.log("大型视频模型沿用最近的环境检测结果，避免反复占用网络")
            return
        disk = shutil.disk_usage(root).free
        needs_images = any(pending.get("files", {}).get(kind) for kind in ("图片", "首帧", "尾帧"))
        profile = select_native_profile(gpu=gpu, disk_free=disk, needs_images=needs_images)
        if profile is None:
            cached = select_native_profile(gpu=gpu, needs_images=needs_images)
            if (cached and native_video_folder_complete(
                    model_path(root, VIDEO_MODEL_FOLDER).with_name(VIDEO_MODEL_FOLDER + ".cached." + cached["id"]))):
                profile = cached
            else:
                atomic_json(record_file, {"checked": datetime.datetime.now().isoformat(),
                                          "status": "insufficient_disk"})
                self.log("原生模型部署最低磁盘余量不足，等待磁盘空间释放")
                return
        endpoints = choose_endpoints()
        cached_path = model_path(root, VIDEO_MODEL_FOLDER).with_name(VIDEO_MODEL_FOLDER + ".cached." + profile["id"])
        if native_video_folder_complete(cached_path):
            download_native_worker(root, endpoints[0] if endpoints else "https://huggingface.co", profile["id"])
            self.log("从工作目录内的已验收模型缓存切换到当前素材兼容的生成管线")
            return
        accessible = []
        for item in endpoints:
            checks = [probe_url(item + "/api/models/" + repo, timeout=3)
                      for repo, _ in profile["repos"]]
            if all(math.isfinite(latency) for latency in checks):
                accessible.append((sum(checks), item))
        accessible = [item for _, item in sorted(accessible)]
        if not accessible:
            atomic_json(record_file, {"checked": datetime.datetime.now().isoformat(),
                                      "status": "network_unavailable"})
            self.log("无法连接原生模型下载仓库，保留已完成的下载部分，待网络恢复重试")
            return
        self.log("设备已识别：自动选择 %s，按文件摘要校验并续传真正的原生时序视频模型" % profile["id"])
        errors = []
        for endpoint in accessible:
            if self.native_stop.is_set() or self.task == "创作":
                raise InterruptedError("已暂停大型模型的可选部署")
            current_power = system_power_state()
            ram = memory_info().get("available", 0)
            disk = shutil.disk_usage(root).free
            if (current_power.get("on_battery") or ram < NATIVE_AUTO_MIN_RAM or
                    disk < NATIVE_AUTO_DISK_RESERVE + MIN_INSTALL_FREE or
                    (lambda cost: cost.get("known") and cost.get("metered"))(windows_network_cost())):
                atomic_json(record_file, {"checked": datetime.datetime.now().isoformat(),
                                          "status": "resource_paused"})
                self.log("检测到电池供电、按流量计费网络或系统资源不足，主动暂停可选大型模型下载")
                return
            try:
                run_external([str(runtime_python(root)), str(Path(__file__).resolve()),
                              "--fetch-native", str(root), endpoint, profile["id"]], root, log=self.log,
                             cancel=self.native_stop, timeout=7200,
                             env=shell_env(root, endpoint=endpoint))
                if native_video_model(root):
                    atomic_json(record_file, {"checked": datetime.datetime.now().isoformat(),
                                              "status": "downloaded", "source": endpoint})
                    return
            except InterruptedError:
                raise
            except Exception as error:
                errors.append(str(error)[:220])
                self.log("原生模型下载线路不可用，尝试其它线路：" + errors[-1])
        atomic_json(record_file, {"checked": datetime.datetime.now().isoformat(),
                                  "status": "download_failed", "error_types": [
                                      diagnostic_exception_summary(item)["exception_type"] for item in errors]})
        self.log("原生模型下载暂未成功，已保留断点；不会使用图片运镜冒充原生视频")

    def prepare_optional_automatically(self):
        root = self.root_path
        if self.native_stop.is_set() or self.task == "创作" or system_power_state().get("on_battery"):
            return
        cost = windows_network_cost()
        if cost.get("known") and cost.get("metered"):
            self.log("增强模型不在按流量计费的网络中自动下载")
            return
        endpoints = choose_endpoints()
        for profile in OPTIONAL_MODEL_CATALOG:
            if self.native_stop.is_set() or self.task == "创作":
                raise InterruptedError("为用户创作让出资源")
            role = profile["role"]
            if optional_model_verified(model_path(root, OPTIONAL_MODEL_FOLDERS[role]), role):
                continue
            ram = memory_info()
            gpu = gpu_info(root)
            disk = shutil.disk_usage(root).free
            usable = max(0, ram.get("available", 0) - max(MIN_SYSTEM_MEMORY_HEADROOM,
                         int(ram.get("total", 0) * SYSTEM_MEMORY_RESERVE_FRACTION)))
            if (usable < profile["min_free_ram"] or
                    gpu.get("free_mb", 0) < profile["min_free_gpu_mb"] or
                    disk < MIN_INSTALL_FREE + MIN_JOB_FREE +
                    int(profile["download_estimate"] * DOWNLOAD_SPACE_MULTIPLIER)):
                continue
            if system_power_state().get("on_battery"):
                return
            errors = []
            for endpoint in endpoints:
                if self.native_stop.is_set():
                    raise InterruptedError("可选模型部署暂停")
                try:
                    self.log("发现空闲硬件资源，正在自动准备增强模型：" + role)
                    run_external([str(runtime_python(root)), str(Path(__file__).resolve()),
                                  "--fetch-optional", str(root), role, endpoint], root,
                                 cancel=self.native_stop, timeout=14400,
                                 env=shell_env(root, endpoint=endpoint))
                    if optional_model_verified(model_path(root, OPTIONAL_MODEL_FOLDERS[role]), role):
                        self.log("增强模型已校验并缓存：" + role)
                        break
                except InterruptedError:
                    raise
                except (RuntimeError, OSError, ValueError, TimeoutError) as error:
                    errors.append(type(error).__name__ + ": " + str(error)[:120])
            if not optional_model_verified(model_path(root, OPTIONAL_MODEL_FOLDERS[role]), role):
                self.log("增强模型 %s 暂不可用，保留基础模型与下载断点：%s" % (
                    role, " / ".join(errors[-2:])[:230]))

    def validate_optional_native(self):
        root = self.root_path
        if not native_video_model(root) or native_inference_ready(root):
            return
        if self.native_stop.is_set() or self.task == "创作":
            return
        marker = read_json(root / ".studio" / "native_ready.json", {})
        if native_load_ready(root) and marker.get("smoke_status") == REVIEW_UNAVAILABLE:
            try:
                checked = datetime.datetime.fromisoformat(marker.get("checked", ""))
                if (datetime.datetime.now() - checked).total_seconds() < NATIVE_AUTO_RETRY_SECONDS:
                    self.log("原生模型实际推理尚未通过，保留模型文件以便下次重新验收")
                    return
            except (TypeError, ValueError):
                pass
        gpu = gpu_info(root)
        if gpu.get("free_mb", 0) < NATIVE_VIDEO_MIN_FREE_MB:
            self.log("原生模型已下载；当前空闲显存不足，待资源恢复后继续原生验收")
            return
        try:
            result = run_external([str(runtime_python(root)), str(Path(__file__).resolve()),
                                   "--check-native", str(root)], root, log=self.log,
                                  cancel=self.native_stop, timeout=NATIVE_SMOKE_TIMEOUT,
                                  env=shell_env(root, offline=True), capture=True)
            if not native_inference_ready(root) or '"inference_tested": true' not in result.lower():
                raise RuntimeError("原生视频真实推理与解码验收不完整")
            self.log("原生视频模型已通过实际推理、编码与离线解码验收")
        except InterruptedError:
            raise
        except (RuntimeError, OSError, MemoryError, TimeoutError) as error:
            self.log("原生视频实际验收未通过，不能自动降级：" + str(error)[:160])

    def start_native_background(self):
        if (not self.root_path or self.task is not None or self.setup_active or
                not self.capabilities.get("full_offline")):
            return
        if self.native_auto_thread is not None and self.native_auto_thread.is_alive():
            return
        if system_power_state().get("on_battery"):
            return
        self.native_stop.clear()
        self.native_auto_thread = threading.Thread(target=self.native_background_worker, daemon=True)
        self.native_auto_thread.start()

    def native_background_worker(self):
        finished = threading.Event()
        def monitor():
            busy_streak = 0
            last_cpu = None
            last_network_check = 0.0
            while not finished.wait(RESOURCE_MONITOR_INTERVAL):
                try:
                    if self.native_stop.is_set() or self.task == "创作":
                        self.native_stop.set()
                        return
                    if (system_power_state().get("on_battery") or
                            memory_info().get("available", 0) < NATIVE_AUTO_MIN_RAM or
                            shutil.disk_usage(self.root_path).free < NATIVE_AUTO_DISK_RESERVE + MIN_INSTALL_FREE):
                        self.log("可选模型下载已让出电量、内存或磁盘资源")
                        self.native_stop.set()
                        return
                    if time.monotonic() - last_network_check >= NETWORK_COST_CHECK_INTERVAL:
                        last_network_check = time.monotonic()
                        cost = windows_network_cost(force=True)
                        if cost.get("known") and cost.get("metered"):
                            self.log("当前网络已确认按流量计费，暂停模型下载")
                            self.native_stop.set()
                            return
                    current_cpu = cpu_time_sample()
                    if current_cpu and last_cpu:
                        total = current_cpu[1] - last_cpu[1]
                        if total > 0:
                            busy = 1 - (current_cpu[0] - last_cpu[0]) / total
                            busy_streak = busy_streak + 1 if busy > RESOURCE_MONITOR_CPU_LIMIT else 0
                    last_cpu = current_cpu
                    if busy_streak >= RESOURCE_PRESSURE_STREAK + 1:
                        self.log("设备持续繁忙，自动暂停可选模型下载以保障其它软件")
                        self.native_stop.set()
                        return
                except (OSError, ValueError):
                    continue
        watcher = threading.Thread(target=monitor, daemon=True)
        watcher.start()
        try:
            self.prepare_native_automatically()
            if not self.native_stop.is_set():
                self.validate_optional_native()
            if not self.native_stop.is_set():
                self.prepare_optional_automatically()
            self.events.put(("native_done", True, capability_report(self.root_path)))
        except InterruptedError:
            self.events.put(("native_done", False, capability_report(self.root_path)))
        except Exception as error:
            self.log("可选原生模型初始化未完成：" + str(error)[:200])
            self.events.put(("native_done", False, capability_report(self.root_path)))
        finally:
            finished.set()
            watcher.join(timeout=1.0)

    def setup_worker(self):
        root = self.root_path
        try:
            configure_environment(root)
            preflight = host_install_preflight(root)
            self.log("设备预检：" + json.dumps(preflight, ensure_ascii=False))
            if preflight["gpu_mode"] == "cpu_fallback":
                self.log("未检测到可用的 NVIDIA CUDA 候选设备；Intel/AMD 等显卡可使用保守 CPU 推理路径")
            if recover_runtime_transaction(root):
                self.log("已恢复上次中断部署前的独立运行环境")
            current_flags = capability_report(root)
            last_scan = read_json(root / ".studio" / "integrity_scan.json", {}).get("at")
            try:
                due_scan = (datetime.datetime.now() - datetime.datetime.fromisoformat(last_scan)).days >= 7
            except (ValueError, TypeError):
                due_scan = True
            deep = bool(current_flags.get("full_offline") and due_scan)
            self.events.put(("setup_scan", current_flags))
            if deep:
                self.set_status("正在逐一检查模型文件完整 SHA-256", 2)
            if not deep and is_ready(root):
                diagnostics = read_json(root / ".studio" / "ready.json", {}).get("diagnostic", {})
                if not voice_backend_operational(root, diagnostics.get("voice_backend"), force=True):
                    self.log("系统中文语音发生变化，准备修复基础离线配音环境")
                else:
                    self.emit_setup_done(True, "离线创作已就绪；原生视频按本机资源自动选择")
                    return
            needs_basic = not basic_ready(root)
            needs_voice = not test_system_chinese_voice(root)
            budget = installation_disk_budget(root, "basic" if needs_basic else "full", needs_voice,
                                              replacement=needs_basic)
            self.log("动态部署预算：预计 %.2f GB，可用 %.2f GB，未安装模型 %s" % (
                budget["required"] / GB, budget["free"] / GB,
                ",".join(budget["missing_models"]) or "无"))
            if budget["free"] < budget["required"]:
                raise RuntimeError("工作目录空间不足：当前阶段预计还需 %.1f GB（含下载缓存、运行库和安全余量），可用 %.1f GB" % (
                    budget["required"] / GB, budget["free"] / GB))
            if (not basic_ready(root) or deep and (
                    not model_download_complete(root, MODEL_SPECS[0], deep=True) or
                    not voice_backend_operational(root, "sapi", force=True) and
                    not voice_download_complete(root, deep=True)) or
                    not voice_backend_operational(root,
                        read_json(root / ".studio" / "basic_ready.json", {}).get(
                            "diagnostic", {}).get("voice_backend"))):
                self.set_status("检查离线中文语音与系统能力", 3)
                needs_piper = not test_system_chinese_voice(root)
                self.install_dependencies(needs_piper=needs_piper, tier="basic")
                if self.install_stop.is_set():
                    raise InterruptedError("部署已停止")
                missing_director = not model_download_complete(root, MODEL_SPECS[0], deep=deep)
                missing_voice = needs_piper and not voice_download_complete(root, deep=deep)
                endpoints = choose_endpoints() if missing_director or missing_voice else []
                if missing_director:
                    self.set_status("优先安装本地分镜导演", 18)
                    self.fetch_model_with_fallback(0, MODEL_SPECS[0], endpoints, deep=deep)
                if missing_voice:
                    self.set_status("准备中文离线配音", 34)
                    errors = []
                    for endpoint in endpoints:
                        try:
                            run_external([str(runtime_python(root)), str(Path(__file__).resolve()),
                                          "--fetch-voice", str(root), endpoint], root,
                                         log=self.log, cancel=self.install_stop, timeout=1800,
                                         env=shell_env(root, endpoint=endpoint), capture=False)
                            if voice_download_complete(root):
                                break
                        except InterruptedError:
                            raise
                        except Exception as error:
                            errors.append(str(error))
                    if not voice_download_complete(root):
                        raise RuntimeError("中文语音模型下载失败：" + " / ".join(errors)[-450:])
                self.set_status("验收基础离线创作能力", 44)
                diagnostics = self.verify_runtime("basic")
                atomic_json(root / ".studio" / "basic_ready.json",
                            {"runtime_version": RUNTIME_VERSION, "completed": now_stamp(),
                             "python": list(sys.version_info[:2]), "diagnostic": diagnostics})
            self.events.put(("setup_basic", True, "基础分镜、配音与编码就绪，正在完成生成和 AI 审校组件",
                             capability_report(root)))
            if self.install_stop.is_set():
                raise InterruptedError("部署已暂停")
            self.install_dependencies(needs_piper=not test_system_chinese_voice(root), tier="full")
            missing = [(index, spec) for index, spec in enumerate(MODEL_SPECS[1:], 1)
                       if not model_download_complete(root, spec, deep=deep)]
            if missing:
                endpoints = choose_endpoints()
                self.log("模型线路探测仅用于排序；即使 HEAD/GET 探测失败也直接尝试实际下载")
                system_idle = (not system_power_state().get("on_battery") and
                               memory_info().get("available", 0) >= 6 * GB)
                parallel = (min(MAX_DOWNLOAD_PROCESSES, len(missing)) if
                            system_idle and shutil.disk_usage(root).free >= MIN_PARALLEL_DOWNLOAD_FREE and
                            available_threads() >= 3 else 1)
                self.set_status("补齐 %d 项扩展离线模型" % len(missing), 48)
                done = 0
                finished = threading.Event()
                def monitor():
                    while not finished.wait(6):
                        try:
                            total = 0
                            for _, spec in missing:
                                folder = model_path(root, spec[2])
                                staging = folder.with_name(folder.name + ".downloading")
                                target = staging if staging.exists() else folder
                                total += sum(file.stat().st_size for file in target.rglob("*") if file.is_file())
                            self.set_status("扩展模型 %d/%d · 已保存 %.2f GB" % (done, len(missing), total / GB),
                                            48 + int(37 * done / len(missing)))
                        except OSError:
                            pass
                threading.Thread(target=monitor, daemon=True).start()
                try:
                    with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as executor:
                        futures = [executor.submit(self.fetch_model_with_fallback, index, spec, endpoints, deep)
                                   for index, spec in missing]
                        try:
                            for future in concurrent.futures.as_completed(futures):
                                future.result()
                                done += 1
                                self.set_status("扩展离线模型 %d/%d 已就绪" % (done, len(missing)),
                                                48 + int(37 * done / len(missing)))
                        except BaseException:
                            self.install_stop.set()
                            for future in futures:
                                future.cancel()
                            raise
                finally:
                    finished.set()
            if self.install_stop.is_set():
                raise InterruptedError("部署已停止")
            if not optional_ocr_ready(root):
                raise RuntimeError("必须先完成离线OCR验收，才能标记全能力就绪")
            self.set_status("执行完整离线模型与视频编码验收", 92)
            diagnostics = self.verify_runtime("full")
            atomic_json(root / ".studio" / "ready.json",
                        {"version": APP_VERSION, "runtime_version": RUNTIME_VERSION,
                         "completed": datetime.datetime.now().isoformat(),
                         "python": list(sys.version_info[:2]), "smoke_test": True,
                         "model_signature": model_signature(root), "diagnostic": diagnostics})
            if deep:
                atomic_json(root / ".studio" / "integrity_scan.json", {
                    "at": datetime.datetime.now().isoformat(), "status": "full_model_hashes_verified"})
            self.emit_setup_done(True, "完整离线能力已验收；动态视频生成方式已自动选择")
        except InterruptedError:
            self.emit_setup_done(False, "扩展部署已暂停，下载进度保留")
        except Exception:
            self.log(traceback.format_exc())
            explanation = traceback.format_exc().splitlines()[-1][:280]
            category, hint = installation_failure_hint(explanation)
            self.log("部署故障类别：" + category + "；" + hint)
            self.emit_setup_done(False, "扩展部署未完成：" + explanation + "。" + hint + "；可重试继续")
        finally:
            self.setup_active = False

    def fetch_model_with_fallback(self, index, spec, endpoints, deep=False):
        if model_download_complete(self.root_path, spec, deep=deep):
            return
        errors = []
        for endpoint in endpoints:
            if self.install_stop.is_set():
                raise InterruptedError("部署已停止")
            try:
                run_external([str(runtime_python(self.root_path)), str(Path(__file__).resolve()),
                              "--fetch-model", str(self.root_path), str(index), endpoint] +
                             (["deep"] if deep else []),
                             self.root_path, log=self.log, cancel=self.install_stop,
                             timeout=4000, env=shell_env(self.root_path, endpoint=endpoint))
                if model_download_complete(self.root_path, spec, deep=deep):
                    return
                raise RuntimeError("模型文件完整性校验失败")
            except InterruptedError:
                raise
            except Exception as error:
                errors.append(str(error)[:260])
                kind, hint = installation_failure_hint(error)
                self.log("%s线路失败（%s）：%s；%s" % (spec[0], kind, str(error)[:180], hint))
        raise RuntimeError("模型 %s 未下载成功，可联网重试：%s" % (spec[0], " | ".join(errors)[-550:]))

    def verify_runtime(self, tier):
        root = self.root_path
        result = run_external([str(runtime_python(root)), str(Path(__file__).resolve()),
                               "--check-runtime", str(root), tier], root, log=self.log,
                              cancel=self.install_stop, timeout=900,
                              env=shell_env(root, offline=True), capture=True)
        required = {"director", "encoder", "voice"} if tier == "basic" else {
            "director", "encoder", "voice", "listener", "inspector", "painter"}
        for line in reversed(result.splitlines()):
            try:
                value = json.loads(line)
                if (value.get("ok") and value.get("tier") == tier
                        and all(value.get("smoke_test", {}).get(item) == "passed" for item in required)
                        and value.get("voice_backend") in {"sapi", "piper"}):
                    return value
            except (ValueError, TypeError, AttributeError):
                continue
        raise RuntimeError("实际离线推理验收不完整（%s），不能宣称完全就绪" % tier)

    def resume_setup(self):
        if not self.root_path or self.task or self.ready:
            return
        if self.setup_active:
            self.root.after(600, self.resume_setup)
        else:
            self.update_setup()

    def capture_request(self):
        prompt = self.prompt_box.get("1.0", "end-1c").strip()
        if prompt.startswith("例："):
            prompt = ""
        mode = "原生AI视频（自动）" if (requires_subject_motion(prompt) or explicit_native_requested(prompt)) else self.visual_mode.get()
        return {"prompt": prompt, "files": {k: list(v) for k, v in self.assets.items()},
                "duration": int(self.duration.get()), "quality": self.quality.get(), "aspect": self.aspect.get(),
                "audio_role": self.audio_role.get(), "source_audio_role": self.source_audio_role.get(),
                "visual_mode": mode}

    def can_pause_optional_install(self, request):
        return bool(self.request_capabilities_cached(request).get("create_allowed"))

    def start_job(self):
        if not self.root_path or self.task not in (None, "部署") or self.blackbox_active:
            return
        request = self.capture_request()
        if not request["prompt"]:
            self.messagebox.showinfo(APP_NAME, "请输入想制作的视频内容")
            self.prompt_box.focus_set()
            return
        absent = [name for paths in request["files"].values() for name in paths if not Path(name).is_file()]
        if absent and find_resumable_job(self.root_path, request) is None:
            self.messagebox.showerror(APP_NAME, "以下素材已不可用：\n" + "\n".join(absent[:4]))
            return
        requested_duration = parse_requested_duration(request["prompt"])
        if (not MIN_REQUEST_DURATION <= request["duration"] <= MAX_REQUEST_DURATION or
                requested_duration is not None and math.ceil(requested_duration) != request["duration"]):
            self.messagebox.showerror(APP_NAME, "视频时长必须与提示词一致，当前安全范围为%d至%d秒。无法自动缩短用户指定时长。" % (
                MIN_REQUEST_DURATION, MAX_REQUEST_DURATION))
            return
        request_flags = self.request_capabilities_cached(request)
        needs_native = bool(request_flags.get("native_requested"))
        preflight = request_preflight(self.root_path, request, request_flags)
        if not preflight["ready"] and not preflight["prepare"]:
            self.set_status(preflight["reason"])
            self.refresh_buttons()
            return
        if self.task == "部署" or self.setup_active:
            self.pending_start_request = request
            if self.can_pause_optional_install(request) and (not needs_native or request_flags.get("native_video")):
                self.install_stop.set()
                self.set_status("当前创作能力已准备，正在释放部署资源")
            else:
                self.set_status("已接收任务，正在完成模型部署与离线验收")
            self.refresh_buttons()
            self.root.after(900, self.launch_queued_job)
            return
        if not request_flags["create_allowed"]:
            self.pending_start_request = request
            self.set_status("所需离线组件尚未就绪，部署完成后自动启动")
            self.refresh_buttons()
            self.update_setup()
            return
        if needs_native and not preflight["ready"]:
            self.pending_start_request = request
            if not (self.native_auto_thread and self.native_auto_thread.is_alive()):
                self.native_stop.clear()
                self.start_native_background()
            self.set_status("正在准备并实测原生时序视频模型；不使用静态图片代替")
            self.refresh_buttons()
            self.root.after(1000, self.launch_queued_job)
            return
        self.native_stop.set()
        if self.native_auto_thread is not None and self.native_auto_thread.is_alive():
            self.pending_start_request = request
            self.refresh_buttons()
            self.root.after(800, self.launch_queued_job)
            return
        self.launch_job(request)

    def launch_queued_job(self):
        if self.pending_start_request is None:
            return
        request = self.pending_start_request
        native_requested = str(request.get("visual_mode", "")).startswith("原生AI视频")
        if self.setup_active or (self.setup_thread and self.setup_thread.is_alive()):
            if not native_requested and self.can_pause_optional_install(request):
                self.install_stop.set()
            self.root.after(1000, self.launch_queued_job)
            return
        if self.task is not None:
            self.root.after(1000, self.launch_queued_job)
            return
        if native_requested:
            current = capability_report(self.root_path, request)
            self.capabilities = current
            native_state = native_preparation_state(self.root_path, request, current)
            if not native_state["ready"]:
                if not native_state["prepare"]:
                    self.pending_start_request = None
                    self.set_status(native_state["reason"])
                    self.refresh_buttons()
                    return
                if self.native_auto_thread and self.native_auto_thread.is_alive():
                    self.root.after(1600, self.launch_queued_job)
                    return
                if not current.get("full_offline"):
                    self.pending_start_request = None
                    self.set_status("原生视频基础模型仍未完成准备；保留已下载的文件，下次可继续")
                else:
                    self.pending_start_request = None
                    state = read_json(self.root_path / ".studio" / "native_auto.json", {}).get("status")
                    self.set_status("原生模型不可用于当前输入：%s（%s）；不静默替换制作方式" % (
                        current.get("native_input_reason", "模型待验收"), state or "检查GPU、网络和模型能力"))
                self.refresh_buttons()
                return
        elif self.native_auto_thread and self.native_auto_thread.is_alive():
            self.native_stop.set()
            self.root.after(800, self.launch_queued_job)
            return
        flags = self.request_capabilities_cached(request)
        if not flags["create_allowed"]:
            self.pending_start_request = None
            self.set_status("部署未完成，已保存模型下载进度")
            self.refresh_buttons()
            return
        self.pending_start_request = None
        self.launch_job(request)

    def launch_job(self, request):
        flags = self.request_capabilities_cached(request)
        preflight = request_preflight(self.root_path, request, flags)
        if not preflight["ready"] and not preflight["prepare"]:
            self.set_status(preflight["reason"])
            self.refresh_buttons()
            return
        if not flags.get("create_allowed"):
            self.set_status("当前所需的离线创作能力尚未验收，请重试部署")
            self.refresh_buttons()
            return
        if flags.get("native_requested") and not preflight["ready"]:
            self.set_status(preflight["reason"])
            self.log("用户要求原生视频，禁止自动切换为静态图片运镜")
            self.refresh_buttons()
            return
        if self.task is not None or self.setup_active or (self.setup_thread and self.setup_thread.is_alive()):
            self.pending_start_request = request
            self.root.after(180, self.launch_queued_job)
            return
        self.task = "创作"
        self.stop_event.clear()
        self.last_output = None
        self.last_job = None
        self.preview_file = None
        self.preview_photo = None
        self.preview_request = None
        self.scene_entries = []
        self.scene_rows = []
        for item in self.scene_rows_frame.winfo_children():
            item.destroy()
        self.scene_count.configure(text="正在规划")
        self.scene_empty_label = self.label(self.scene_rows_frame, "AI 正在理解需求并编写镜头", 9,
                                             self.palette["muted"])
        self.scene_empty_label.pack(anchor="w")
        self.result_card.pack_forget()
        self.result_card.winfo_children()[0].configure(text="作品已完成", fg=self.palette["green"])
        self.creation_progress["value"] = 0
        self.progress_text.configure(text="0%")
        self.preview_caption.configure(text="正在准备创作任务")
        self.render_task_state("preparing")
        self.draw_preview()
        self.refresh_buttons()
        self.job_thread = threading.Thread(target=self.job_worker, args=(request,), daemon=True)
        self.job_thread.start()

    def job_worker(self, request):
        request_file = self.root_path / ".studio" / "tmp" / ("request_" + now_stamp() + ".json")
        stop_file = self.root_path / ".studio" / "tmp" / ("stop_" + now_stamp() + ".signal")
        self.job_stop_file = stop_file
        try:
            atomic_json(request_file, request)
            outcome = {}
            def receive(line):
                if line.startswith(PROGRESS_PREFIX):
                    try:
                        event = json.loads(line[len(PROGRESS_PREFIX):])
                        if event.get("type") == "status":
                            self.set_status(event["message"], event.get("progress"))
                        elif event.get("type") == "job_path":
                            self.last_job = Path(event["path"])
                        elif event.get("type") == "result":
                            outcome["output"] = event["output"]
                        elif event.get("type") in {"phase", "storyboard", "scene_active", "scene_ready", "scene_review", "reference_warning"}:
                            self.events.put(("project_event", event))
                    except (ValueError, KeyError, TypeError) as error:
                        self.log("进度事件无法读取：" + str(error))
                else:
                    self.log(line)
            run_external([str(runtime_python(self.root_path)), "-u", str(Path(__file__).resolve()), "--run-job",
                          str(self.root_path), str(request_file), str(stop_file)], self.root_path,
                         cancel=self.stop_event,
                         timeout=(max(21600, int(request["duration"] * 3600))
                                  if str(request.get("visual_mode", "")).startswith("原生AI视频") else 21600),
                         env=shell_env(self.root_path, offline=True),
                          capture=True, on_line=receive, stop_file=stop_file, stop_grace=STOP_GRACE_SECONDS)
            if not outcome.get("output"):
                raise RuntimeError("创作进程未返回完成的成品路径")
            self.events.put(("job_done", True, outcome["output"]))
        except InterruptedError:
            self.events.put(("job_done", False, "已停止，已完成的中间素材仍保存在工作目录"))
        except Exception as error:
            self.log(traceback.format_exc())
            recent = read_json(self.last_job / "final_reviews.json", []) if self.last_job else []
            latest = recent[-1] if isinstance(recent, list) and recent else {}
            failure_code = latest.get("failure_code")
            if failure_code:
                scene = latest.get("scene")
                detail = ("第%d幕 · " % (scene + 1) if isinstance(scene, int) else "")
                detail += "%s：%s" % (failure_code, latest.get("failure", "最终审核未通过"))
            else:
                detail = "%s：%s" % (type(error).__name__, str(error)[-250:])
            self.events.put(("job_done", False, "生成未交付：" + detail[:340]))
        finally:
            request_file.unlink(missing_ok=True)
            stop_file.unlink(missing_ok=True)
            self.job_stop_file = None

    def blackbox(self):
        if not self.root_path or self.blackbox_active:
            return
        request = self.capture_request()
        self.blackbox_active = True
        self.refresh_buttons()
        def work():
            try:
                value = export_black_box(self.root_path, request, self.last_job, self.log,
                                         include_private=False)
                self.events.put(("black_done", True, str(value)))
            except Exception:
                self.log(traceback.format_exc())
                self.events.put(("black_done", False, traceback.format_exc().splitlines()[-1]))
        self.blackbox_thread = threading.Thread(target=work, daemon=True)
        self.blackbox_thread.start()

    def process_events(self):
        if self.closing:
            return
        try:
            for _ in range(80):
                try:
                    event = self.events.get_nowait()
                except queue.Empty:
                    break
                category = event[0]
                if category == "log":
                    continue
                elif category == "status":
                    self.stage_label.configure(text=event[1][:250], fg=self.palette["soft"])
                    if event[2] is not None:
                        percent = max(0, min(100, int(event[2])))
                        if self.task == "创作":
                            self.creation_progress["value"] = percent
                            self.progress_text.configure(text="%d%%" % percent)
                        else:
                            self.setup_progress["value"] = percent
                elif category == "project_event":
                    data = event[1]
                    kind = data.get("type")
                    if kind == "reference_warning":
                        self.stage_label.configure(text=str(data.get("message", "部分参考内容未采用")),
                                                   fg=self.palette["amber"])
                        self.log("参考素材警示：" + str(data.get("message", "")))
                    elif kind == "phase":
                        self.render_task_state(str(data.get("phase", "idle")))
                    elif kind == "storyboard":
                        scenes = data.get("scenes", [])
                        if isinstance(scenes, list):
                            self.render_storyboard(str(data.get("title", "")), scenes)
                    elif kind in {"scene_active", "scene_ready", "scene_review"}:
                        index = data.get("index", -1)
                        if isinstance(index, int):
                            state = "active" if kind == "scene_active" else "reviewing" if kind == "scene_review" else "done"
                            self.render_scene_state(index, state, data.get("preview"),
                                                    str(data.get("review", "")))
                elif category == "preview_ready":
                    self.preview_worker = None
                    if not event[2]:
                        self.preview_failed_keys.add(event[1])
                        if len(self.preview_failed_keys) > UI_PREVIEW_CACHE_LIMIT:
                            self.preview_failed_keys.clear()
                    if self.preview_request and self.preview_request[0] != event[1]:
                        self.start_preview_thumbnail()
                    elif event[2]:
                        self.draw_preview()
                elif category == "setup_scan":
                    if self.task != "部署":
                        continue
                    self.capabilities = dict(event[1])
                    self.ready = bool(self.capabilities.get("full_offline"))
                    self.basic_ready = bool(self.capabilities.get("basic"))
                    self.ready_badge.configure(text=offline_readiness_label(self.capabilities),
                                               fg=self.palette["green"] if self.ready else
                                               self.palette["amber"])
                    self.update_capability_label()
                    self.refresh_buttons()
                elif category == "setup_basic":
                    self.capabilities = dict(event[3])
                    self.update_capability_label()
                    self.ready = False
                    self.basic_ready = bool(event[1])
                    self.ready_badge.configure(text="● 基础依赖已验收 · 完整创作仍需部署", fg=self.palette["amber"])
                    self.stage_label.configure(text=event[2], fg=self.palette["soft"])
                    self.refresh_buttons()
                    if self.pending_start_request is not None and self.can_pause_optional_install(
                            self.pending_start_request):
                        self.install_stop.set()
                        self.root.after(220, self.launch_queued_job)
                elif category == "setup_done":
                    if self.task != "部署":
                        continue
                    self.task = None
                    self.capabilities = dict(event[3])
                    self.update_capability_label()
                    self.ready = bool(self.capabilities.get("full_offline"))
                    self.basic_ready = bool(self.capabilities.get("basic"))
                    self.ready_badge.configure(text=offline_readiness_label(self.capabilities),
                                               fg=self.palette["green"] if self.ready else
                                               self.palette["amber"])
                    message = (event[2] + "；完整创作需等待语义审校及生成组件验收" if self.basic_ready and not self.ready
                               else event[2])
                    self.stage_label.configure(text=message[:250],
                                               fg=self.palette["green"] if event[1] or self.basic_ready
                                               else self.palette["danger"])
                    if self.capabilities.get("full_offline", False):
                        self.setup_progress["value"] = 100
                    self.refresh_buttons()
                    self.refresh_smart_suggestions()
                    if self.ready:
                        self.deployment_retry = 0
                    elif not any(term in str(event[2]) for term in
                                 ("空间不足", "内存不足", "不支持", "不兼容", "文件夹不可写", "权限不足")):
                        self.deployment_retry += 1
                        backoff = min(15 * 60 * 1000, 20 * 1000 * (2 ** min(5, self.deployment_retry - 1)))
                        self.root.after(backoff, self.update_setup)
                    if self.pending_start_request is not None:
                        pending_flags = self.request_capabilities_cached(self.pending_start_request)
                        if pending_flags["create_allowed"]:
                            if pending_flags.get("native_requested") and not pending_flags.get("native_video"):
                                self.root.after(250, self.start_native_background)
                            self.root.after(1200, self.launch_queued_job)
                        elif not event[1]:
                            self.pending_start_request = None
                            self.stage_label.configure(text=(message + "；可再次点击启动尝试部署")[:250],
                                                       fg=self.palette["danger"])
                            self.refresh_buttons()
                    elif self.ready:
                        self.root.after(450, self.start_native_background)
                elif category == "job_done":
                    self.task = None
                    if event[1]:
                        self.last_output = Path(event[2])
                        self.creation_progress["value"] = 100
                        self.progress_text.configure(text="100%")
                        self.render_task_state("complete")
                        self.stage_label.configure(text="成片已交付 · " + str(event[2]),
                                                   fg=self.palette["green"])
                        self.show_result_panel(self.last_output)
                    else:
                        self.stage_label.configure(text=event[2], fg=self.palette["danger"])
                        self.show_job_error(event[2])
                    self.refresh_buttons()
                    if event[1] and self.root_path and shutil.disk_usage(self.root_path).free < MIN_INSTALL_FREE:
                        self.cleanup_thread = threading.Thread(target=cleanup_completed_cache,
                                                               args=(self.root_path, self.stop_event),
                                                               daemon=True)
                        self.cleanup_thread.start()
                    self.root.after(450, self.resume_setup)
                    if event[1]:
                        self.root.after(800, self.start_native_background)
                elif category == "native_done":
                    self.capabilities = dict(event[2])
                    self.update_capability_label()
                    self.refresh_smart_suggestions()
                    if self.pending_start_request is not None:
                        self.root.after(200, self.launch_queued_job)
                elif category == "black_done":
                    self.blackbox_active = False
                    self.refresh_buttons()
                    if event[1]:
                        self.messagebox.showinfo(APP_NAME, "黑匣子已保存：\n" + event[2]
                                                 + "\n\n分享前请确认压缩包内容。")
                    else:
                        self.messagebox.showerror(APP_NAME, "黑匣子导出失败：\n" + event[2])
        except Exception as error:
            try:
                self.log("界面事件处理异常：%s · %s" % (type(error).__name__, str(error)[:240]))
            except (OSError, RuntimeError, AttributeError):
                pass
        finally:
            try:
                self.root.after(120, self.process_events)
            except self.tk.TclError:
                pass

    def on_close(self):
        if self.closing:
            return
        running = (self.task in {"部署", "创作"} or self.blackbox_active or
                   self.native_auto_thread and self.native_auto_thread.is_alive())
        if running and not self.messagebox.askyesno(
                APP_NAME, "当前任务正在执行，确定退出？未完成的数据将保存在工作目录，下次可续传。"):
            return
        self.closing = True
        if self.preview_after is not None:
            try:
                self.root.after_cancel(self.preview_after)
            except self.tk.TclError:
                pass
            self.preview_after = None
        self.stop_event.set()
        self.install_stop.set()
        self.native_stop.set()
        if self.job_stop_file is not None:
            try:
                self.job_stop_file.touch()
            except OSError:
                pass
        with RUNNING_CHILDREN_LOCK:
            children = list(RUNNING_CHILDREN)
        for proc in children:
            stop_process_tree(proc)
        self.close_deadline = time.monotonic() + STOP_GRACE_SECONDS
        self.root.after(80, self.finish_close)

    def finish_close(self):
        threads = [self.setup_thread, self.native_auto_thread, self.job_thread,
                   self.blackbox_thread, self.cleanup_thread]
        alive = [thread for thread in threads if thread is not None and thread.is_alive()]
        with RUNNING_CHILDREN_LOCK:
            children = [proc for proc in RUNNING_CHILDREN if proc.poll() is None]
        if (alive or children) and time.monotonic() < self.close_deadline:
            self.root.after(180, self.finish_close)
            return
        for proc in children:
            stop_process_tree(proc)
        if not alive and self.workspace_lock is not None:
            self.workspace_lock.close()
            self.workspace_lock = None
        self.root.destroy()

    def run(self):
        self.root.mainloop()



def main():
    args = sys.argv[1:]
    if (sys.version_info[:2] < MIN_PYTHON or sys.version_info[:2] > MAX_PYTHON
            or struct.calcsize("P") != 8):
        raise SystemExit("需要 Python 3.10–3.13 的 64 位解释器")
    if os.name != "nt":
        raise SystemExit("本程序仅支持 Windows 11 x64")
    if sys.getwindowsversion().build < WINDOWS_11_MIN_BUILD:
        raise SystemExit("需要 Windows 11（系统内部版本 22000 或更高）")
    if args and args[0] == "--fetch-native" and len(args) in (3, 4):
        download_native_worker(args[1], args[2], args[3] if len(args) == 4 else None)
        return
    if args and args[0] == "--fetch-optional" and len(args) == 4:
        download_optional_model_worker(args[1], args[2], args[3])
        return
    if args and args[0] == "--fetch-model" and len(args) in (4, 5):
        download_model_worker(args[1], int(args[2]), args[3],
                              deep=len(args) == 5 and args[4] == "deep")
        return
    if args and args[0] == "--prepare-preview" and len(args) == 6:
        prepare_preview_thumbnail(args[1], args[2], args[3], int(args[4]), int(args[5]))
        return
    if args and args[0] == "--render-native" and 5 <= len(args) <= 10:
        native_video_worker(args[1], args[2], args[3], args[4],
                            float(args[5]) if len(args) >= 6 else 3.0,
                            (args[6] or None) if len(args) >= 7 else None,
                            args[7] if len(args) >= 8 else "横屏 16:9",
                            (args[8] or None) if len(args) >= 9 else None,
                            StopSignal(args[9]) if len(args) >= 10 and args[9] else None)
        return
    if args and args[0] == "--verify-packages" and len(args) == 4:
        verify_packages_worker(args[1], args[2], args[3] == "piper")
        return
    if args and args[0] == "--check-native" and len(args) == 2:
        check_native_worker(args[1])
        return
    if args and args[0] == "--check-runtime" and len(args) in (2, 3):
        check_runtime_worker(args[1], args[2] if len(args) == 3 else "full")
        return
    if args and args[0] == "--fetch-voice" and len(args) == 3:
        download_voice_worker(args[1], args[2])
        return
    if args and args[0] == "--speak" and len(args) == 4:
        piper_speak_worker(args[1], args[2], args[3])
        return
    if args and args[0] == "--speak-server" and len(args) == 2:
        piper_server_worker(args[1])
        return
    if args and args[0] == "--read-document" and len(args) == 4:
        configure_environment(args[1])
        Path(args[3]).write_text(document_text(args[2]), encoding="utf-8")
        return
    if args and args[0] == "--run-job" and len(args) == 4:
        root = Path(args[1])
        configure_environment(root)
        os.environ.update({"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "DIFFUSERS_OFFLINE": "1"})
        request = read_json(args[2], {})
        if not request.get("prompt"):
            raise RuntimeError("创作请求没有有效的提示词")
        def emit(payload):
            print(PROGRESS_PREFIX + json.dumps(payload, ensure_ascii=False), flush=True)
        def event(message, progress=None):
            emit({"type": "status", "message": message, "progress": progress})
        studio = StudioJob(root, request, event, StopSignal(args[3]),
                           lambda line: print(line, flush=True), emit=emit)
        print(PROGRESS_PREFIX + json.dumps({"type": "job_path", "path": str(studio.job)},
                                            ensure_ascii=False), flush=True)
        output = studio.start()
        print(PROGRESS_PREFIX + json.dumps({"type": "result", "output": str(output)},
                                            ensure_ascii=False), flush=True)
        return
    StudioUI().run()


if __name__ == "__main__":
    main()
